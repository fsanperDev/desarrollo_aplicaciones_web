/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_ap1;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_PROG_AP1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner miTeclado = new Scanner(System.in);
        
  // VARIABLES
    //Depositos
     double heladoVainilla = 1;
     double heladoNata = 1;
     double heladoChocolate = 1;
     int tarrina = 60;
     int almendras = 30;
     int caramelo = 30;
    //Opciones
     int opcion1 = 0;
     int opcion2 = 0;
     int opcion3 = 0;
     int opcion4 = 0;
     int opcion5 = 0;
     int opcion6 = 0;
     int numeroExtras = 0;
    
     int numeroEntero = 0;
     int numeroBolas = 0;
    //Dinero
     double precioHelado = 0;
     double dineroPagar = 0;
    //Bucles
     boolean salir = false;
     boolean correctoBolas = false;
     boolean salirExtras = false;
     boolean salirPagar = false;
    //Restar deposito
     double restarHeladoVainilla = 0;
     double restarHeladoNata = 0;
     double restarHeladoChocolate = 0;
     double numeroBolasElegidas = 0;
     int restarAlmendra = 0;
     int restarCaramelo = 0;
     
    //Correccion de errores
     String numeroCaracter = "";
    //Textos
     final String menuInicio = "*** Bienvenido ***\n 1.Vender helado\n 2.Consultar estado de la máquina \n 3.Apagar máquina y salir";
     final String TnumeroBolas = "¿Cuantas bolas de helado deseas? (mínimo 1 máximo 3)\n";
     final String TsaborBolas = "Selecciona el sabor de la bola "+numeroBolas+",\n Pulse 1 para Helado de Vainilla. \n "
             + "Pulse 2 para Helado de Nata.\n Pulse 3 para Helado de Chocolate. ";
     final String TNumeroExtras = "Seleccione el numero de extras que deseas (mínimo 1 y máximo 2) \n";
     final String Textras = "Pulsa 1 para Almendras \n Pulsa 2 para Caramelo";
     final String Tpagar = "El precio del pedido es de "+precioHelado+"€, introduce el dinero:\n"
             + "Pulsa 1 para introducir 0.50 cent.\n Pulsa 2 para introducir 1€.\n Pulsa 3 para introducir 2€. \n"
             + "Pulsa 4 para introducir 5€.\n Pulsa 5 para pagar la cantidad introducida.\n";
  // AQUI EMPIEZA 
    do{        
        System.out.println(menuInicio);
           try {
                numeroCaracter = miTeclado.nextLine();
                opcion1 = Integer.parseInt(numeroCaracter);
            }catch (Exception e){
                System.err.println("Error teclado: Se espera un numero entero");
                opcion1 = 0;
            }
        switch(opcion1){ 
            case 1:
//------------------------------------------------------------------------------------------------------------------------       
        /**
         * Elegir el numero de bolas de helado.
         */
                do{
                    System.out.println(TnumeroBolas);
                    try {
                        numeroCaracter = miTeclado.nextLine();
                        opcion2 = Integer.parseInt(numeroCaracter);
                    }catch (Exception e){
                        System.err.println("Error teclado: Se espera un numero entero");
                        opcion2 = 0;
                    }
                    if(opcion2 >= 1 || opcion2 <= 3){
                        numeroBolas = opcion2 + numeroBolas;
                        precioHelado = precioHelado + numeroBolas;
                        correctoBolas = true;
                    }else{
                        System.out.println("Has puesto un numero incorrecto"); 
                    }
                }while(!correctoBolas);
//-----------------------------------------------------------------------------------------------------------------------
 /**
  * Elegir el sabor de cada bola.
  */
                while(numeroBolas == 0){                          
                    System.out.println(TsaborBolas);
                       try {
                            numeroCaracter = miTeclado.nextLine();
                            opcion3 = Integer.parseInt(numeroCaracter);
                        }catch (Exception e){
                            System.err.println("Error teclado: Se espera un numero entero");                            
                        }
                    numeroBolasElegidas = numeroBolasElegidas + opcion3;
                    switch(opcion3){
                        case 1:
                            restarHeladoVainilla = restarHeladoVainilla + 0.2;
                            numeroBolas--;
                            break;
                        case 2:
                            restarHeladoVainilla = restarHeladoNata + 0.2;
                            numeroBolas--;
                            break;
                        case 3:
                            restarHeladoVainilla = restarHeladoChocolate + 0.2;
                            numeroBolas--;
                            break;
                        default:
                            System.out.println("No has introducido una tecla correcta.");
                    }
                    
                }
//----------------------------------------------------------------------------------------------------------------------
    /**
     * Seleccionar los extras. (Almendras o Caramelo)
     */
                 do{                        
                    System.out.println(TNumeroExtras);
                       try {
                            numeroCaracter = miTeclado.nextLine();
                            numeroExtras = Integer.parseInt(numeroCaracter);
                        }catch (Exception e){
                            System.err.println("Error teclado: Se espera un numero entero"); 
                            numeroExtras = 0;
                        }
                    if(numeroExtras > 0){
                       while(numeroExtras > 0){ 
                            System.out.println(Textras);
                            try {
                                numeroCaracter = miTeclado.nextLine();
                                opcion4 = Integer.parseInt(numeroCaracter);
                            }catch (Exception e){
                                System.err.println("Error teclado: Se espera un numero entero"); 
                                opcion4 = 0;
                            }
                            switch(opcion4){
                                case 1:
                                    restarAlmendra = restarAlmendra - 1;
                                    precioHelado = precioHelado + 0.5;
                                    numeroExtras--;
                                    break;
                                case 2:
                                    restarCaramelo = restarCaramelo -1;
                                    precioHelado = precioHelado + 0.5;
                                    numeroExtras--;
                                    break;
                                default:
                                    System.out.println("Numero no admitido.");
                            }
                        if(numeroExtras == 0){salirExtras = true;}
                        }
                    }else{
                        System.err.println("Numero introducido incorrecto.");
                    } 
                 }while(!salirExtras);
//-----------------------------------------------------------------------------------------------------------------------
    /**
     * Comprobar si puede servirse el helado.
     */
                if((heladoVainilla>0)&&(heladoNata>0)&&(heladoChocolate>0)&&(tarrina>0)&&(almendras>0)&&(caramelo>0)){
                    do{
                        System.out.println(Tpagar);
                        System.out.println("Dinero introducido: "+dineroPagar+"€");
                        try {
                             numeroCaracter = miTeclado.nextLine();
                             opcion5 = Integer.parseInt(numeroCaracter);
                         }catch (Exception e){
                             System.err.println("Error teclado: Se espera un numero entero");
                             opcion5 = 0;
                         }
                     switch(opcion5){
                        case 1:
                             dineroPagar = dineroPagar + 0.5;
                             break;
                        case 2:
                             dineroPagar = dineroPagar + 1;
                             break;
                        case 3:
                             dineroPagar = dineroPagar + 2;
                             break;
                        case 4:
                             dineroPagar = dineroPagar + 5;
                             break;
                        case 5:
                            if(dineroPagar >= precioHelado){
                              dineroPagar = dineroPagar - precioHelado;
                                if(dineroPagar >= 0){
                                /**
                                 * Restar al deposito el pedido.
                                 */
                                    heladoVainilla = heladoVainilla - restarHeladoVainilla;
                                    heladoNata = heladoNata - restarHeladoNata;
                                    heladoChocolate = heladoChocolate - restarHeladoChocolate;
                                    almendras = almendras - restarAlmendra;
                                    caramelo = caramelo - restarCaramelo;
                                    tarrina--;
                                    salirPagar = true;
                                }else{
                                 salirPagar = true;
                                }         
                              
                            }else{
                                System.out.println("Cantidad de dinero insufuciente.");
                                salirPagar = true;
                            }                       
                             break;
                        default:
                            System.out.println("No has introducido un numero correcto");
                     }
                    }while(!salirPagar);
                }else{
                    System.out.println("No se ha podido reslizar el pedido debido a que no hay suficientes existencias,"
                            + " consulta el estado de la máquina para ver los depositos.");
                }
                break;
            case 2:
//-----------------------------------------------------------------------------------------------------------------------
    /**
     * Mostrar los depositos por pantalla.
     */            
                System.out.println("--- Depósito de la máquina ---\n"
                        + "Helado de Vainilla: "+heladoVainilla+"K\n"
                        + "Helado de Nata: "+heladoNata+"K\n"
                        + "Helado de Chocolate: "+heladoChocolate+"K\n"
                        + "Tarrinas: "+tarrina+"\n"
                        + "Almendras: "+almendras+" dosis\n"
                        + "Caramelo: "+caramelo+" dosis\n");
                break;
            case 3:
                salir = true;
                break;
            default:
                System.out.println("No has pulsado la tecla correcta");
        }
        
    }while(!salir);
 }
}