/*
 * Copyright (C) 2017 Gerardo Gómez Puerto <gerardo@nyxe.es>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sudokuProg;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

/**
 * Almacena un tablero de sudoku y gestiona la modificación de sus valores, permitiendo obtener la
 * representación gráfica del tablero en forma de cadena.
 *
 * @author Gerardo Gómez Puerto
 *
 * @version 1.8.1
 */
public class Sudoku {

  // Las dimensiones del sudoku, la representación de la celda vacía y el máximo de jugadas
  // son constantes públicas
  public static final int DIM = 9;
  public static final int CELDA_VACIA = 0;
  public static final int JUGADAS_MAX = 256;
  // Las dimensiones de un sector no son relevantes fuera de la clase
  private static final int DIM_SECTOR = 3;

  // Mensajes de error propios del método de introducción de número
  private static final String NO_ES_CANDIDATO = "\n%s no es un candidato válido de la celda (%d,%d)";
  private static final String INICIAL =
      "\nLa celda indicada pertenece al tablero y no es modificable";
  private static final String SIN_CANDIDATOS = "\nLa casilla (%d,%d) NO tiene candidatos";

  // Atributos
  private Celda[][] tablero; // El tablero consiste en una tabla de DIMxDIM objetos Celda
  private int[][] jugadas; // Almacena las jugadas en un array de [JUGADAS_MAX][fila, columna, numero] enteros
  private int contadorJugadas; // Lleva la cuenta del núméro de jugadas válidas realizadas
  private int celdasVacias; // Lleva la cuenta de las celdas vacías permitiendo comprobar si el sudoku está completo
  private int celdasIniciales; // Almacena el número de celdas propias del tablero

  /**
   * Inicializa un Sudoku vacío de DIMxDIM celdas mutables
   */
  public Sudoku() {
    this.tablero = new Celda[DIM][DIM];
    this.jugadas = new int[JUGADAS_MAX][];
    this.contadorJugadas = 0;
    this.celdasIniciales = 0;
    this.celdasVacias = DIM * DIM;

    for (int fila = 0; fila < DIM; fila++) {
      for (int col = 0; col < DIM; col++) {
        this.tablero[fila][col] = new CeldaMutable();
      }
    }
  }

  /**
   * Recibe un array bidimensional de cadenas que representa un tablero de sudoku y lo procesa para
   * crear DIMxDIM celdas iniciales con el contenido correspondiente. También se actualizan el
   * número de celdas vacías y se inicializan el almacén de jugadas y su contador
   *
   * @param filas un array bidimensional de cadenas representando el tablero de juego
   */
  public Sudoku(String[][] filas) {
    this();
    int numero;

    for (int fila = 0; fila < DIM; fila++) {
      for (int col = 0; col < DIM; col++) {
        numero = Integer.valueOf(filas[fila][col]);
        if (numero != CELDA_VACIA) {
          this.tablero[fila][col] = new CeldaInicial(numero);
          this.eliminarCandidato(fila, col, numero);
          this.celdasIniciales++;
        }
      }
    }

    this.celdasVacias -= this.celdasIniciales;
  }

  /**
   * Recupera el contenido de un <b>Sudoku</b> guardado inicializando uno vacío y actualizándolo al
   * estado pasado por los parámetros
   *
   * @param inicial array que define las celdas iniciales del <b>Sudoku</b>. Cada entrada es un
   * array de 3 enteros que identifican la fila, la columna y el contenido de la celda
   * @param jugadas array con JUGADAS_MAX entradas, cada una de ellas consistente en un array de 3
   * enteros que identifican la fila, la columna y el número introducido en cada una de las jugadas
   * válidas realizadas en el <b>Sudoku</b> a recuperar
   * @param nJugadas entero con el número de jugadas acumuladas en el <b>Sudoku</b> a recuperar
   * @deprecated es preferible emplear el constructor que también1 recibe el array int[][]
   * <i>estado</i> para preservar el estado de las celdas borradas por el usuario
   */
  public Sudoku(int[][] inicial, int[][] jugadas, int nJugadas) {
    this();

    this.celdasIniciales = inicial.length;

    for (int[] celda : inicial) {
      this.tablero[celda[0]][celda[1]] = new CeldaInicial(celda[2]);
      this.eliminarCandidato(celda[0], celda[1], celda[2]);
    }

    this.celdasVacias -= this.celdasIniciales;

    for (int indice = 0; indice < nJugadas; indice++) {
      int fila = jugadas[indice][0];
      int col = jugadas[indice][1];
      int numero = jugadas[indice][2];
      CeldaMutable celda = (CeldaMutable) this.tablero[fila][col];

      if (celda.estaVacia()) {
        celda.introducirNumero(numero);
        this.celdasVacias--;
      } else {
        int numeroPrevio = celda.obtenerNumero();
        celda.introducirNumero(numero);
        this.reintroducirCandidato(fila, col, numeroPrevio);
      }

      this.eliminarCandidato(fila, col, numero);
      this.jugadas[contadorJugadas++] = new int[]{fila, col, numero};
    }
  }

  /**
   * Recupera el contenido de un <b>Sudoku</b> guardado previamente, inicializando uno vacío y
   * actualizándolo al estado pasado por los parámetros. Esta versión es más eficiente y preserva el
   * estado de las celdas borradas por el usuario
   *
   * @param inicial array que define las celdas iniciales del <b>Sudoku</b>. Cada entrada es un
   * array de 3 enteros que identifican la fila, la columna y el contenido de la celda
   * @param jugadas array con JUGADAS_MAX entradas, cada una de ellas consistente en un array de 3
   * enteros que identifican la fila, la columna y el número introducido en cada una de las jugadas
   * válidas realizadas en el <b>Sudoku</b> a recuperar
   * @param nJugadas entero con el número de jugadas acumuladas en el <b>Sudoku</b> a recuperar
   * @param estado array que define las celdas rellenadas por el usuario en el momento de guardar la
   * partida. Cada entrada es un array de 3 enteros que identifican la fila, la columna y el
   * contenido de la celda
   * @throws Exception
   */
  public Sudoku(int[][] inicial, int[][] jugadas, int nJugadas, int[][] estado) {
    this();

    this.celdasIniciales = inicial.length;

    for (int[] celda : inicial) {
      this.tablero[celda[0]][celda[1]] = new CeldaInicial(celda[2]);
      this.eliminarCandidato(celda[0], celda[1], celda[2]);
    }

    this.celdasVacias -= this.celdasIniciales;

    for (int[] descriptor : estado) {
      CeldaMutable celda = (CeldaMutable) this.tablero[descriptor[0]][descriptor[1]];
      celda.introducirNumero(descriptor[2]);
      this.eliminarCandidato(descriptor[0], descriptor[1], descriptor[2]);
      this.celdasVacias--;
    }

    this.contadorJugadas = nJugadas;
    this.jugadas = jugadas;
  }

  public boolean esMutable(int fila, int col) {
    return tablero[fila][col] instanceof CeldaMutable;
  }

  /**
   * Comprueba si el sudoku está completo
   *
   * @return true si el sudoku está completo, false en el caso contrario
   */
  public boolean estaCompleto() {
    return this.celdasVacias == 0;
  }

  /**
   * Comprueba si quedan jugadas disponibles
   *
   * @return true si quedan jugadas, false en caso contrario
   */
  public boolean quedanJugadas() {
    return this.contadorJugadas < JUGADAS_MAX;
  }

  /**
   * Comprueba si un número determinado se encuentra en la fila indicada
   *
   * @param numero número entero a comparar
   * @param fila fila en la que se comprobará la presencia del número
   * @return true si el número se encuentra en la fila, false si no es así
   */
  public boolean compruebaEnFila(int numero, int fila) {

    for (int col = 0; col < DIM; col++) {
      if (this.tablero[fila][col].obtenerNumero() == numero) {
        return true;
      }
    }

    return false;
  }

  /**
   * Comprueba si un número determinado se encuentra en la columna indicada
   *
   * @param numero número entero a comparar
   * @param col columna en la que se comprobará la presencia del número
   * @return true si el número se encuentra en la columna, false si no es así
   */
  public boolean compruebaEnColumna(int numero, int col) {

    for (int fila = 0; fila < DIM; fila++) {
      if (this.tablero[fila][col].obtenerNumero() == numero) {
        return true;
      }
    }

    return false;
  }

  /**
   * Comprueba si un número determinado se encuentra en el sector indicado
   *
   * @param numero número entero a comparar
   * @param sector sector en el que se comprobará la presencia del número
   * @return true si el número se encuentra en el sector, false si no es así
   */
  public boolean compruebaEnSector(int numero, int sector) {

    int filaInicial = this.fInicioSector(sector);
    int columnaInicial = this.cInicioSector(sector);
    int filaFinal = filaInicial + DIM_SECTOR;
    int columnaFinal = columnaInicial + DIM_SECTOR;

    for (int fila = filaInicial; fila < filaFinal; fila++) {
      for (int col = columnaInicial; col < columnaFinal; col++) {
        if (this.tablero[fila][col].obtenerNumero() == numero) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Resume el estado del Sudoku en una serie de parámetros que son pasados al método
   * <i>guardarPartidaSudoku</i> de la clase <b>IO</b> para almacenarlo en forma de archivo .sdp
   *
   * @param archivo cadena conteniendo nombre del archivo a guardar
   * @throws FileNotFoundException si no se puede crear el archivo indicado
   * @throws IOException en el caso de que se produzca un error durante la escritura del archivo
   */
  public void guardar(String archivo) throws FileNotFoundException, IOException {
    int jugadas[][];
    jugadas = new int[this.contadorJugadas][3];

    for (int jugada = 0; jugada < this.contadorJugadas; jugada++) {
      for (int indice = 0; indice < 3; indice++) {
        jugadas[jugada][indice] = this.jugadas[jugada][indice];
      }
    }

    int[][] inicial;
    int[][] estado;
    inicial = new int[this.celdasIniciales][3];
    int celdasEstado = (DIM * DIM) - this.celdasVacias - this.celdasIniciales;
    estado = new int[celdasEstado][3];
    int celdaInicial;
    int celdaUsuario;
    celdaInicial = 0;
    celdaUsuario = 0;

    for (int fila = 0; fila < DIM; fila++) {
      for (int col = 0; col < DIM; col++) {
        if (this.tablero[fila][col] instanceof CeldaInicial) {
          inicial[celdaInicial][0] = fila;
          inicial[celdaInicial][1] = col;
          inicial[celdaInicial++][2] = this.tablero[fila][col].obtenerNumero();
        } else if (!this.tablero[fila][col].estaVacia()) {
          estado[celdaUsuario][0] = fila;
          estado[celdaUsuario][1] = col;
          estado[celdaUsuario++][2] = this.tablero[fila][col].obtenerNumero();
        }
      }
    }

    IO.guardarPartidaSudoku(inicial, jugadas, estado, archivo);
  }

  /**
   * Calcula con una sencilla fórmula el sector correspondiente a una celda dada
   *
   * @param fila fila de la celda, comenzando en 0
   * @param col columna de la celda, comenzando en 0
   * @return valor entero que se corresponde al número del sector, comenzando en 1
   */
  public static int obtenerSector(int fila, int col) {
    //La fila se incrementa DIM cada DIM sectores
    //La columna se incrementa DIM por cada sector de una misma fila, siendo 0 al comienzo de cada una
    return (fInicioSector(fila + 1) + (col) / Sudoku.DIM_SECTOR) + 1;
  }

  /**
   * Calcula con una sencilla fórmula la fila inicial de un sector dado
   *
   * @param sector el sector cuya fila inicial se quiere conocer, comenzando en 1
   * @return un entero indicando la posición inicial del sector en la tabla, comenzando en 0
   */
  private static int fInicioSector(int sector) {
    return (sector - 1) / Sudoku.DIM_SECTOR * Sudoku.DIM_SECTOR;
  }

  /**
   * Calcula con una sencilla fórmula la columna inicial de un sector dado
   *
   * @param sector el sector cuya fila inicial se quiere conocer, comenzando en 1
   * @return un entero indicando la posición inicial del sector en la tabla, comenzando en 0
   */
  private int cInicioSector(int sector) {
    return (sector - 1) % Sudoku.DIM_SECTOR * Sudoku.DIM_SECTOR;
  }

  /**
   * Si las coordenadas refieren a una <b>CeldaMutable</b> de la que el número introducido es
   * candidato, llama al método adecuado para introducirlo, actualiza los candidatos de las celdas
   * afectadas (misma fila, columna o sector), almacena la jugada e incrementa el contador de
   * jugadas. En caso de que la celda estuviera vacía, decrementa el contador correspondiente.
   * jugada incrementando el contador de jugadas En caso contrario, lanza una excepción.
   *
   *
   * @param fila fila de la celda a actualizar, comenzando en 1
   * @param col columna de la celda a actualizar, comenzando en 1
   * @param numero número a introducir en la celda
   * @throws Exception si la celda introducida no es modificable por ser del tipo
   * <b>CeldaInicial</b> o porque el número introducido no se encuentra entre sus candidatos
   * posibles
   */
  public void introducirNumero(int fila, int col, int numero) {

    CeldaMutable celda = (CeldaMutable) this.tablero[fila][col];
    if (celda.estaVacia()) {
      celda.introducirNumero(numero);
      this.celdasVacias--;
    } else {
      int numeroPrevio = celda.obtenerNumero();
      celda.introducirNumero(numero);
      this.reintroducirCandidato(fila, col, numeroPrevio);
    }
    this.eliminarCandidato(fila, col, numero);
    this.jugadas[contadorJugadas++] = new int[]{fila, col, numero};
  }

  /**
   * Si las coordenadas hacen referencia a una <b>CeldaMutable</b>, comprueba si está vacía y, si no
   * es así, procede a vaciarla, decrementando el contador correspondiente
   *
   *
   * @param fila fila de la celda a borrar, comenzando en 1
   * @param col columna de la celda a borrar, comenzando en 1
   * @throws Exception si la celda introducida no del tipo <b>CeldaMutable</b>
   */
  public void borrarCelda(int fila, int col) throws Exception {
    if (this.tablero[fila][col] instanceof CeldaMutable) {
      CeldaMutable celda = (CeldaMutable) this.tablero[fila][col];
      if (!celda.estaVacia()) {
        int numeroPrevio = celda.obtenerNumero();
        celda.borrar();
        this.celdasVacias++;
        this.reintroducirCandidato(fila, col, numeroPrevio);
      }
    } else {
      throw new Exception(INICIAL);
    }
  }

  /**
   * Elimina un número candidato de todas las celdas pertenecientes a la fila, la columna, o el
   * sector determinado por las coordenadas introducidas
   *
   * @param fila entero indicando la fila a actualizar
   * @param col entero indicando la columna a actualizar
   * @param candidato entero indicando el número candidato a eliminar de fila, columna y sector
   */
  public void eliminarCandidato(int fila, int col, int candidato) {

    int sector = this.obtenerSector(fila, col);

    this.borrarCandidatoEnFila(fila, candidato);
    this.borrarCandidatoEnCol(col, candidato);
    this.borrarCandidatoEnSector(sector, candidato);
  }

  /**
   * Recorre una fila eliminando de la lista de candidatos de cada <b>CeldaMutable<b> el número
   * introducido
   *
   * @param fila entero indicando la fila a actualizar
   * @param candidato entero indicando el número candidato a eliminar de las celdas de la fila
   */
  private void borrarCandidatoEnFila(int fila, int candidato) {

    for (int col = 0; col < DIM; col++) {
      if (this.tablero[fila][col] instanceof CeldaMutable) {
        CeldaMutable celda = (CeldaMutable) this.tablero[fila][col];
        celda.borrarCandidato(candidato);
      }
    }
  }

  /**
   * Recorre una columna eliminando de la lista de candidatos de cada <b>CeldaMutable<b> el número
   * introducido
   *
   * @param col entero indicando la columna a actualizar
   * @param candidato entero indicando el número candidato a eliminar de las celdas de la columna
   */
  private void borrarCandidatoEnCol(int col, int candidato) {

    for (int fila = 0; fila < DIM; fila++) {
      if (this.tablero[fila][col] instanceof CeldaMutable) {
        CeldaMutable celda = (CeldaMutable) this.tablero[fila][col];
        celda.borrarCandidato(candidato);
      }
    }
  }

  /**
   * Recorre un sector eliminando de la lista de candidatos de cada <b>CeldaMutable<b> el número
   * introducido
   *
   * @param sector entero indicando el sector a actualizar
   * @param candidato entero indicando el número candidato a eliminar de las celdas del sector
   */
  private void borrarCandidatoEnSector(int sector, int candidato) {

    int filaInicial = this.fInicioSector(sector);
    int columnaInicial = this.cInicioSector(sector);
    int filaFinal = filaInicial + DIM_SECTOR;
    int columnaFinal = columnaInicial + DIM_SECTOR;

    for (int fila = filaInicial; fila < filaFinal; fila++) {
      for (int col = columnaInicial; col < columnaFinal; col++) {
        if (this.tablero[fila][col] instanceof CeldaMutable) {
          CeldaMutable celda = (CeldaMutable) this.tablero[fila][col];
          celda.borrarCandidato(candidato);
        }
      }
    }
  }

  /**
   * Reintroduce, en caso de que sea posible, un candidato en las celdas afectadas por la
   * eliminación del número en la celda con coordenadas fila, col
   *
   * @param fila entero indicando la fila de la celda modificada
   * @param col entero indicando columna de la celda modificada
   * @param candidato entero indicando el número elminiado
   */
  private void reintroducirCandidato(int fila, int col, int candidato) {

    int sector = this.obtenerSector(fila, col);
    HashMap<CeldaMutable, int[]> afectados = this.obtenerAfectados(fila, col, sector);

    for (CeldaMutable celda : afectados.keySet()) {
      boolean afectado;
      afectado = true;
      int[] coordenadas = afectados.get(celda);

      if (fila != coordenadas[0]) {
        if (this.compruebaEnFila(candidato, coordenadas[0])) {
          afectado = false;
        }
      }

      if (col != coordenadas[1]) {
        if (this.compruebaEnColumna(candidato, coordenadas[1])) {
          afectado = false;
        }
      }

      if (sector != coordenadas[2]) {
        if (this.compruebaEnSector(candidato, coordenadas[2])) {
          afectado = false;
        }
      }

      if (afectado) {
        celda.introducirCandidato(candidato);
      }
    }
  }

  /**
   * Obtiene todas las celdas potecialmente afectadas por la eliminación de un número en la celda
   * con coordenadas filaOrigen, colOrigen y ubicado en el sector sectorOrigen
   *
   * @param filaOrigen entero indicando la fila de la celda modificada
   * @param colOrigen entero indicando la columna de la celda modificada
   * @param sectorOrigen entero indicando el sector de la celda modificada
   * @return HashMap donde las claves son referencias a <b>CeldaMutable</b> y los valores arrays de
   * enteros describiendo las coordenadas y sector al que pertenecen
   */
  private HashMap<CeldaMutable, int[]> obtenerAfectados(int filaOrigen, int colOrigen,
      int sectorOrigen) {

    HashMap<CeldaMutable, int[]> afectados = new HashMap<>();

    int filaInicial = this.fInicioSector(sectorOrigen);
    int columnaInicial = this.cInicioSector(sectorOrigen);
    int filaFinal = filaInicial + DIM_SECTOR;
    int columnaFinal = columnaInicial + DIM_SECTOR;

    for (int fila = filaInicial; fila < filaFinal; fila++) {
      for (int col = columnaInicial; col < columnaFinal; col++) {
        if (this.tablero[fila][col] instanceof CeldaMutable) {
          CeldaMutable celda = (CeldaMutable) this.tablero[fila][col];
          afectados.put(celda, new int[]{fila, col, sectorOrigen});
        }
      }
    }

    int sector;

    for (int col = 0; col < DIM; col++) {
      if (this.tablero[filaOrigen][col] instanceof CeldaMutable) {
        CeldaMutable celda = (CeldaMutable) this.tablero[filaOrigen][col];
        sector = this.obtenerSector(filaOrigen, col);
        afectados.put(celda, new int[]{filaOrigen, col, sector});
      }
    }

    for (int fila = 0; fila < DIM; fila++) {
      if (this.tablero[fila][colOrigen] instanceof CeldaMutable) {
        CeldaMutable celda = (CeldaMutable) this.tablero[fila][colOrigen];
        sector = this.obtenerSector(fila, colOrigen);
        afectados.put(celda, new int[]{fila, colOrigen, sector});
      }
    }

    return afectados;
  }

  /**
   * Actualiza el estado del sudoku con la información obtenida en el objeto <b>Sudoku</b> devuelto
   * por el método <i>cargarPartidaSudoku</i> de la clase <b>IO</b>
   *
   * @param archivo cadena conteniendo nombre del archivo a guardar
   * @throws FileNotFoundException si no se encuentra el archivo indicado
   * @throws IOException si se produce un error durante la lectura del archivo
   * @throws Exception si <i>cargarPartidaSudoku</i> tiene problemas al crear el objeto
   * <b>Sudoku</b>
   */
  public void cargar(String archivo) throws FileNotFoundException, IOException, Exception {
    Sudoku nuevo = IO.cargarPartidaSudoku(archivo);

    this.celdasVacias = nuevo.celdasVacias;
    this.celdasIniciales = nuevo.celdasIniciales;
    this.contadorJugadas = nuevo.contadorJugadas;
    this.jugadas = nuevo.jugadas;
    this.tablero = nuevo.tablero;
  }

  public String contenidoCelda(int fila, int col) {
    int numero = tablero[fila][col].obtenerNumero();
    if (numero <= DIM && numero > 0) {
      return String.valueOf(numero);
    } else {
      return "";
    }
  }

  public int[] candidatosCelda(int fila, int col) {
    if (tablero[fila][col] instanceof CeldaMutable) {
      CeldaMutable celda = (CeldaMutable) tablero[fila][col];
      return celda.obtenerCandidatos();
    }
    return new int[0];
  }
}
