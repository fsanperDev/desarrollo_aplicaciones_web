/*
 * Copyright (C) 2017 Gerardo Gómez Puerto <gerardo@nyxe.es>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sudokuProg;

import java.util.HashSet;

/**
 * Celda modificable para juego de sudoku. Alberga un número que puede ser modificado o borrado.
 * Posee una lista de candidatos posibles que puede ser modificada. Posee métodos lógicos que
 * permiten consultar su estado. Implementa su propio método de pintado de contenido con color
 * diferenciado
 *
 * @author Gerardo Gómez Puerto <gerardo@nyxe.es>
 *
 * @version 1.0
 */
public class CeldaMutable extends Celda {

  private HashSet<Integer> candidatos;
  private boolean vacia;

  /**
   * Inicializa la celda a su estado vacío y rellena la lista de candidatos con todos los números
   * posibles, desde 1 hasta Sudoku.DIM
   */
  public CeldaMutable() {
    this.numero = ' ';
    this.vacia = true;
    this.candidatos = new HashSet<>();

    for (int candidato = 1; candidato <= Sudoku.DIM; candidato++) {
      this.candidatos.add(candidato);
    }
  }

  /**
   * La celda es borrada y se actualiza el atributo <i>vacia</i>.
   */
  public void borrar() {
    this.numero = ' ';
    this.vacia = true;
  }

  /**
   * Comprueba si el número dado es candidato propio de la celda
   *
   * @param numero entero con el número a comprobar
   * @return true si es candidato, false si no lo es
   */
  public boolean tieneComoCandidato(int numero) {
    return this.candidatos.contains(numero);
  }

  /**
   * Comprueba si la celda tiene candidatos posibles
   *
   * @return true si los tiene, false si no
   */
  public boolean hayCandidatos() {
    return this.candidatos.size() > 0 ? true : false;
  }

  /**
   * Elimina el candidato indicado de la lista de candidatos
   *
   * @param candidato entero con el número candidato a eliminar
   */
  public void borrarCandidato(int candidato) {
    this.candidatos.remove(candidato);
  }

  /**
   * Introduce el candidato indicado en la lista de candidatos
   *
   * @param candidato entero con el número candidato a introducir
   */
  public void introducirCandidato(int candidato) {
    this.candidatos.add(candidato);
  }

  /**
   * introduce un número en la celda y actualiza el atributo <i>vacia</i>.
   *
   * @param numero entero con el número a introducir en la celda
   */
  public void introducirNumero(int numero) {
    this.numero = numero;
    this.vacia = false;
  }

  /**
   * Muestra los posibles candidatos de la celda
   *
   * @return cadena con los posibles candidatos de la celda
   */
  public String mostrarCandidatos() {
    String salida = String.valueOf(this.candidatos);

    return salida.substring(1, salida.length() - 1);
  }

  public int[] obtenerCandidatos() {
    int[] array = new int[candidatos.size()];
    int indice = 0;

    for (Integer numero : candidatos) {
      array[indice] = numero;
      indice++;
    }
    return array;
  }

  @Override
  public boolean estaVacia() {
    return vacia;
  }
}
