/*
 * Copyright (C) 2017 Gerardo Gómez Puerto <gerardo@nyxe.es>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sudokuProg;

/**
 * Celda inicial no modificable para juego de sudoku. Al ser inicializada recibe un número que no
 * variará a lo largo de la partida. Implementa un método propios de pintado del contenido, que
 * emplea un color diferenciado, y un método propio <i>estaVacia</i>, que siempre devuelve verdadero
 *
 * @author Gerardo Gómez Puerto <gerardo@nyxe.es>
 *
 * @version 1.0
 */
public class CeldaInicial extends Celda {

  /**
   * Crea una celda inicial no modificable.
   *
   * @param numero entero que representa el número que contendrá la celda
   */
  CeldaInicial(int numero) {
    this.numero = numero;
  }

  @Override
  public boolean estaVacia() {
    return false;
  }
}
