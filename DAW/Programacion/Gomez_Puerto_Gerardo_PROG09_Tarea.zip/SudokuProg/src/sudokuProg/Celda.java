/*
 * Copyright (C) 2017 Gerardo Gómez Puerto <gerardo@nyxe.es>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sudokuProg;

/**
 * Plantilla abstracta de celda de tablero de sudoku. Implementa metodos para pintar la celda en
 * tres líneas unicode y un método para devolver el número almacenado. Requiere desarrollar el
 * método <i>estaVacia</i> en clases hijas
 *
 * @author Gerardo Gómez Puerto
 *
 * @version 2.0
 */
public abstract class Celda {

  protected int numero;

  /**
   * Comprueba si la celda está vacía
   *
   * @return true si está vacía, false si no es así
   */
  public abstract boolean estaVacia();

  /**
   * Método de acceso al contenido de la celda
   *
   * @return entero que alberga la celda
   */
  public int obtenerNumero() {
    return this.numero;
  }
}
