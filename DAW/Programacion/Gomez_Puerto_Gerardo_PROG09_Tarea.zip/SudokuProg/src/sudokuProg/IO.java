/*
 * Copyright (C) 2017 Gerardo Gómez Puerto <gerardo@nyxe.es>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sudokuProg;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

/**
 * Gestiona los flujos de entrada/salida de la clase <b>Sudoku</b>
 *
 * @author Gerardo Gómez Puerto <gerardo@nyxe.es>
 *
 * @version 1.2
 */
class IO {

  /**
   * Lee un archivo de texto <i>.sud</i>, lo procesa y devuelve como un array bidimensional que
   * representa el contenido de un tablero de sudoku
   *
   * @param archivo cadena con el nombre del archivo a cargar
   * @return array bidimensional de cadenas representando un tablero de sudoku
   * @throws FileNotFoundException si no se puede localizar el archivo solicitado
   * @throws IOException si se produce una excepción durante la lectura del archivo
   */
  static String[][] cargarTableroSudoku(String archivo) throws FileNotFoundException, IOException {
    String[][] tablero = new String[Sudoku.DIM][];
    BufferedReader lector = new BufferedReader(new FileReader(archivo));

    for (int indice = 0;
        indice < Sudoku.DIM;
        indice++) {
      tablero[indice] = lector.readLine().split(" ");
    }

    lector.close();
    return tablero;
  }

  /**
   * Almacena el estado de un objeto <b>Sudoku</b> en un archivo binario <i>.sdp</i>. El archivo
   * tiene el siguiente formato:
   * <ul>
   * <li>Un byte con el número de celdas iniciales</li>
   * <li>Bloques de tres bytes con la información de cada una de las celdas iniciales:
   * <ul>
   * <li>Fila</li <li>Columna</li> <li>Número</li>
   * </ul>
   * </li>
   * <li>Un byte con el número de jugadas realizadas</li>
   * <li>Bloques de tres bytes con la información de cada una de las jugadas realizadas:
   * <ul>
   * <li>Fila</li> <li>Columna</li> <li>Número</ul></li>
   * <li>Un byte con el número de celdas rellenas por el usuario en el estado actual</li></li>
   * <li>Bloques de tres bytes con la información de cada una de las jugadas realizadas:
   * <ul>
   * <li>Fila</li> <li>Columna</li> <li>Número</ul></li>
   * </li>
   * </ul>
   *
   * @param inicial array bidimensional de enteros describiendo cada celda inicial
   * @param jugadas array bidimiensional de enteros describiendo cada jugada realizada
   * @param estado array bidimensional de enteros describiendo el estado actual del sudoku
   * @param archivo cadena con el nombre del archivo a guardar
   * @throws FileNotFoundException si no es posible crear el archivo
   * @throws IOException si se produce un error durante la escritura del archivo
   */
  static void guardarPartidaSudoku(int[][] inicial, int[][] jugadas, int[][] estado, String archivo)
      throws
      FileNotFoundException, IOException {

    DataOutputStream escritor;
    escritor = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(archivo)));

    escritor.writeByte(inicial.length);

    for (int[] celda : inicial) {
      for (int entero : celda) {
        escritor.writeByte(entero);
      }
    }

    escritor.writeByte(jugadas.length);

    for (int[] jugada : jugadas) {
      for (int entero : jugada) {
        escritor.writeByte(entero);
      }
    }

    escritor.writeByte(estado.length);

    for (int[] descriptor : estado) {
      for (int entero : descriptor) {
        escritor.writeByte(entero);
      }
    }

    escritor.close();
  }

  /**
   * Lee y procesa un archivo binario <i>.sdp</i>, devolviendo un objeto Sudoku cuyo estado es el
   * descrito en el archivo. Dicho archivo tiene el siguiente formato:
   * <ul>
   * <li>Un byte con el número de celdas iniciales</li>
   * <li>Bloques de tres bytes con la información de cada una de las celdas iniciales:
   * <ul>
   * <li>Fila</li <li>Columna</li> <li>Número</li>
   * </ul>
   * </li>
   * <li>Un byte con el número de jugadas realizadas</li>
   * <li>Bloques de tres bytes con la información de cada una de las jugadas realizadas:
   * <ul>
   * <li>Fila</li> <li>Columna</li> <li>Número</ul></li>
   * <li>(Opcional - Nueva versión) Un byte con el número de celdas rellenas por el usuario en el
   * estado actual</li></li>
   * <li>(Opcional - Nueva versión) Bloques de tres bytes con la información de cada una de las
   * jugadas realizadas:
   * <ul>
   * <li>Fila</li> <li>Columna</li> <li>Número</ul></li>
   * </li>
   * </ul>
   *
   * @param archivo el nombre del archivo a leer
   * @return un nuevo objeto <b>Sudoku</b> con el estado almacenado en el archivo
   * @throws FileNotFoundException si no se encuentra el archivo indicado
   * @throws IOException si se produce un error durante la lectura del archivo
   * @throws Exception si se produce un error en la creación del objeto <b>Sudoku</b>
   */
  static Sudoku cargarPartidaSudoku(String archivo) throws FileNotFoundException, IOException,
      Exception {
    DataInputStream lector;
    lector = new DataInputStream(new BufferedInputStream(new FileInputStream(archivo)));

    int[][] inicial = new int[lector.read()][3];

    for (int celda = 0; celda < inicial.length; celda++) {
      for (int indice = 0; indice < 3; indice++) {
        inicial[celda][indice] = lector.read();
      }
    }

    int nJugadas = lector.read(); //Puede haber hasta 255 jugadas
    int[][] jugadas = new int[Sudoku.JUGADAS_MAX][3];

    for (int jugada = 0; jugada < nJugadas; jugada++) {
      for (int indice = 0; indice < 3; indice++) {
        jugadas[jugada][indice] = lector.read();
      }
    }

    int celdasUsuario = lector.read();

    if (celdasUsuario != - 1) {
      int[][] estado = new int[celdasUsuario][3];

      for (int celda = 0; celda < estado.length; celda++) {
        for (int indice = 0; indice < 3; indice++) {
          estado[celda][indice] = lector.read();
        }
      }

      lector.close();
      return new Sudoku(inicial, jugadas, nJugadas, estado);
    }

    // Compatibilidad con partidas guardadas en la versión anterior
    lector.close();
    return new Sudoku(inicial, jugadas, nJugadas);
  }
}
