/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_examen1;

/**
 *
 * @author ANGELA PEREZ
 */
public class Rueda {
   
   // ATRIBUTOS
    
   // CONSTRUCTOR
    
   // METODOS

}
