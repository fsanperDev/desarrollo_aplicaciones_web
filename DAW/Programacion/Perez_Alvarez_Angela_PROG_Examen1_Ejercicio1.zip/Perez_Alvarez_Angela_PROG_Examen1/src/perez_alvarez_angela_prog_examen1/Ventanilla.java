/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_examen1;

/**
 *
 * @author ANGELA PEREZ
 */
public class Ventanilla {
/**
 * En esta clase he puesto que la ventana bajada es false y subida true, por defecto estara subida.
 */      
   // ATRIBUTOS
    private boolean _estadoVentanilla;
   // CONSTRUCTOR
    public Ventanilla(){
        _estadoVentanilla = true;
    }
   // METODOS
   /**
    * Metodo que devuelve el estado de la ventanilla.
    * @return 
    */ 
    public boolean EstadoVentanilla(){
        return _estadoVentanilla;
    }
    /**
     * Metodo para subir la ventanilla subida = false.
     */
    public void SubirVentanilla(){
        _estadoVentanilla = false;
    }
    /**
     * Metodo para bajar la ventanilla bajada = true.
     */
    public void BajarVentanilla(){
        _estadoVentanilla = true;
    }
    
}
