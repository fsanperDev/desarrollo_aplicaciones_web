/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_examen1;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class EntradaSalida {
/**
 * Con esta clase controlo lo que se introduce por teclado durante el programa.
 */
    
    
    /**
     * Metodo para leer un número entero y controlarlo.
     * @return 
     */
        public static int leerEntero (){
        
        Scanner Teclado = new Scanner(System.in);
        int numeroEntero = 0;
        String numeroComoCadena ="";
        boolean correcto = true;
        
        do
        {
            try {
                numeroComoCadena = Teclado.nextLine();
                numeroEntero = Integer.parseInt(numeroComoCadena);
                correcto = true;

            } catch (Exception e) {
                correcto = false;
                System.err.println("Número introducido no correcto");
            }
        }while (!correcto);
        
        return (numeroEntero);        
    }
    
    /**
     * Método que controla que se introduzcan numeros enteros entre un rango.
     * @param menor variable para el numero mas alto.
     * @param mayor variable para el numero mas bajo.
     * @return 
     */
    public static int leerEntreRango (int menor, int mayor){
        
        Scanner miTeclado = new Scanner(System.in);
        int numeroEntero = 0;
        String numeroComoCadena ="";
        boolean correcto = true;
        
        do
        {
            try {
                numeroComoCadena = miTeclado.nextLine();
                numeroEntero = Integer.parseInt(numeroComoCadena);
                if ((numeroEntero < menor) || (numeroEntero > mayor)){
                    System.err.println("Número erroneo... ha de estar entre "+
                                        menor+" y "+mayor+
                                        ". Introduzca número de nuevo");
                    correcto = false;
                } else {
                    correcto = true;
                }                

            } catch (Exception e) {
                correcto = false;
                System.err.println("Número introducido no correcto");
            }
        }while (!correcto);
        
        return (numeroEntero);        
    }
}
