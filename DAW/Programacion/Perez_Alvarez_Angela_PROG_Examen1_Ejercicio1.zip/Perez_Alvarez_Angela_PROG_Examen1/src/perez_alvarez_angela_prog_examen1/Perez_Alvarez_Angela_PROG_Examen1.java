/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_examen1;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_PROG_Examen1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
// CLASE (Como solo puedo llamar a la clase Vehiculo solo instancio una clase)
    Vehiculo vehiculo = new Vehiculo();
// ARRAYS 
    int NUMERO_DE_ELEMENTOS = 1;
    int[] otroVehiculo = new int[NUMERO_DE_ELEMENTOS];
// VARIABLES
    // Todo lo que sea texto a mostrar por pantalla lo introduzco en una variable String.
    boolean salir = false;
    final String MENU_PRINCIPAL = "**** Menú Principal  ***** \n1 - Conocer el estado del vehiculo\n2 - Arrancar vehiculo\n"
            + "3 - Apagar vehiculo\n4 - Puertas \n5 - Configurar otro Vehiculo \n6 - Salir de la aplicación \n";
    int opcionMenu;
    
    //---- AQUI EMPIEZA  --------------------------------------------------------------------------------
    do{
        System.out.println(MENU_PRINCIPAL);
        opcionMenu = EntradaSalida.leerEntreRango(1, 6);
        /**
         * Utilizo un switch para la seleccion de cada una de las opciones del menu, podría haber puesto
         * una variable por cada numero pero voy ahora mas rapido si pongo directamente el numero.
         * Todas las opciones llaman a la clase Vehiculo menos la ultima.
         */
        switch(opcionMenu){
            case 1:
                vehiculo.EstadoVehiculo();
                break;
            case 2:
                vehiculo.ArrancarVehiculo();
                break;
            case 3:
                vehiculo.ApagarVehiculo();
                break;
            case 4:
                vehiculo.MenuPuerta();
                break;
            case 5:
                /**
                 * Sumo al array de otroVehiculo el nuevo vehiculo.
                 */
                NUMERO_DE_ELEMENTOS++;
                break;
            case 6:
                salir = true;
                break;
        }
        
    }while(!salir);    
    }
    
}
