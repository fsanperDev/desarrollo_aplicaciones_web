/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_examen1;

/**
 *
 * @author ANGELA PEREZ
 */
public class Puerta {
    
   // CLASES
    Ventanilla ventana = new Ventanilla();
   // ATRIBUTOS
    private static String _menuPuerta;
    private boolean salir;
    private int _opcionMenuPuerta;
    private boolean _estadoPuerta;
    private String _ventanaAbierta;
    private String _ventanaCerrada;
   // CONSTRUCTOR
    public Puerta(){
        _menuPuerta = "++++ MENU PUERTAS ++++\n1 - Conocer el estado de las puertas.\n2 - Abrir puerta\n3 - Cerrar puerta\n"
                + "4 - Conocer el estado de las ventanillas\n5 - Subir ventanilla\n6 - Bajar ventanilla\n7 - Volver al menu principal\n";
        salir = false;
        _opcionMenuPuerta = 0;
        _estadoPuerta = false;
        _ventanaAbierta = "La ventanilla esta abierta.";
        _ventanaCerrada = "La ventanilla esta cerrada";
    }
   // METODOS
    /**
     * Método que despliega el menu de la clase Puerta.
     */
    public void MenuPuerta(){
        do{
            System.out.println(_menuPuerta);
            _opcionMenuPuerta = EntradaSalida.leerEntreRango(1, 7);
            switch(_opcionMenuPuerta){
                case 1:
                    if(_estadoPuerta == true){
                        System.out.println("La puerta esta abierta.");
                    }else{
                        System.out.println("La puerta esta cerrada.");
                    }
                    break;
                case 2:
                    _estadoPuerta = true;
                    break;
                case 3:
                    _estadoPuerta = false;
                    break;
                case 4:
                    /**
                     * Hago un if para que segun el resultado muestre un texto u otro.
                     */
                    if((ventana.EstadoVentanilla())==false){
                        System.out.println(_ventanaCerrada);
                    }else{
                        System.out.println(_ventanaAbierta);
                    }
                    break;
                case 5:
                    ventana.SubirVentanilla();
                    break;
                case 6:
                    ventana.BajarVentanilla();
                    break;
                case 7:
                    salir = true;
                    break;
            }
        }while(!salir);
    }
   /**
    * Metodo que dedvuelve el estado de la puerta.
    * @return 
    */ 
    public boolean EstadoDePuertas(){
        return _estadoPuerta;
    }
    /**
     * Metodo para abrir la puerta.
     */
    public void AbrirPuerta(){
        _estadoPuerta = true;
    }
    /**
     * Metodo para cerrar la puerta.
     */
    public void CerrarPuerta(){
        _estadoPuerta = false;
    }
}
