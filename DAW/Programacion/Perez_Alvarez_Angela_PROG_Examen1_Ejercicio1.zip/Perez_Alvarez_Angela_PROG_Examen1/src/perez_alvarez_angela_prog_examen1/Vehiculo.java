/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_examen1;

/**
 *
 * @author ANGELA PEREZ
 */
public class Vehiculo {

   // CLASE 
    Puerta puerta = new Puerta();    
   // ATRIBUTOS
     private int _numeroRuedas;
     private int _numeroDePuertas;
     private String _tipoCombustible;
     private String _matricula;
     boolean _estadoVehiculo;
   // CONSTRUCTOR
    public Vehiculo(){
        _numeroRuedas = 0;
        _numeroDePuertas = 0;
        _tipoCombustible = "";
        _matricula = "";
        _estadoVehiculo = false;
    }
   // METODOS
    /**
     * Metodo para ver el estado del vehiculo, True = encendido False = Apagado.
     */
    public void EstadoVehiculo(){
        if(_estadoVehiculo = true){
            System.out.println("El vehiculo esta encendido.");
        }else{
            if(_estadoVehiculo = false){
            System.out.println("El vehiculo esta apagado.");
            }
        }       
    }

    /**
     * Metodo que cambia el valor de _estadoVehiculo a true = encendido.
     */
    public void ArrancarVehiculo(){
        _estadoVehiculo = true;
    }
    /**
     * Metodo que cambia el valor de _estadoVehiculo a false = apagado.
     */
    public void ApagarVehiculo(){
        _estadoVehiculo = false;
    }
    /**
     * Metodo para entrar en el menu de Puertas que está en la clase Puerta.
     */
    public void MenuPuerta(){
        puerta.MenuPuerta();
    }
}
