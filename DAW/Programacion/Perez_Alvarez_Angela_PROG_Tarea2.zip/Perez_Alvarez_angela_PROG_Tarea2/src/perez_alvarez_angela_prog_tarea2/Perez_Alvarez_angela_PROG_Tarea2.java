/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_tarea2;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ ALVAREZ
 */
public class Perez_Alvarez_angela_PROG_Tarea2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       
       // VARIABLES
         boolean salir = false;
         boolean copc2 = false;
         boolean copc3 = false;
         boolean copc4 = false;
         boolean naccesorios = false;
         
         int opc1 = 0;
         int opc2 = 0;
         int opc3 = 0;
         int opc4 = 0;
         int opc5 = 0;
         
         final int baja = 200;
         final int media = 350;
         final int alta = 800;
         
         int lapiz = 1;
         int protector = 1;
         int funda = 1;
         int auriculares = 1;
         int antena = 1;
         int cable = 1;
         
         int accesorio = 0;
         int total = 0;
         String opcionComoCadena = "";
         String so = "ninguno";
         String gama = "ninguno";
       
/**
 * AQUI EMPIEZA EL PROGRAMA
 */
//-----------------------  MENU PRINCIPAL  --------------------------------------------------------------------------------------
       do{
           System.out.println("Bienvenido");
           System.out.println("Pulse 1 para pedir presupuesto");
           System.out.println("Pulse 2 para salir\n");
           
        try {
            opcionComoCadena = teclado.nextLine();
            opc1 = Integer.parseInt(opcionComoCadena);
        }catch (Exception e){
            System.out.println("Error teclado: Se espera un entero");
            opc1 = 0;
        }
           
           
           switch(opc1){
//------------------------ SISTEMAS OPERATIVOS ---------------------------------------------------------------------------------------------
               case 1:
                 do{
                   System.out.println("Eligue un sistema operativo");
                   System.out.println("1. Android");
                   System.out.println("2. IOS");
                   System.out.println("3. Windows");
                   try {
                        opcionComoCadena = teclado.nextLine();
                        opc2 = Integer.parseInt(opcionComoCadena);
                    }catch (Exception e){
                        System.out.println("Error teclado: Se espera un numero entero");
                        opc2 = 0;
                    }
                        switch(opc2){
                            case 1:
                                so = "Android";
                                copc2 = true;
                                break;
                            case 2:
                                so = "IOS";
                                copc2 = true;
                                break;
                            case 3:
                                so = "Windows";
                                copc2 = true;
                                break;
                            default:
                                System.out.println("Numero introducido incorrecto");
                                break;
                        }
                   }while(!copc2);
//--------------------- GAMA DE TELEFONOS -------------------------------------------------------------------------------------------
                   do{
                   System.out.println("Eligue la gama de telefono que desea");
                   System.out.println("1. Gama Baja - 200€");
                   System.out.println("2. Gama Media - 350€");
                   System.out.println("3. Gama Alta - 800€");
                   try {
                        opcionComoCadena = teclado.nextLine();
                        opc3 = Integer.parseInt(opcionComoCadena);
                    }catch (Exception e){
                        System.out.println("Error teclado: Se espera un numero entero");
                        opc3 = 0;
                    }
                    switch(opc3){
                            case 1:
                                gama = "Baja";
                                total = total + baja;
                                copc3 = true;
                                break;
                            case 2:
                                gama = "Media";
                                total = total + media;
                                copc3 = true;
                                break;
                            case 3:
                                gama = "Alta";
                                total = total + alta;
                                copc3 = true;
                                break;
                            default:
                                System.out.println("Numero introducido incorrecto");
                                break;
                        }
                    }while(!copc3);
//--------------------------  ACCESORIOS  ----------------------------------------------------------------------------------
                    do{
                        System.out.println("¿Deseas algún accesorio? (Puedes elegir un maximo de 3 accesorios,"
                                + "si no deseas ninguno selecciona 0)\n");
                        naccesorios = true;
                        try {
                             opcionComoCadena = teclado.nextLine();
                             accesorio = Integer.parseInt(opcionComoCadena);
                         }catch (Exception e){
                             System.out.println("Error teclado: Se espera un numero entero");
                             naccesorios = false;
                         }
                         if(accesorio >= 4){naccesorios = false;}
                         if(accesorio < 0){naccesorios = false;}
                    }while(!naccesorios);
                    do{                        
                        while(accesorio > 0){
                                System.out.println(" Accesorios disponibles: ");
                                System.out.println(" 1  Lápiz - 3€ ");
                                System.out.println(" 2  Protector de pantalla - 6€ ");
                                System.out.println(" 3  Funda - 10€ ");
                                System.out.println(" 4  Auriculares - 15€ ");
                                System.out.println(" 5  Antena FM - 2€ ");
                                System.out.println(" 6  Cable lector USB - 8€ \n");
                                
                                try {
                                    opcionComoCadena = teclado.nextLine();
                                    opc5 = Integer.parseInt(opcionComoCadena);
                                }catch (Exception e){
                                    System.out.println("Error teclado: Se espera un entero");
                                    opc5 = 0;
                                }
                                
                                switch(opc5){
                                    case 1:
                                        if(lapiz > 0){
                                            lapiz = lapiz - 1;
                                            total = total + 3;
                                            accesorio = accesorio - 1;
                                        }else{
                                            System.out.println("Ya has elegido este accasorio");
                                        }
                                        break;
                                    case 2:
                                        if(protector > 0){
                                            protector = protector - 1;
                                            total = total + 6;
                                            accesorio = accesorio - 1;
                                        }else{
                                            System.out.println("Ya has elegido este accasorio");
                                        }
                                        break;
                                    case 3:
                                        if(funda > 0){
                                            funda = funda - 1;
                                            total = total + 10;
                                            accesorio = accesorio - 1;
                                        }else{
                                            System.out.println("Ya has elegido este accasorio");
                                        }
                                        break;
                                    case 4:
                                        if(auriculares > 0){
                                            auriculares = auriculares - 1;
                                            total = total + 15;
                                            accesorio = accesorio - 1;
                                        }else{
                                            System.out.println("Ya has elegido este accasorio");
                                        }
                                        break;
                                    case 5:
                                        if(antena > 0){
                                            antena = antena - 1;
                                            total = total + 2;
                                            accesorio = accesorio - 1;
                                        }else{
                                            System.out.println("Ya has elegido este accasorio");
                                        }
                                        break;
                                    case 6:
                                        if(cable > 0){
                                            cable = cable - 1;
                                            total = total + 8;
                                            accesorio = accesorio - 1;
                                        }else{
                                            System.out.println("Ya has elegido este accasorio");
                                        }
                                        break;
                                    default:
                                        System.out.println("Se esperaba un numero entre 1 y 6");
                                }                                
                            }
                        
                        if (accesorio == 0){
                            copc4 = true;
                        }
                    }while(!copc4);
//--------------------------  VOLVER AL MENU PRINCIPAL ---------------------------------------------------------------------------
                    System.out.println(" - Presupuesto - ");
                    System.out.println("Sistema operativo elegido: "+so);
                    System.out.println("Gama del movil elegida: "+gama);
                    System.out.println("Accesorios elegidos:");
                    if(lapiz == 0){System.out.println("- Lapiz");}
                    if(protector == 0){System.out.println("- Protector de pantalla");}
                    if(funda == 0){System.out.println("- Funda");}
                    if(auriculares == 0){System.out.println("- Auriculares");}
                    if(antena == 0){System.out.println("- Antena FM");}
                    if(cable == 0){System.out.println("- Cable lector USB");}
                    System.out.println("Total: "+total+"€\n");
                    
                   break;
               case 2:
                   salir = true;
                   break;
               default: 
                   System.out.println("Numero introducido incorrecto, por favor, introduce 1 o 2");
                   break;
               }    
       }while(!salir);
       System.out.println("Adios");
    }
    
}
