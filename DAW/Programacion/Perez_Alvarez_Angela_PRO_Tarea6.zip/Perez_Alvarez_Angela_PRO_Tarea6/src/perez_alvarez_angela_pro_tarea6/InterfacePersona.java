/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea6;

/**
 *
 * @author ANGELA PEREZ
 */
public interface InterfacePersona {
    /**
     * Sirve para dar de Alta.
     * @return 
     */
    String darDeAlta();
    /**
     * Sirva para mostrar todos los datos de una persona.
     * @return 
     */
    String mostrar();
}
