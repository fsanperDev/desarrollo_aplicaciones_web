/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea6;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class Alumno extends Persona{
    Scanner teclado = new Scanner(System.in);
    
// ATRIBUTOS
    protected int _curso;
    protected int _numeroTelefono;
    private String _txt_nombre = "Nombre: ";
    private String _txt_apellidos = "Apellidos: ";
    private String _txt_dni = "DNI:";
    private String _txt_edad = "Edad:";
    private String _txt_curso = "Curso(solo hay de 1º a 4º) :";
    private String _txt_telefono = "Telefono de contacto:";

// METODOS
    /**
     * Metodo para  dar de alta a un Alumno.
     * @return 
     */
    @Override
    public String darDeAlta() {
        
        String alumno = "";// Variable donde guardaremos luego todos los datos.
        
        // Primero recopilamos los datos.
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_nombre);
        _nombre = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_apellidos);
        _apellidos = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_dni);
        _dni = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_edad);
        _edad = Auxiliar.leerEntero();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_curso);
        _curso = Auxiliar.leerEntero(1, 4);
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_telefono);
        _numeroTelefono = Auxiliar.leerEntero();
        
        // Ahora se preparan para introducirlos en una sola variable.
        alumno += Auxiliar.AZUL+" Nombre del Alumno: "+_nombre+"\n";
        alumno += Auxiliar.AZUL+"Apellidos: "+_apellidos+"\n";
        alumno += Auxiliar.AZUL+"DNI: "+_dni+"\n";
        alumno += Auxiliar.AZUL+"Curso actual: "+_curso+"\n";
        alumno += Auxiliar.AZUL+"Edad: "+_edad+"\n";
        alumno += Auxiliar.AZUL+"Telefono de contacto: "+_numeroTelefono+"\n";
        
        return alumno;
    }
    /**
     * Método que muestra los datos del Alumno.
     * @return 
     */
    @Override
    public String mostrar() {
        return (Auxiliar.AZUL+super.mostrar()+"\n Curso: "+_curso+"º \n Telefono: "+_numeroTelefono);
    }
}
