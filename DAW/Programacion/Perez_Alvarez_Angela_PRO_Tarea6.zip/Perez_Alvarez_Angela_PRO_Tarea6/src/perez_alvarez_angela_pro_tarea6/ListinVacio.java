/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea6;

/**
 * Excepcion que indica que el listin está vacio.
 * @author ANGELA PEREZ
 */
public class ListinVacio extends Exception{
    public ListinVacio (){
        super("El listín esta vacio.");
    }
}
