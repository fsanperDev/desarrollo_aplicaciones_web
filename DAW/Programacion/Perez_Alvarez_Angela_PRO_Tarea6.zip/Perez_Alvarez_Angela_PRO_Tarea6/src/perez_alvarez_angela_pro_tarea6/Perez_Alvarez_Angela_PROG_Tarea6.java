/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea6;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_PROG_Tarea6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // CLASES
    Scanner teclado = new Scanner(System.in);
    Alumno alumno = new Alumno();
    PFuncionario funcionario = new PFuncionario();
    PInterino interino = new PInterino();
    PersonalLaboral plaboral = new PersonalLaboral();
    // ARRAY
    String[] listin = new String[100];
    // ATRIBUTOS
    int opcion;
    int opcion2;
    boolean salir = false;
    int numeroDePersonas = 0;
    String dato = "";
    final String txt_menu = "*****  LISTÍN DE CENTRO  ****** \n 1. Mostrar todo el lintín.\n 2. Alta en el listín.\n"
            + "3. Baja en el listín.\n  4. Salir de la aplicación.\n";
    final String txt_darDeAlta = "¿A quien quieres dar de alta?\n 1. Alumno.\n 2. Profesor Funcionario.\n 3. Profesor Interino.\n"
            + "4. Personal Laboral.\n ";
    final String txt_darDeBaja = "¿Estas seguro que desea darle de baja?\n 1 - SI\n 2 - NO\n";
    //--------------------   EMPIEZA AQUI   -----------------------------------------------------------------------------
        do {
            Auxiliar.pantalla(Auxiliar.NEGRO, txt_menu);
            opcion = Auxiliar.leerEntero(1, 4);
            switch(opcion){
            //-----------------------------  MOSTRAR EL LISTIN  --------------------------------------------------------------------------------
                case 1:
                    // Se comprueba que el listin no esté vacio.
                    try{
                        if(numeroDePersonas == 0){
                            // Si está vacio salta la excepcion.
                            throw new ListinVacio();
                        }else{
                            // Si no está vacio lo muestra.
                            for (int i = 0; i < numeroDePersonas; i++) {
                                if (listin[i] != null) {
                                    Auxiliar.pantalla(Auxiliar.NEGRO,listin[i]+"\n");
                                }                                
                            }
                        }
                    }catch(ListinVacio ex){
                        System.err.println(ex.getMessage());
                    }
                    break;
            //-----------------------------  DAR DE ALTA  ---------------------------------------------------------------------------------
                case 2: 
                    // Preguntamos el tipo de persona que se va a insertar en el listin.
                    Auxiliar.pantalla(Auxiliar.NEGRO, txt_darDeAlta);
                    opcion = Auxiliar.leerEntero(1, 4);
                    switch(opcion){
                        case 1:
                            /* Llamamos al metodo darDeAlta que nos devolvera un String con todos los datos y 
                               lo guardamos en una variable. */ 
                            String personaDelListin = alumno.darDeAlta();
                            // Buscara una pocision vacia y guardará los datos.
                            for (int i = 0; i <= numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = personaDelListin;
                                }
                            }
                            //Sumamos 1 al numero de personas que hay en el listin. 
                            numeroDePersonas++;
                            break;
                        case 2:
                            String PfuncionarioDelListin = funcionario.darDeAlta();
                            for (int i = 0; i <= numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = PfuncionarioDelListin;
                                }
                            }
                            numeroDePersonas++;
                            break;
                        case 3:
                            String PinterinoDelListin = interino.darDeAlta();
                            for (int i = 0; i <= numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = PinterinoDelListin;
                                }
                            }
                            numeroDePersonas++;
                            break;
                        case 4:
                            String PLaboralDelListin = plaboral.darDeAlta();
                            for (int i = 0; i <= numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = PLaboralDelListin;
                                }
                            }
                            numeroDePersonas++;
                            break;
                    }
                    break;
            //--------------------------------  DAR DE BAJA  -------------------------------------------------------------------------
                case 3:
                    do {
                        // Mostrar todo el listin.
                        for (int i = 0; i < numeroDePersonas; i++) {
                            System.out.println(Auxiliar.NEGRO+(i)+" - "+listin[i]+"\n");
                        }
                        // Selecciona el numero de la persona que desea dar de baja.
                        opcion = Auxiliar.leerEntero(0, 100);
                        // Preguntar si realmente desea eliminarlo.
                        System.out.println(txt_darDeBaja+listin[opcion]);
                        opcion2 = Auxiliar.leerEntero(1, 2);
                        if(opcion2 == 1){
                            listin[opcion] = null;
                            salir = true;
                        }else{
                           salir = true; 
                        }                        
                    } while (!salir); 
                    salir = false;
                    break;
            //---------------------------------------  SALIR  ----------------------------------------------------------------------
                case 4:
                    salir = true;
                    break;
            }
        } while (!salir);  
    
    }
    
}
