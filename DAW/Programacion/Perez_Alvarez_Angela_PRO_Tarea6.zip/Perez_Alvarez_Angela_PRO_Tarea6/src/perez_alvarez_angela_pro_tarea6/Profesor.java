/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea6;

/**
 *
 * @author ANGELA PEREZ
 */
public abstract class Profesor extends Persona{
// ATRIBUTOS
    protected int _idProfesor;
    protected String _especialidad;
    
    static float _salarioBaseMensual = 1000;
// METODOS   
    /**
     * Salario mensual base.
     * @return 
     */
    abstract public float salarioMensual();
}
