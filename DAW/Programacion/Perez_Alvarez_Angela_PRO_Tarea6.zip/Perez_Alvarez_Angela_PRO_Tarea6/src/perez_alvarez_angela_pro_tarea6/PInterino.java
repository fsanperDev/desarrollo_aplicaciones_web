/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea6;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class PInterino extends Profesor{
    Scanner teclado = new Scanner(System.in);
// ATRIBUTOS
    protected boolean _vacante;
    private String _txt_nombre = "Nombre: ";
    private String _txt_apellidos = "Apellidos: ";
    private String _txt_dni = "DNI:";
    private String _txt_edad = "Edad:";
    private String _txt_vacante = "Vacante :";
// METODOS
    /**
     * Metodo para  dar de alta a un Profesor Interino.
     * @return 
     */
    @Override
    public String darDeAlta() {
        
        String Pinterino = "";// Variable donde guardaremos luego todos los datos.
        
        // Primero recopilamos los datos.
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_nombre);
        _nombre = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_apellidos);
        _apellidos = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_dni);
        _dni = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_edad);
        _edad = Auxiliar.leerEntero();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_vacante);
        _vacante = Auxiliar.VerdaderoFalso();
        
        // Ahora se preparan para introducirlos en una sola variable.
        Pinterino += Auxiliar.ROJO+" Nombre del Alumno: "+_nombre+"\n";
        Pinterino += Auxiliar.ROJO+"Apellidos: "+_apellidos+"\n";
        Pinterino += Auxiliar.ROJO+"DNI: "+_dni+"\n";
        Pinterino += Auxiliar.ROJO+"Edad: "+_edad+"\n";
        Pinterino += Auxiliar.ROJO+"Disponibilidad de la vacante: "+_vacante+"\n";
        
        return Pinterino;
    }
    
    /**
     * Método para mostrar los datos del profesor interino.
     * @return 
     */
    @Override
    public String mostrar(){
        return (Auxiliar.ROJO+super.mostrar()+"\n Vacante disponible: "+_vacante);
    }
    /**
     * Metodo que devuelve el salario mensual del profesor interino.
     * @return 
     */
    @Override
    public float salarioMensual() {
         return (Profesor._salarioBaseMensual);
    }
    
}
