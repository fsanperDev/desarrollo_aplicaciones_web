/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exejercicio1;

/**
 *
 * @author ANGELA PEREZ
 */
public class Ventana {
    
    int _vent1 = 0;
    int _vent2 = 0;
    int _vent3 = 0;
    String _c = "Cerrada";
    String _a = "Abierta";
   
  /**
   * Estado de la ventana 1 en texto
   * @return 
   */
    String EstadoVentana1 (){
        if(_vent1==0){
            return _c;
        }else{
            return _a;
        }  
    }
    
 /**
  * Estado de la ventana 2 en texto
  * @return 
  */
    String EstadoVentana2 (){
       if(_vent2==0){
            return _c;
        }else{
            return _a;
        }  
    }
    
 /**
  * Estado de la ventana 3 en texto
  * @return 
  */
    String EstadoVentana3 (){
        if(_vent1==0){
            return _c;
        }else{
            return _a;
        }  
    }
    
/**
 * Abre la ventana 1
 */
    void Abrirvent1(){
        _vent1++;
    }
    
 /**
  * Abre la ventana 2
  */
    void Abrirvent2(){
        _vent2++;
    }
    
 /**
  * Abre la ventana 3
  */
    void Abrirvent3(){
        _vent3++;
    }
    
/**
 * Cierra la ventana 1
 */
    void Cerrarvent1(){
        _vent1--;
    }
 /**
  * Cierra la ventana 2
  */
    void Cerrarvent2(){
        _vent2--;
    }
 /**
  * Cierra la ventana 3
  */
    void Cerrarvent3(){
        _vent3--;
    }
    
}
