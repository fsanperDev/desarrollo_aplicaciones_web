/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exejercicio1;

/**
 *
 * @author ANGELA PEREZ
 */
public class Calefaccion {
    
    int _encender;
    int _apagar;
    private int _seleccionarTemperatura;
    int _estado;
    String _a = "La calefaccion esta apagada";
    String _e = "La calefaccion esta encendida";
    int _temperatura = 25;
    int valor = 0;
    
   
   /**
    * Encender: Le damos a Estado el valor uno de encendido
    */
   public void Encender(){
       _estado = 1;
   }
   
 /**
  * Apagar: Le damos a Estado el valor cero de apagado
  */
   public void Apagar(){
       _estado = 0;
   }
   
/**
 * Estado: Muestra si esta encendida o apagada, dependiendo de si el valor es 1 o 0, y devuelde el mensaje.
 * @return 
 */
    String Estado (){
       _estado = valor;
       if (valor == 0){
           return _a;
       }else {
          return _e; 
       }
   }
    
/**
 * Aumenta en uno la temperatura
 * 
 */ 
    void SubTemperatura(){
        _temperatura++;
    }
    
/**
 * Disminulle en uno la temperatura
 */
    void BajTemperatura(){
        _temperatura--;
    }
    
}
