/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exejercicio1;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class ExEjercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
     Scanner scan=new Scanner(System.in);
     Scanner teclado = new Scanner(System.in);
     Ventana ventana = new Ventana();
     Persiana persiana = new Persiana();
     Calefaccion calefaccion = new Calefaccion();
     
     //Variables
       int opcion = 0;
       boolean errorDeEntrada = false;
     //menu ventanas
       int opc2 = 0;
       int nv = 0;
     //menu de calefaccion
       int opc3 = 0;
       int opc4 = 0;
     
     
     //Inicio de programa
    
     do{
        System.out.println("MENU");
        System.out.println("1. Manipular ventanas");
        System.out.println("2. Manipular calefaccion");
        System.out.println("3. Salir");
        //comprobar que introduce el valor correcto
        try{
              opcion = Integer.parseInt(teclado.nextLine());
                if ((opcion >=1)&&(opcion <=3)) {                       
                    errorDeEntrada = false;
                } else {
                    System.out.println("Opción elegida no valida..");
                    errorDeEntrada = true;
                }
            }catch (Exception e) {
                System.out.println("Error al insertar opcion....");
                errorDeEntrada = true;
               
            } while (errorDeEntrada);
        //Menu de ventanas
         if(opcion==1){
                System.out.println("1. Conocer el estado de las ventanas");
                System.out.println("2. Abrir ventana");
                System.out.println("3. Cerrar ventana");
                System.out.println("4. Estado de la persiana");
                System.out.println("5. Subir persiana");
                System.out.println("6. Bajar persianas");
                opc2 = Integer.parseInt(teclado.nextLine());
             
             switch(opc2){
                case 1:
                  //Ver estado de las ventanas llamando a la clase
                  System.out.println("El estado de la ventana 1 es: "+ventana.EstadoVentana1());  
                  System.out.println("El estado de la ventana 2 es: "+ventana.EstadoVentana2());
                  System.out.println("El estado de la ventana 3 es: "+ventana.EstadoVentana3());
                      break;
                case 2:
                   //Comprobar que introduce el numero correcto y utilizar la clase para aumentar el valor de la ventana
                    System.out.println("¿Que ventana deseas abrir?");
                    nv = Integer.parseInt(teclado.nextLine());
                    if((nv<0)&&(nv>3)){
                       System.out.println("Esa ventana no existe, vuelve a introducir un numero");
                       break;
                    }
                    if(nv==1){
                        ventana.Abrirvent1();
                    }
                    if(nv==2){
                        ventana.Abrirvent2();
                    }
                    if(nv==3){
                        ventana.Abrirvent3();
                    }
                    break;
                case 3:
                    System.out.println("¿Que ventana deseas cerrar?");
                    nv = Integer.parseInt(teclado.nextLine());
                    if((nv<0)&&(nv>3)){
                       System.out.println("Esa ventana no existe, vuelve a introducir un numero");
                       break;
                    }
                    if(nv==1){
                        ventana.Cerrarvent1();
                    }
                    if(nv==2){
                        ventana.Cerrarvent2();
                    }
                    if(nv==3){
                        ventana.Cerrarvent3();
                    }
                    break;
                case 4:
                 //Persianas
                  System.out.println("El estado de la persiana 1 es: "+persiana.EstadoPersiana1());  
                  System.out.println("El estado de la persiana 2 es: "+persiana.EstadoPersiana2());
                  System.out.println("El estado de la persiana 3 es: "+persiana.EstadoPersiana3());
                       break;
                case 5:
                    System.out.println("¿Que persiana deseas subir?");
                    nv = Integer.parseInt(teclado.nextLine());
                    if((nv<0)&&(nv>3)){
                       System.out.println("Esa persiana no existe, vuelve a introducir un numero");
                       break;
                    }
                    if(nv==1){
                        persiana.Abrirpers1();
                    }
                    if(nv==2){
                        persiana.Abrirpers2();
                    }
                    if(nv==3){
                        persiana.Abrirpers3();
                    }
                    break;
                case 6:
                    System.out.println("¿Que persiana deseas bajar?");
                    nv = Integer.parseInt(teclado.nextLine());
                    if((nv<0)&&(nv>3)){
                       System.out.println("Esa persiana no existe, vuelve a introducir un numero");
                       break;
                    }
                    if(nv==1){
                        persiana.Cerrarpers1();
                    }
                    if(nv==2){
                        persiana.Cerrarpers2();
                    }
                    if(nv==3){
                        persiana.Cerrarpers3();
                    }
                    break;
            }
             
         }
          //Menu calefaccion
           if(opcion==2){
                System.out.println("1. Encender la calefaccion");
                System.out.println("2. Apagar la calefaccion");
                System.out.println("3. Estado de la calefaccion");
                System.out.println("4. Ajustar la temperatica de la calefaccion");
                opc3 = Integer.parseInt(teclado.nextLine());
             switch(opc3){
                case 1:
                    calefaccion.Encender();
                    break;
                case 2:
                    calefaccion.Apagar();
                    break;
                case 3:
                    System.out.println(calefaccion.Estado());
                    break;
                case 4:
                    System.out.println("¿Deseas aumentar o disminuir la temperatura?");
                    System.out.println("1. Aumentar");
                    System.out.println("2. Disminuir");
                    opc4 = Integer.parseInt(teclado.nextLine());
                      if (opc4 == 1){
                          calefaccion.SubTemperatura();
                          break;
                        }
                      if (opc4 == 2){
                          calefaccion.BajTemperatura();
                          break;
                        }
             }
            }
           
       }while(opcion==3);
         
    }
    
}
