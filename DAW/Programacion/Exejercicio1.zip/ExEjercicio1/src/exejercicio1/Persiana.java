/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exejercicio1;

/**
 *
 * @author ANGELA PEREZ
 */
public class Persiana {
    
    int _pers1 = 0;
    int _pers2 = 0;
    int _pers3 = 0;
    String _c = "Cerrada";
    String _a = "Abierta";
    
 /**
  * Estado de la persiana 1 en texto
  * @return 
  */
    String EstadoPersiana1 (){
        if(_pers1==0){
            return _c;
        }else{
            return _a;
        }  
    }
    
  /**
   * Estado de la persiana 2 en texto
   * @return 
   */
    String EstadoPersiana2 (){
       if(_pers2==0){
            return _c;
        }else{
            return _a;
        }  
    }
    
 /**
  * Estado de persiana 3 en texto
  * @return 
  */
    String EstadoPersiana3 (){
        if(_pers1==0){
            return _c;
        }else{
            return _a;
        }  
    }
    
 /**
  * Sube la persiana 1
  */
    void Abrirpers1(){
        _pers1++;
    }
    
  /**
   * Sube la persiana 2
   */
    void Abrirpers2(){
        _pers2++;
    }
    
 /**
  * Sube la persiana 3
  */
    void Abrirpers3(){
        _pers3++;
    }
    
 /**
  * Baja la persiana 1
  */
    void Cerrarpers1(){
        _pers1--;
    }
 /**
  * Baja la persiana 2
  */
    void Cerrarpers2(){
        _pers2--;
    }
 /**
  * Baja la persiana 3
  */
    void Cerrarpers3(){
        _pers3--;
    }
   
}
