/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ex_2ºt;

/**
 *
 * @author FENRIR
 */
public class Excepcion {
    
    static public class ParkingLlenoExcepcion extends Exception{
        public ParkingLlenoExcepcion(){
            super("El parking está lleno de vehiculos. No es posible introducir mas.");
        }
    }
    
}
