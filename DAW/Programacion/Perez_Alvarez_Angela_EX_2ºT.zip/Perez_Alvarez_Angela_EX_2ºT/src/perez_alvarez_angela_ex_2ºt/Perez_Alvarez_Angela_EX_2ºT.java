/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ex_2ºt;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_EX_2ºT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Parking parking = new Parking();
        
        boolean salir = false;
        int opcion = 0;
        final String txt_menu = "**** MENU_PARKING ******\n1. Cargar desde código.\n2. Cargar desde fichero.\n"
                + "3. Guardar datos del parking en fichero.\n4. Entrada de vehiculo en parking(Memorioa volátil)\n"
                + "Salida de vehiculo en parking(Memorioa volátil)\n6. Mostrar vehículos en el parking.\n"
                + "7. Salir de la aplicación.";
        
        do {            
            System.out.println(txt_menu);
            opcion = EntradaSalida.leerEntero(1, 7);
            
            switch(opcion){                
                case 1:
                    break;
                case 2:
                    parking.CargarFichero();
                    break;
                case 3:
                    parking.GuardarEnFichero();
                    break;
                case 4:
                    parking.entradaDeVehiculo();
                    break;
                case 5:
                    parking.SalidaDeVehiculo();
                    break;
                case 6:
                    parking.MostrarVehiculos();
                    break;
                case 7:
                    salir = true;
                    break;
            }            
        } while (!salir);
        
        
    }
    
}
