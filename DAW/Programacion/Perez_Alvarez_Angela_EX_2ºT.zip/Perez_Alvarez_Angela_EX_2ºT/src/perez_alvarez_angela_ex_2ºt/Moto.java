/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ex_2ºt;

/**
 *
 * @author FENRIR
 */
final class Moto extends Vehiculo{
    
    final static String[] _estilo = {"Sport", "Chopper","Scooter"};
    private double _precioPorDia = 10;
    
    public Moto(String matricula, String nombre, int telefono, int diaDeEntrada, String estilo){
        super(matricula, nombre, telefono, diaDeEntrada);
    }

    
    @Override
    public int fechaDeEntrada() {
        return super._diaDeEntrada;
        
    }
    
    @Override
    public String fechaDeSalida() {
        String importe = "";
        int diaSalida = 0;
        int totalDias = 0;
        
        System.out.println("Día de salida: ");
        diaSalida = EntradaSalida.leerEntero(1, 31);
        totalDias = diaSalida - _diaDeEntrada;
        
        totalDias = totalDias * 10;
        
        importe += "El total del importe es de :"+totalDias+"€";
        
        return importe; 
    }
}
