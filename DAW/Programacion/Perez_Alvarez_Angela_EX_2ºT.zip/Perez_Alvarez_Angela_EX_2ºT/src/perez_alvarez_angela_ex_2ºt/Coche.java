/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ex_2ºt;

import java.util.Scanner;

/**
 *
 * @author FENRIR
 */
public class Coche extends Vehiculo{
    Scanner teclado = new Scanner(System.in);
    
    final static int _grande = 0;
    final static int _mediano = 1;
    final static int _pequeño = 2;
    protected double _tamano;
    
    final static double[] _precioPorDia = {30, 20, 20};

    
    public Coche(String matricula, String nombre, int telefono, int diaDeEntrada, double tamaño){
        super(matricula, nombre, telefono, diaDeEntrada);
        tamaño = _tamano;
    }

    
    public String EntradaCoche(){
        String vehiculo = "";
        System.out.println("Nombre: ");
        _nombre = teclado.nextLine();
        System.out.println("Matricula: ");
        this._matricula = teclado.nextLine();
        System.out.println("Telefono: ");
        this._telefono = EntradaSalida.leerEntero();
        System.out.println("EL vehiculo es  ¿1.Grande 2.Mediano 3.Pequeño?");
        _tamano = EntradaSalida.leerEntero(1, 3);
        _tamano--; //EL array empieza en 0.
        System.out.println("Introduce el dia de entrada (solo día)");
        this._diaDeEntrada = EntradaSalida.leerEntero(1, 31);
        
        vehiculo += "Nombre: "+_nombre+" Metricula: "+_matricula+" telefono: "+_telefono;
        
        return vehiculo;        
    }
    
    @Override
    public int fechaDeEntrada() {
        return super._diaDeEntrada;
        
    }
    
    @Override
    public String fechaDeSalida() {
        String importe = "";
        int diaSalida = 0;
        int totalDias = 0;
        
        System.out.println("Día de salida: ");
        diaSalida = EntradaSalida.leerEntero(1, 31);
        totalDias = diaSalida - _diaDeEntrada;
        
        if(_tamano == 0){
            totalDias = totalDias * 30;
        }else{
            totalDias = totalDias * 20;
        }
        
        importe += "El total del importe es de :"+totalDias+"€";
        
        return importe; 
    }
    
}
