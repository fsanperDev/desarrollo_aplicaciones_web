/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ex_2ºt;

/**
 *
 * @author FENRIR
 */ 
public abstract class Vehiculo implements InterfaceParking {

    protected String _matricula;
    protected String _nombre;
    protected int _telefono;
    protected int _diaDeEntrada;
    
    
    public Vehiculo(String matricula, String nombre, int telefono, int diaDeEntrada){
        _matricula = matricula;
        _nombre = nombre;
        _telefono = telefono;
        _diaDeEntrada = diaDeEntrada;
    }
    
    @Override
    public int fechaDeEntrada() {       
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String fechaDeSalida() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
