/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ex_2ºt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author FENRIR
 */
public class Parking {
    
    private Coche coche = new Coche();
    
    private String[] parkingDeVehiculos = new String[100];
    
    private int _numVehiculos;
    private int _numCoches;
    private int _numMotos;
    private int _opcion2;
    private boolean salir = false;
    
    private int _opcion;
    private String _txt_entradaVehiculo = "¿Que tipo de vehiculo desea introducir? 1.Coche 2.Moto";
    
    Parking(){
        _numVehiculos = 0;
        _numCoches = 0;
        _numMotos = 0;
    }
    
//------------------------------------------------------------------------------------------------------------------    
    public void MostrarVehiculos(){
        /**
         * Primero compruebo de que hay vehiculos en el array, en caso de que no salta u  mensaje.
         */
        if (_numVehiculos == 0) {
            System.err.println("NO hay vehiculos en el parking.");
        }else{
            for (int i = 0; i < _numVehiculos; i++) {
                System.out.println(parkingDeVehiculos[i]+"\n");
            }
        }
    }
//------------------------------------------------------------------------------------------------------------------
    public void cargarVehiculos(){
    // No me ha dado tiempo.
       // parkingDeVehiculos[0] = new Coche("Juan","123456799T", 456789789, 2, 12);
        //parkingDeVehiculos[0] = new Moto();
    }
// ----------------------------------------------------------------------------------------------------------   
    public void entradaDeVehiculo(){
        try {
        /**
         * Comprueba si el parking esta lleno, saltara la excepcion.
         */
            if(_numVehiculos == 100){
                throw new Excepcion.ParkingLlenoExcepcion();
            }else{
                System.out.println(_txt_entradaVehiculo);
                _opcion = EntradaSalida.leerEntero(1, 2);
                switch(_opcion){
                    case 1:
                        String nuevoVehiculo = coche.EntradaCoche();
                        for (int i = 0; i < _numVehiculos; i++) {
                            parkingDeVehiculos[1] = nuevoVehiculo;
                        }
                        _numVehiculos++;
                        _numCoches++;
                        break;
                    case 2:
                        // Solo te he hecho el coche como prueba. La moto seria igual pero con la clase Moto.
                        break;
                }
            }
        } catch (Excepcion.ParkingLlenoExcepcion e) {
            System.err.println(e.getMessage());
        }
    }
//------------------------------------------------------------------------------------------------------------------
    public void SalidaDeVehiculo(){
        int contador = 0;
           do {
// Mostrar todo el listin.
        for (int i = 0; i < _numVehiculos; i++) {
            System.out.println(contador+" - "+parkingDeVehiculos[i]+"\n");
                contador++;
        }
// Selecciona el numero de la persona que desea dar de baja.
        _opcion = EntradaSalida.leerEntero(0, 100);
// Preguntar si realmente desea eliminarlo.
        System.out.println("Entas seguro de que quieres eliminar a "+parkingDeVehiculos[_opcion]);
        _opcion2 = EntradaSalida.leerEntero(1, 2);
            if(_opcion2 == 1){
                //listin[_opcion] = null;
                for (int i = _opcion; i < _numVehiculos; i++) {
                    parkingDeVehiculos[i] = parkingDeVehiculos[i+1];
                }
                _numVehiculos--;
                salir = true;
            }else{
                salir = true; 
            }                        
            } while (!salir);  
    }     
//------------------------------------------------------------------------------------------------------------------   
    public void CargarFichero(){
        String linea;
        int contador = 0;
        try {
            FileReader fichero=new FileReader("fichero.txt");
            BufferedReader br=new BufferedReader(fichero);
                        
                linea=br.readLine();
        // Leera lineas del fichero hasta que sea null.
		while ( linea!=null){
                    contador++;
                    for (int i = 0; i < contador; i++) {
                        linea += parkingDeVehiculos[i];
                        linea=br.readLine();
                    }
                // Cuenta el numero de vehiculos, cada vehiculo es una línea.
                    _numVehiculos += contador;
		}
                br.close();
		fichero.close();            
        } catch (IOException e) {
            System.out.println( e.getMessage());
        }
    }
//-----------------------------------------------------------------------------------------------------------------
    public void GuardarEnFichero(){
        FileWriter fichero = null;
        
        try {
            fichero = new FileWriter("fichero.txt");
            PrintWriter pw =new PrintWriter(fichero);

            for (int i = 0; i < _numVehiculos; i++) {                
                pw.println(parkingDeVehiculos[i]);                
            } 
            System.out.println("Fichero guardado.");
            pw.close();	    
        } catch (IOException ex) {
            System.out.println( ex.getMessage());
        }finally{
            try {
                if(null != fichero){fichero.close();}
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        _numVehiculos = 0;   
     }    
    
}
