/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_examen1_ejercicio2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author FENRIR
 */
public class Perez_Alvarez_Angela_PROG_Examen1_Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   Scanner teclado = new Scanner(System.in);
   
   // VARIABLES 
   int NUMERO_DE_ELEMENTOS;
   //int menor;
   
   // ARRAYS   
        //int[] arraysDeEnteros = new int[NUMERO_DE_ELEMENTOS];
        
   // AQUI EMPIEZA

        /**
         * Este es el segundo intento, primero pido cuantos numeros quieres introducir para poner un maximo al array
         * y luego los ordeno, no me sale como queiro y me quedo sin tiempo.
         */
       /* System.out.println("¿Cuantos numeros deseas introducir?");
        NUMERO_DE_ELEMENTOS = teclado.nextInt();
        for (int i = 0; i < arraysDeEnteros.length; i++) {
          System.out.println("Introduce un numero para la posicion "+(i+1)+".");  
          arraysDeEnteros[i] = teclado.nextInt();
        }
        
        for (int i = 0; i < NUMERO_DE_ELEMENTOS; i++) {
            if(arraysDeEnteros[i]< arraysDeEnteros[1+i]){
                
            }else{
                if(arraysDeEnteros[i]> arraysDeEnteros[1+i]){
                }
            }
        }*/
        
        
   /**
    * Este es el primer intento que hize para el ejercicio.
    */

  /*  int NUMERO_ELEMENTO;
    int menor;

    for(int i = 0; i < 10; i++){
        menor = a[0];

        if (a[i] < menor){
            menor = a[i];
        }
        else{
            if (a[i] > menor){
              menor = menor;
            }      
        }
    }
    System.out.println(Arrays.toString(a));*/
  
  /**
   * Tercer intento.
   */
int [] numeros = {2,5,10,9,1,3,6,4};
 Arrays.sort(numeros);
 for (int i = 0; i < numeros.length; i++) {
 System.out.println(""+numeros[i]);
 }
   
}    
}
