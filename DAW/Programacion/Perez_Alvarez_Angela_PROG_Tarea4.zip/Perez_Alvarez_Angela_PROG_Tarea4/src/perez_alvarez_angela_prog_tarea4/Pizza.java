/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_tarea4;

/**
 *
 * @author ANGELA PEREZ
 */
public class Pizza {
 // ATRIBUTOS
    private int _opcionTamaño;
    private int _opcionTipoPizza;
    private double _precioPequeña;
    private double _precioMediana;
    private double _precioGrande;
    private double _precioTotalPizza;
    String _tamañoPizza;
    String _textoTipoDePizza;
    
    private String _tamañoPizzas = "¿De que tamaño deseas la pizza?\n 1. Pequeña 3€\n 2. Mediana 5€\n 3. Familiar 7€\n";
    private String _tipoPizza = "¿que tipo de pizza deseas?\n 1. Margarita\n 2. Mediterranea\n 3. Caprichosa\n 4. Vegetariana\n";
    
 // ARRAYS
    String[] tiposDePizza = new String[]{"Margarita", "Mediterranea", "Caprichosa", "Vegetariana"};
    
 // CONSTRUCTOR 
    public Pizza(){
        _tamañoPizza = "";
        _textoTipoDePizza = "";
        _opcionTamaño = 0;
        _opcionTipoPizza = 0;
        _precioPequeña = 3;
        _precioMediana = 5;
        _precioGrande = 7;
        _precioTotalPizza = 0;
    }
 // METODOS
    
    public void seleccionarTamaño(){
        System.out.println(_tamañoPizzas);
        _opcionTamaño = Menu.ControlarTeclado(1, 3);
        switch(_opcionTamaño){
            case 1:
                _tamañoPizza = _tamañoPizza + "Pequeña";
                _precioTotalPizza = _precioTotalPizza + _precioPequeña;
                break;
            case 2:
                _tamañoPizza = _tamañoPizza + "Mediana";
                _precioTotalPizza = _precioTotalPizza + _precioMediana;
                break;
            case 3:
                _tamañoPizza = _tamañoPizza + "Familiar";
                _precioTotalPizza = _precioTotalPizza + _precioGrande;
                break;
        }
        
    }
    
    public void seleccionarTipoPizza(){
        /**
         * Al poner directamente el array para sacar el tipo de pizza en el atributo que muestra por pantalla el pedido
         * daba error, así que he tenido que introducir el valor del array el una variable.
         */
        System.out.println(_tipoPizza);
        _opcionTipoPizza = Menu.ControlarTeclado(1, 4);
        _textoTipoDePizza = _textoTipoDePizza + tiposDePizza[(_opcionTipoPizza-1)];
    }
    

    /**
     * Metodo para mostra en el recibo el tamaño de la pizza y el tipo. 
     */
    public void mostrarPizza(){
        System.out.println("Su pedido es de una pizza "+_textoTipoDePizza +" de tamaño: "+_tamañoPizza);
    }
    /**
     * Metodo que devuelve el precio total del tamaño de la pizza.
     * @return 
     */
    public double devolverPrecioPizza(){
        return (double) _precioTotalPizza;
    }
}
