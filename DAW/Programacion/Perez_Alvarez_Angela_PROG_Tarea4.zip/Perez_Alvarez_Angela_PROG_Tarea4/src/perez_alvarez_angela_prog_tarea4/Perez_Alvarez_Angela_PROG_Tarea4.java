/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_tarea4;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_PROG_Tarea4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // CLASES
      Scanner teclado = new Scanner(System.in);
      Pizza pizza = new Pizza();
      Ingrediente ingrediente = new Ingrediente();
    // VARIABLES
    boolean salir = false;
    int opcionInicial;
    
    /**
     *  Aqui empieza.
     */
//------------  Menu inicial para hacer el pedido o salir del programa  --------------------------------------------------
    do{
        System.out.println("+++  BIENVENIDO  +++\n"
                + "1. Inrtoducir pedido.\n"
                + "2. Salir.");
        opcionInicial = Menu.ControlarTeclado(1, 2);
        switch(opcionInicial){
            case 1:
//-----------  Llamamos a la clase Pizza para seleccionar el tamaño.  ----------------------------------------------------
                pizza.seleccionarTamaño();                
//----------  Volvemos a llamar a la clase Pizza esta vez para elegir el tipo de pizza  ---------------------------------
                pizza.seleccionarTipoPizza();
//----------  Ahora llamammos a la clase Ingrediente  -------------------------------------------------------------------
                ingrediente.seleccionarIngredientes();
//------- Por ultimo llamamos a los métodos para devolver lo que hemos seleccionado de las respectivas clases  ----------
                pizza.mostrarPizza();
                ingrediente.devolverIngredientes();
                System.out.println("El total del pedido es de: "+(ingrediente.devolverPrecioIngredientes()+pizza.devolverPrecioPizza()));
                
                break;
            case 2:
                salir = true;
        }
    }while(!salir);
    }
    
}
