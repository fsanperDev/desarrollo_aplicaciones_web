/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_tarea4;

import java.util.ArrayList;

/**
 *
 * @author ANGELA PEREZ
 */
public class Ingrediente {
 // ATRIBUTOS
    private String _preguntarIngredientes;
    private String _textoPedirIngrdientes;
    private String _textoTicketIngrdientes;
    private int _opcionIngrediente;
    private int _ingrediente;
    private double _precioTotalIngredientes;
    
    private double _precioBacon;
    private double _precioQueso;
    private double _precioJamon;
    private double _precioAnchoas;
    private double _precioPepinillos;
    private double _precioAtun;
    private double _precioChampiñones;
 // ARRAYS
    //String[] listaDeIngrdientes = new String[]{};
    ArrayList<String> listaDeIngrdientes = new ArrayList<String>();
 // CONSTRUCTOR
    public Ingrediente(){
        _preguntarIngredientes = "¿Deseas algún ingrediente adicional? Puedes pedir un máximo de 3, seleccione 0 si no desea ninguno\n";
        _textoPedirIngrdientes = "+++ LISTA DE INGREDIENTES +++\n 1. Bacon - 0.50€\n 2. Queso - 0.50€\n"
                + " 3. Jamón - 1€\n 4. Anchoas - 1€\n 5. Pepinillos - 0.50€\n 6. Atún - 1€\n 7. Champiñones - 0.50€\n";
        _textoTicketIngrdientes = "*** INGREDIENTES SELECCIONADOS ***";
        _opcionIngrediente = 0;
        _ingrediente = 0;
        _precioTotalIngredientes = 0;
        _precioBacon = 0.50;
        _precioQueso = 0.50;
        _precioJamon = 1;
        _precioAnchoas = 1;
        _precioPepinillos = 0.50;
        _precioAtun = 1;
        _precioChampiñones = 0.50;
    }
 // METODOS
    /**
     * Metodo para el menu de los Ingredientes.
     */
    public void seleccionarIngredientes(){
        /*
        Para este hacer este método he decidido introducir los ingredientes en un arraylist según se vayan seleccionando
        en el bucle.
        */
        System.out.println(_preguntarIngredientes);
        _opcionIngrediente = Menu.ControlarTeclado(0, 3);
        if(_opcionIngrediente > 0){
            do{
                System.out.println(_textoPedirIngrdientes);
                _ingrediente = Menu.ControlarTeclado(1, 7);
                switch(_ingrediente){
                    case 1:
                        listaDeIngrdientes.add("Bacon");
                        _precioTotalIngredientes = _precioTotalIngredientes + _precioBacon;
                        _opcionIngrediente--;
                        break;
                    case 2:
                        listaDeIngrdientes.add("Queso");
                        _precioTotalIngredientes = _precioTotalIngredientes + _precioQueso;
                        _opcionIngrediente--;
                        break;
                    case 3:
                        listaDeIngrdientes.add("Jamón");
                        _precioTotalIngredientes = _precioTotalIngredientes + _precioJamon;
                        _opcionIngrediente--;
                        break;
                    case 4:
                        listaDeIngrdientes.add("Anchoas");
                        _precioTotalIngredientes = _precioTotalIngredientes + _precioAnchoas;
                        _opcionIngrediente--;
                        break;
                    case 5:
                        listaDeIngrdientes.add("Pepinillos");
                        _precioTotalIngredientes = _precioTotalIngredientes + _precioPepinillos;
                        _opcionIngrediente--;
                        break;
                    case 6:
                        listaDeIngrdientes.add("Atún");
                        _precioTotalIngredientes = _precioTotalIngredientes + _precioAtun;
                        _opcionIngrediente--;
                        break;
                    case 7:
                        listaDeIngrdientes.add("Champiñones");
                        _precioTotalIngredientes = _precioTotalIngredientes + _precioChampiñones;
                        _opcionIngrediente--;
                        break;
                }
                
            }while(_opcionIngrediente > 0);
        }
        
    }
    /**
     * Metodo que devuelve la lista de los ingredientes seleccionados.
     */
    public void devolverIngredientes(){
        /*
        Aqui saco los ingredientes o elemento que introduje en el arraylist previemente.
        */
        System.out.println(_textoTicketIngrdientes);
        for(int x=0;x<listaDeIngrdientes.size();x++) {
            System.out.println(listaDeIngrdientes.get(x));
        }
    }
    /**
     * Metodo que devuelve el precio total de los ingredientes.
     * @return 
     */
    public double devolverPrecioIngredientes(){
        return (double) _precioTotalIngredientes;
    }
}
