/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareapresencial1;

import java.util.Scanner;

/**
 *
 * @author JBono
 */
public class TareaPresencial1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Definimos las constantes para los Menus.
        final int SELECCION_CAFE = 1;
        final int SELECCION_LECHE = 2;
        final int SELECCION_CAFE_CON_LECHE = 3;
        final int SELECCION_ESTADO_DE_MAQUINA = 4;
        final int SELECCION_APAGAR_MAQUINA = 5;
        
        final int INSERTAR_EURO = 1;
        final int INSERTAR_50_CENTIMOS = 2;
        final int INSERTAR_20_CENTIMOS = 3;
        final int INSERTAR_10_CENTIMOS = 4;
        final int SALIR_DE_MENU_INSERTAR = 5;        
        
        //Definimos las constantes para la aplicación        
        final int DEPOSITOS_INICIAL_DE_CAFE = 10;
        final int DEPOSITOS_INICIAL_LECHE = 10;
        final int DEPOSITOS_INICIAL_DE_VASOS = 16;
        
        final int MONEDERO_INICIAL_MONEDAS_EURO = 0;
        final int MONEDERO_INICIAL_MONEDAS_50_CENTIMOS = 5;
        final int MONEDERO_INICIAL_MONEDAS_20_CENTIMOS = 5;
        final int MONEDERO_INICIAL_MONEDAS_10_CENTIMOS = 5;
        
        final double VALOR_EURO = 1;
        final double VALOR_50_CENTIMOS = 0.5;
        final double VALOR_20_CENTIMOS = 0.2;
        final double VALOR_10_CENTIMOS = 0.1;
        
        final double PRECIO_CAFE = 1;
        final double PRECIO_LECHE = 0.8;
        final double PRECIO_CAFE_CON_LECHE = 1.5;
        
        //Defino las variables del programa.        
        
        //Inicializo las monedas del monedero;
        int monederoMonedasEuro = MONEDERO_INICIAL_MONEDAS_EURO;
        int monederoMonedas50Centimos = MONEDERO_INICIAL_MONEDAS_50_CENTIMOS;
        int monederoMonedas20Centimos = MONEDERO_INICIAL_MONEDAS_20_CENTIMOS;
        int monederoMonedas10Centimos = MONEDERO_INICIAL_MONEDAS_10_CENTIMOS;
        
        //Inicializo los depositos de la máquina.
        int depositosDeCafe = DEPOSITOS_INICIAL_DE_CAFE;
        int depositosDeLeche = DEPOSITOS_INICIAL_LECHE;
        int depositosDeVasos = DEPOSITOS_INICIAL_DE_VASOS;
        
        //Definimos variables auxiliares que necesitare para hacer calculos.
        double dineroInsertado = 0;
        double cantidadADevolver = 0;
        double centimosADevolver = 0;
        int opcionMenuPrincipal = 0;
        int opcionMenuDinero = 0;
        int monedaDeEuroADevovler = 0;
        int monedaDe50CentimosADevovler = 0;
        int monedaDe20CentimosADevovler = 0;
        int monedaDe10CentimosADevovler = 0;
        int monedaInsertadaEuro = 0;
        int monedaInsertada50Centimos = 0;
        int monedaInsertada20Centimos = 0;
        int monedaInsertada10Centimos = 0;
        
        //Defino variables que necesitare para controlar la aplicacion.
        boolean salir = false;
        boolean errorDeEntrada = false;
        boolean finInsertarMonedas = false;
        boolean dineroSuficiente = true;
        boolean depositoSuficiente = true;
        boolean descontarProducto = false;
        boolean opcionElegidaQueDispensaProducto = false;
        
        //Uso la clase Scanner para la entrada de información por teclado.
        Scanner teclado = new Scanner(System.in);
        
        //Comienza la aplicación
        do{
            //Establecemos a false el valor booleano de si se ha elegido una opcion que conlleve dispensar producto
            opcionElegidaQueDispensaProducto = false;
            //Mostramos el menu
            System.out.println("\nMenu de Maquina de cafe.");
            System.out.println(SELECCION_CAFE + ". Servir café solo ( 1 euro)");
            System.out.println(SELECCION_LECHE + ". Servir leche (0.8 euros)");
            System.out.println(SELECCION_CAFE_CON_LECHE + ". Servir café con leche (1,5 euros)");
            System.out.println(SELECCION_ESTADO_DE_MAQUINA + ". Consultar el estado de la maquina");
            System.out.println(SELECCION_APAGAR_MAQUINA + ". Apagar máquina y salir");
            System.out.println("\nSeleccione una opcion de "+ SELECCION_CAFE + " a " + SELECCION_APAGAR_MAQUINA);
            do{ /* Codigo relativo a la lectura por teclado
                     de opcion valida y a prueba de errores */
                try{
                    opcionMenuPrincipal = teclado.nextInt();
                    if ((opcionMenuPrincipal>0) && (opcionMenuPrincipal<=SELECCION_APAGAR_MAQUINA)){ //opcion dentro del rango.                       
                        errorDeEntrada = false;
                    }
                    else{
                        System.out.println("Opción elegida no valida... Intentelo de nuevo");
                        errorDeEntrada = true;
                    }                    
                }
                catch (Exception e){
                    System.out.println("Error al insertar opcion... Intentelo de nuevo.");
                    errorDeEntrada = true;
                    teclado.nextLine();
                }                
            }while(errorDeEntrada);//Hasta que no haya leido un numero entero valido seguiremos intentando.
            
            //verificamos si hemos eleguido una opcion de dispensar producto            
            opcionElegidaQueDispensaProducto = ((opcionMenuPrincipal == SELECCION_CAFE) || 
                                                (opcionMenuPrincipal == SELECCION_LECHE) ||
                                                (opcionMenuPrincipal == SELECCION_CAFE_CON_LECHE));
            
            //Preparo el valor de deposito suficiente antes de verificar si hay suficientes depositos.
            depositoSuficiente = true;
            
            //Compruebo que hay depositos suficientes para servir el producto.           
            switch(opcionMenuPrincipal){
                case SELECCION_CAFE: 
                   depositoSuficiente = ((depositosDeCafe > 0) && (depositosDeVasos > 0));
                   break;
                case SELECCION_LECHE: 
                   depositoSuficiente = ((depositosDeLeche > 0) && (depositosDeVasos > 0));
                   break;
                case SELECCION_CAFE_CON_LECHE: 
                   depositoSuficiente = ((depositosDeCafe > 0) && (depositosDeLeche > 0) && (depositosDeVasos > 0));
                   break;
            }            
            // si no hay depositos  sufucientes y se habia seleccionado un menú de dispensar: lo muestro por pantalla y vuelvo al Menu.
            if ((!depositoSuficiente) && opcionElegidaQueDispensaProducto){
                System.out.println("No hay existencias de su elección.");
            }
            else {//Comprobado que tengo depositos suficientes para la elección continuamos con la ejecución
                switch (opcionMenuPrincipal){ // Segun la opcion elegida del menu....
                    case SELECCION_CAFE:                                        
                    case SELECCION_LECHE:                
                    case SELECCION_CAFE_CON_LECHE://Codigo comun para los casos de cafe, leche o cafe con leche.
                        //Lo primero será insertar monedas. 
                        
                        //Inicializamos variables que vamos a usar.
                        finInsertarMonedas = false;
                        errorDeEntrada = false;
                        dineroInsertado = 0;
                        monedaInsertadaEuro =0;
                        monedaInsertada50Centimos = 0;
                        monedaInsertada20Centimos = 0;
                        monedaInsertada10Centimos = 0;
                        do{ //Mostramos el Menu 
                            System.out.println("Menu de Insertar Monedas");
                            System.out.println(INSERTAR_EURO + ".- Introducir moneda de 1 €uro");
                            System.out.println(INSERTAR_50_CENTIMOS + ".- Introducir monedas de 50 centimos");
                            System.out.println(INSERTAR_20_CENTIMOS + ".- Introducir monedas de 20 centimos");
                            System.out.println(INSERTAR_10_CENTIMOS + ".- Introducir monedas de 10 centimos");
                            System.out.println(SALIR_DE_MENU_INSERTAR + ".-Finalizar el insertar monedas");                        
                            System.out.println("Cantidad Actual: "+ dineroInsertado +" €uros");                            
                            do{ /* Codigo relativo a la lectura por teclado
                                    de opcion valida y a prueba de errores */
                                try{
                                    opcionMenuDinero = teclado.nextInt();
                                    if ((opcionMenuDinero>0) && (opcionMenuDinero<=5)){ //opcion dentro del rango.                        
                                        errorDeEntrada = false;
                                    }
                                    else{
                                        System.out.println("Opción elegida no valida... Intentelo de nuevo");
                                        errorDeEntrada = true;
                                    }                    
                                }
                                catch (Exception e){
                                    System.out.println("Error al insertar opcion... Intentelo de nuevo.");
                                    errorDeEntrada = true;
                                    teclado.nextLine();
                                }                
                            }while(errorDeEntrada);//Hasta que no haya leido un numero entero valido seguiremos intentando.

                            switch (opcionMenuDinero){//Segun la opcion elegija de insertar monedas
                                case INSERTAR_EURO: 
                                    monedaInsertadaEuro += 1;
                                    dineroInsertado += VALOR_EURO;
                                    break;
                                case INSERTAR_50_CENTIMOS:
                                    monedaInsertada50Centimos += 1;
                                    dineroInsertado += VALOR_50_CENTIMOS;
                                    break;
                                case INSERTAR_20_CENTIMOS:
                                    monedaInsertada20Centimos += 1;
                                    dineroInsertado += VALOR_20_CENTIMOS;
                                    break;
                                case INSERTAR_10_CENTIMOS:
                                    monedaInsertada10Centimos += 1;
                                    dineroInsertado += VALOR_10_CENTIMOS;
                                    break;
                                case SALIR_DE_MENU_INSERTAR:
                                    finInsertarMonedas = true;
                                    break;                            
                            }
                            //Math.rint(dineroInsertado*100)/100 lo utilizo para REDONDEAR la variable double dineroInsertado a 2 decimales
                            dineroInsertado = Math.rint(dineroInsertado*100)/100;
                        }while(!finInsertarMonedas);                    
                        System.out.println("Valor insertado total: "+dineroInsertado);

                        //Comprobamos que el dinero introducido es suficiente.
                        switch(opcionMenuPrincipal){
                            case SELECCION_CAFE: 
                               dineroSuficiente = dineroInsertado >= PRECIO_CAFE;
                               break;
                            case SELECCION_LECHE: 
                               dineroSuficiente = dineroInsertado >= PRECIO_LECHE;
                               break;
                            case SELECCION_CAFE_CON_LECHE: 
                               dineroSuficiente = dineroInsertado >= PRECIO_CAFE_CON_LECHE;
                               break;
                        }
                        // si no hay dinero sufuciente mostrlo por pantalla y volvemos al menu
                        if (!dineroSuficiente){
                            System.out.println("Dinero introducido insuficiente.");
                        }
                        else {/* Seguimos con la aplicación
                              Comprobaremos si hay suficiente dinero. En caso de que si 
                              comprobaremos que hay cambio suficiente. En el caso de que si
                              cargaremos en el monedero lo insertado, descontaremos el cambio
                              y restaremos los productos servidos */
                            
                            //Inicializo las cantidades a devolver.
                            monedaDeEuroADevovler = 0;
                            monedaDe50CentimosADevovler = 0;
                            monedaDe20CentimosADevovler = 0;
                            monedaDe10CentimosADevovler = 0;
                            switch(opcionMenuPrincipal){
                                case SELECCION_CAFE: 
                                   cantidadADevolver = dineroInsertado - PRECIO_CAFE;
                                   break;
                                case SELECCION_LECHE: 
                                   cantidadADevolver = dineroInsertado - PRECIO_LECHE;
                                   break;
                                case SELECCION_CAFE_CON_LECHE: 
                                   cantidadADevolver = dineroInsertado - PRECIO_CAFE_CON_LECHE;
                                   break;
                            }
                            
                            //redondeo la cantidad a devolver a 2 decimales.
                            cantidadADevolver = Math.rint(cantidadADevolver*100)/100;
                            descontarProducto = false;
                            if (cantidadADevolver == 0){ //cambio exacto
                                System.out.println("Importe exacto, no necesita cambio");
                                descontarProducto = true;
                            }
                            else{
                                //Muestro por consola el valor a devolver.
                                System.out.println("Cantidad a devolver: " + cantidadADevolver);
                                
                                //Calculemos las monedas necesarias NO ES UN ALGORITMO PERFECTO!!
                                monedaDeEuroADevovler = (int) (cantidadADevolver / VALOR_EURO);
                                centimosADevolver = (cantidadADevolver % VALOR_EURO);  
                                centimosADevolver = Math.rint(centimosADevolver*100)/100; // redondeo los centimos a devolver a 2 decimales.
                                if (centimosADevolver > 0){//Quedán centimos por devolver
                                    monedaDe50CentimosADevovler = (int) (centimosADevolver / VALOR_50_CENTIMOS);
                                    if ((centimosADevolver % VALOR_50_CENTIMOS) != 0){//Siguen quedando centimos por devolver                                        
                                        centimosADevolver = (cantidadADevolver % VALOR_50_CENTIMOS);
                                        centimosADevolver = Math.rint(centimosADevolver*100)/100; // redondeo los centimos a devolver a 2 decimales.
                                        monedaDe20CentimosADevovler = (int) (centimosADevolver / VALOR_20_CENTIMOS);
                                        if (centimosADevolver % VALOR_20_CENTIMOS > 0){
                                            centimosADevolver = (centimosADevolver % VALOR_20_CENTIMOS);
                                            centimosADevolver = Math.rint(centimosADevolver*100)/100; // redondeo los centimos a devolver a 2 decimales.
                                            monedaDe10CentimosADevovler = (int)( centimosADevolver / VALOR_10_CENTIMOS);
                                        }
                                    }
                                }                                
                            
                            
                                //Compruebo si tendré suficientes monedas en el monedero para dar el cambio al ususario.
                                if ((monedaDe50CentimosADevovler <= (monederoMonedas50Centimos + monedaInsertada50Centimos))
                                    && (monedaDe20CentimosADevovler <= (monederoMonedas20Centimos + monedaInsertada20Centimos))
                                    && (monedaDe10CentimosADevovler <= (monederoMonedas10Centimos + monedaInsertada10Centimos))) {//Tenemos cambio
                                    //En este punto ya sabemos que SI vamos a tener cambio para devolver al usuario.
                                    //Insertamos las monedas en el monedero.
                                    monederoMonedasEuro += monedaInsertadaEuro;
                                    monederoMonedas50Centimos += monedaInsertada50Centimos;
                                    monederoMonedas20Centimos += monedaInsertada20Centimos;
                                    monederoMonedas10Centimos += monedaInsertada10Centimos;
                                    //Sacamos del monedero para devolver al usuario la vuelta.
                                    monederoMonedasEuro -= monedaDeEuroADevovler;
                                    monederoMonedas50Centimos -= monedaDe50CentimosADevovler;
                                    monederoMonedas20Centimos -= monedaDe20CentimosADevovler;
                                    monederoMonedas10Centimos -= monedaDe10CentimosADevovler;
                                    //Mostramos por pantalla la devolución.
                                    System.out.println("Su devolucion: " + monedaDeEuroADevovler + " monedas de Euro, " +
                                                        monedaDe50CentimosADevovler + " monedas de 50 Centimos, " + 
                                                        monedaDe20CentimosADevovler+ " monedas de 20 Centimos y " +
                                                        monedaDe10CentimosADevovler + " monedas de 10 Centimos");
                                    descontarProducto = true;
                                }
                                else{//Este es el caso de no tener suficiente cambio para el usuario.
                                    System.out.println("No hay cambio suficiente en la maquina");
                                }  
                            }
                            if (descontarProducto == true){//Restamos los producto/s consumido/s de la maquina.      
                                System.out.println("Sirviendo su bebida...");
                                switch(opcionMenuPrincipal){
                                    case SELECCION_CAFE: 
                                       depositosDeCafe--;
                                       depositosDeVasos--;
                                       break;
                                    case SELECCION_LECHE: 
                                       depositosDeLeche--;
                                       depositosDeVasos--;
                                       break;
                                    case SELECCION_CAFE_CON_LECHE: 
                                       depositosDeCafe--;
                                       depositosDeLeche--;
                                       depositosDeVasos--;
                                       break;
                                }
                            }
                        }                        
                        break;

                    case SELECCION_ESTADO_DE_MAQUINA:
                        System.out.println("Estado de la Maquina");
                        System.out.println("Monedero - Monedas de Euro: " + monederoMonedasEuro);
                        System.out.println("Monedero - Monedas de 50 Centimos: " + monederoMonedas50Centimos);
                        System.out.println("Monedero - Monedas de 20 Centimos: " + monederoMonedas20Centimos);
                        System.out.println("Monedero - Monedas de 10 Centimos: " + monederoMonedas10Centimos);
                        System.out.println("Deposito - Depositos de cafe: " + depositosDeCafe);
                        System.out.println("Deposito - Depositos de Leche: " + depositosDeLeche);
                        System.out.println("Deposito - Depositos de Vasos: " + depositosDeVasos + "\n");
                        break;

                    case SELECCION_APAGAR_MAQUINA:
                        salir = true;
                        System.out.println("Maquina apagandose... Hasta luego...");
                        break;
                }                
            }
        }while (!salir);        
    }    
}
