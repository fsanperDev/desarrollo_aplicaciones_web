/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_examen_3ºt;

/**
 *
 * @author FENRIR
 */
public class Empleados {
    private final String _nombreApellidos;
    private final String _anho;
    private final String _estadoCivil;
    private final String _estadoLaboral;
    
    //Constructor
    public Empleados(String nombreYapellidos, String anhoNacimiento, String estadoC, String estadoL){
        _nombreApellidos = nombreYapellidos;
        _anho = anhoNacimiento;
        _estadoCivil = estadoC; 
        _estadoLaboral = estadoL;        
    }
    
    
    @Override  
    public String toString(){
        return ("Nombre: "+_nombreApellidos+" Año de nacimiento: "+_anho
                +" Estado Civil: " + _estadoCivil +" Situación laboral: "+ _estadoLaboral);
    }
}
