/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_examen_3ºt;

import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;

/**
 *
 * @author FENRIR
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TextField TextFieldNombre;
    @FXML
    private TextField textFieldAnho;
    @FXML
    private TextArea textAreaMostrat;
    @FXML
    private RadioButton RadioBottonSoltero;
    @FXML
    private RadioButton RadioBottonCasado;
    @FXML
    private RadioButton RadioBottonViudo;
    @FXML ComboBox ComboBoxLaboral;
    
//******************   BOTONES   ******************************************************************
    @FXML
    private void handleButtonAceptar(ActionEvent event) {
        String nombreYapellidos, anhoNacimiento, estadoC, estadoL;
        Empleados nuevoEmpleado;
        
        
        nombreYapellidos = TextFieldNombre.getText();
        anhoNacimiento = textFieldAnho.getText();
        estadoC = estadoCivil();
        estadoL = ComboBoxLaboral.getValue().toString();
        
        if(Verificacion() == false){
            nuevoEmpleado = new Empleados(nombreYapellidos, anhoNacimiento, estadoC, estadoL);
            Perez_Alvarez_Angela_Examen_3ºT.listaDeEmpleados.add(nuevoEmpleado);
            TextFieldNombre.setText("");
            textFieldAnho.setText("");
        }else{            
            int value = Integer.valueOf(textFieldAnho.getText());
            if(value > 1900 && value < 2019)
            {
              JOptionPane.showMessageDialog(null, "No puedes dejar campos vacios");
            }else{
              JOptionPane.showMessageDialog(null, "El año no puede ser menor a 1900 o mayor a 2019");              
            }
        }
    }
    
    @FXML
    private void handleButtonMostar(ActionEvent event) {
        textAreaMostrat.clear();
        
        // Declaramos el Iterador e imprimimos los Elementos del ArrayList
        Iterator<Empleados> iterator = Perez_Alvarez_Angela_Examen_3ºT.listaDeEmpleados.iterator();
        while (iterator.hasNext()) {
            Empleados nuevoEmpleado = iterator.next();
            textAreaMostrat.appendText(nuevoEmpleado.toString()+"\n");
        }
    }
    
    @FXML
    private void handleButtonLimpiar(ActionEvent event) {
        textAreaMostrat.clear();
    }
    
    @FXML
    private void handleButtonSalir(ActionEvent event) {
        System.exit(0);
    }
 
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        rellenaComboBox();
    }
    
 // METODOS
    /**
     * Método que devuelve el estado civil. RadioButton
     * @return 
     */
    private String estadoCivil(){
        String resultado;
        if (RadioBottonSoltero.isSelected()){
            resultado ="Soltero";            
        } else {
            if (RadioBottonCasado.isSelected()){
                resultado = "Casado";
            }
            else{
                resultado = "Viudo";
            }
        }
        return (resultado);
    }
    /**
     * Método que rellena de datos el Combobox.
     */
    ObservableList<String> listaDeEstadoLaboral = FXCollections.observableArrayList("activo","parado","jubilado");
    public void rellenaComboBox() {

        ComboBoxLaboral.setItems(listaDeEstadoLaboral);
        ComboBoxLaboral.getSelectionModel().selectFirst();
    }
    
    private boolean Verificacion(){
        boolean vacio = false;
    //Campos vacios.
        if(TextFieldNombre.getText().length()==0){
            vacio = true;
        }else{
            if(textFieldAnho.getText().length()==0){
                vacio = true;
            }else{
                if(ComboBoxLaboral.getItems().size()==0){
                    vacio = true;
                }else{
                    //Rango de edad.
                    int value = Integer.valueOf(textFieldAnho.getText());
                    if(value > 1900 && value < 2019)
                    {
                       vacio = false;
                    }else{
                        vacio = true;
                    } 
                }
            }
        }      
         
        return vacio;
    }
    
}
