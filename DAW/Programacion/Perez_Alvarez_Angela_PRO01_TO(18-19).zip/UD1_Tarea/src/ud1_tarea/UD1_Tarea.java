/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ud1_tarea;

/**
 *
 * @author ANGELA PEREZ ALVAREZ
 */
public class UD1_Tarea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // VARIABLES
    
    String nomb = "ANGELA";   
    String ape1 = "PEREZ"; 
    String ape2 = "ALVAREZ"; 
    String deporte = "Baloncesto";
    final double altura = 1.66;
    final byte mes = 5;
    final int ano = 1994;
    int federaIni = 2017;
    final long camiseta = 36L;
    final char mano = 'D';
    boolean federado = true;
    final float acierto = 79.35f ;
    short partido = 12;
    
    

    /* A PARTIR DE AQUI EMPIEZA EL PROGRAMA */
    System.out.println(" Hoja de datos ");
    System.out.println("Nombre: "+ nomb);
    System.out.println("Apellidos: "+ ape1+" "+ape2);
    System.out.println("Altura: "+ altura);
    System.out.println("Mes de nacimiento: "+ mes);
    System.out.println("Año de nacimiento: "+ ano);
    System.out.println("Mano dominante: "+ mano);
    System.out.println("Deporte que practica: "+ deporte);
    System.out.println("Numero del jugador: "+ camiseta);
    System.out.println("Federado: "+ federado);
    System.out.println("Ultima federacion: "+federaIni);
    federaIni = federaIni + 3;
    System.out.println("Su federacion caducara en : "+federaIni);
    System.out.println("Porcentaje de acierto : "+ acierto+"%");
    System.out.println("Partidos jugados: "+ partido);
    
        
    }
}
