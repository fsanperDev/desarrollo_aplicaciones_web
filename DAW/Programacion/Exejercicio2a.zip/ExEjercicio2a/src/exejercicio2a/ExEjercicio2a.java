/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exejercicio2a;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class ExEjercicio2a {

    /**
     * @param args the command line arguments
     */
 
    public static void main(String[]args){
 
        Scanner scan=new Scanner(System.in);
        System.out.println("Introduce números enteros y pulse 0 para acabar: ");
        int datosIntroducidos=0;
        int[] array=new int[1000];
        int i=0;
        do{
            datosIntroducidos=scan.nextInt();
 
            if(datosIntroducidos!=0){
                array[i]=datosIntroducidos;
                i++;
            }
        }while(datosIntroducidos!=0);
        
        System.out.println(array[i]);
    }
}
    
    
    
    
    
    /*   public static void main(String[] args) {
      
        Scanner teclado = new Scanner(System.in);
      //Variables  
        int n = 0;
        int nu = 0;
        
      // Array
      int [] numeros = new int [1000];
      
      //El programa empieza aqui
      
     System.out.println("Escribe el total de numeros a introducir: ");
     n = Integer.parseInt(teclado.nextLine());
     n = nu;
    do{
        System.out.println("Escribe un numero: ");
        n = Integer.parseInt(teclado.nextLine());
    }while(n==0);
           
}*/
