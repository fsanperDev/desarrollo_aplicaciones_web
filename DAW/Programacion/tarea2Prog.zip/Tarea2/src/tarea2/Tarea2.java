
package tarea2;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ ALVAREZ
 */
public class Tarea2 {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
      
        Scanner teclado = new Scanner(System.in);
      //Variables 
        
      final String pedido = "1.Pedido";
      final String salir = "0.Salir";
      final int Msalir = 0, Mpedido = 1;
      int menu = 0;
      
      int precio1 = 0;
      int sobremesa = 800;
      int portatil = 600;
      int barebone = 400;
      double total = 0;

      String conf;
      String gamer = null, estandar, multimedia;
      
      int resp;
      int serv = 0;
      final int fserv = 0;
      int opcion = 0;
      
      
      int precio = 0;
      int total2 = 0;
      
      
        
    //Primer menu 1 para hacer pedido o 5 para salir
     do{
               
            do{
                 try {
                        System.out.println(salir);
                        System.out.println(pedido);
                        System.out.println("¿Que deseas hacer?");
                        menu = Integer.parseInt(teclado.nextLine());
                    }
                    catch (InputMismatchException laexcepcion)
                   {
                      System.out.println("Tienes que meter un número");
                      teclado.nextLine();
                    }
            finally { }
               
              }while (menu != Msalir && menu != Mpedido);
              
            if (menu==0) System.exit(0);
             
//Un menu para elegir el modelo,segun el numero se le sumara una cantidad a la variante precio1 
              
                System.out.println("¿Que modelo deseas?");  
                System.out.println("1. Sobremesa 800€");
                System.out.println("2. Portatil 600€");
                System.out.println("3. Barebone 400€"); 
                precio1 = Integer.parseInt(teclado.nextLine());
                precio1++;
                if(precio1==1) total= total+800;
                if(precio1==2) total= total+600;
                if(precio1==3) total= total+400;
               if(precio1>=4 && precio1<=0) System.out.println("Tienes que elegir 1, 2 o 3 ");
              
               
 //Darle un nombre a la variante conf, si no son iguales que vuelva a escribirto
                System.out.println("Ahora escribe la configuracion que deseas :");
                System.out.println("Gamer");
                System.out.println("Estandar");
                System.out.println("Multimedia");
                conf = teclado.next();

                
 //Selecccionar los servicios adicionales, max 3               
                
            
                        do{
                         System.out.println("¿Cuantos servicios deseas?(Puedes elegir hasta un maximo de 3 servicios)");
                         serv=teclado.nextInt();
                         //do{
                                      System.out.println("MENU DE SERVICIOS"); 
                                      System.out.println("1 Arranque inicial 20€ "); 
                                      System.out.println("2 Solucion de virus 30€ "); 
                                      System.out.println("3 Soporte informático 49.99€ ");
                                      System.out.println("4 Instalar SO 36.80€ "); 
                                      System.out.println("5 Instalar Hardware 24.99€ ");
                                      System.out.println("6 Gestion de datos HD 60€ ");
                                      opcion=teclado.nextInt();
                                         try{
                                           if(opcion==1)
                                                    total = total + 20;
                                               //Restamos 1 a la variable serv para asi poder cumplir la condicion
                                                    serv = serv - 1;  
                                                   
                                           if(opcion==2)
                                                    total = total + 30;
                                                    serv = serv - 1;
                                                  
                                           if(opcion==3)
                                                    total = total + 49.99;
                                                    serv = serv - 1;
                                                   
                                           if(opcion==4)
                                                    total = total + 36.80;
                                                    serv = serv - 1;
                                           
                                           if(opcion==5)
                                                    total = total + 24.99;
                                                    serv = serv - 1;
                                           
                                           if(opcion==6)
                                                    total = total + 60;
                                                    serv = serv - 1;
                                          
                                         }catch (Exception e){
                                           System.out.println("Error al introducir un numero");
                                         }
                            }while(serv==fserv);
                   
       //Mostrar los resultados                 
               System.out.println("Tu oredenador con la configuracion "+conf+" costara: " +total);
               menu = menu - 1;
   }while(menu!=0);
  }
}   