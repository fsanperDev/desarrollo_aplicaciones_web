/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maquinacafe;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ ALVAREZ
 */
public class MaquinaCafe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner teclado = new Scanner(System.in);
        
        //CONSTANTES
        final int cafes = 1;
        final double leche = 0.8;
        final double cafel = 1.5;
        
        //VARIABLES
        
        int nbebidas;
    //Deposito
        int cafecap = 10;
        int lechecap = 10;
        int vasos = 16;
        
        int menu = 0;
        int moneda = 0;
        int nmonedas = 0;
        int hecharm = 0;
        double precio1 = 0;
        double precio2 = 0;
        double precio3 = 0;
       
     //Monedero 
        
        int meuro = 0;
        double mcincent = 5;
        double mvencent = 5;
        double mdiezcent = 5;
        
     //Monedas
        int euro = 1;
        double cincent = 0.5;
        double vencent = 0.2;
        double diezcent = 0.1;
        
        do{
           
           try {
            System.out.println("1. Servir café solo (1 euro)");
            System.out.println("2. Servir leche (0.8 euros)");
            System.out.println("3. Servir café con leche (1.5 euros)");
            System.out.println("4. Consultar estado de la maquina");
            System.out.println("5. Apagar maquina");
            menu = Integer.parseInt(teclado.nextLine());
           }
           catch (InputMismatchException laexcepcion)
            {
                System.out.println("Tienes que introducir un numero");
                teclado.nextLine();
            }
           //if (menu==1){
           switch(menu){
               case 1:
            /*Si elige uno primero pide cuantas monedas quere hechar,
             *   luego se repite hasta que se agota el numero,
              *  el bucle se detendra cuando se cumpla las 2 condiciones*/
               System.out.println("Cuantas monedas desea introducir");
               nmonedas=teclado.nextInt();
               while(nmonedas==hecharm && precio1==cafes){
              
               System.out.println("1. Un euro, 2. 0.50€, 3. 0.20€, 4. 0.10€");
               System.out.println("Has hechado: "+precio1);
               moneda=teclado.nextInt();
               
                if(moneda==1){
                    meuro = meuro + 1;
                    precio1 = precio1 + 1;
                }
                if(moneda==2){
                    mcincent = mcincent + 1;
                    precio1 = precio1 + 0.5;
                }
                
                if(moneda==2){
                    mvencent = mvencent + 1;
                    precio1 = precio1 + 0.2;
                }
                if(moneda==2){
                    mdiezcent = mdiezcent + 1;
                    precio1 = precio1 + 0.1;
                }
               
             /*Se va sumando de uno en uno hasta que coincide con el numero de monedas que indica antes,
             * una vez que coincide se acaba el bucle*/
               hecharm = hecharm + 1;
               }
               //Reducimos la variante de los depositos
               vasos = vasos - 1;
               cafecap = cafecap - 1;
             System.out.println("Bebida servida");
          // }
           break;
         //if(menu==2){
            case 2:                 
               System.out.println("Cuantas monedas desea introducir");
               nmonedas=teclado.nextInt();
             while(nmonedas==hecharm && precio2==leche){
              
               System.out.println("1. Un euro, 2. 0.50€, 3. 0.20€, 4. 0.10€");
               System.out.println("Has hechado: "+precio2);
               moneda=teclado.nextInt();

                if(moneda==1){
                    meuro = meuro + 1;
                    precio2 = precio2 + 1;
                }
                if(moneda==2){
                    mcincent = mcincent + 1;
                    precio2 = precio2 + 0.5;
                }
                
                if(moneda==2){
                    mvencent = mvencent + 1;
                    precio2 = precio2 + 0.2;
                }
                if(moneda==2){
                    mdiezcent = mdiezcent + 1;
                    precio2 = precio2 + 0.1;
                }

               hecharm = hecharm + 1;
       
               }
               vasos = vasos - 1;
               lechecap = lechecap - 1;
               System.out.println("Bebida servida");
          // }
        break;
         //if(menu==3){
            case 3:                  
               System.out.println("Cuantas monedas desea introducir");
               nmonedas=teclado.nextInt();
               while(nmonedas==hecharm && precio3==cafel){
              
               System.out.println("1. Un euro, 2. 0.50€, 3. 0.20€, 4. 0.10€");
               System.out.println("Has hechado: "+precio3);
               moneda=teclado.nextInt();

                if(moneda==1){
                    meuro = meuro + 1;
                    precio3 = precio3 + 1;
                }
                if(moneda==2){
                    mcincent = mcincent + 1;
                    precio3 = precio3 + 0.5;
                }
                
                if(moneda==2){
                    mvencent = mvencent + 1;
                    precio3 = precio3 + 0.2;
                }
                if(moneda==2){
                    mdiezcent = mdiezcent + 1;
                    precio3 = precio3 + 0.1;
                }

               hecharm = hecharm + 1;
       
               }
               
               vasos = vasos - 1;
               cafecap = cafecap - 1;
               lechecap = lechecap - 1;
             System.out.println("Bebida servida");
          // }
        break;
        
         //if(menu==4){
            case 4:
             System.out.println("Deposito cafe: "+cafecap);
             System.out.println("Deposito cafe: "+lechecap);
             System.out.println("Deposito cafe: "+vasos);
             System.out.println("Monedas de 1 euro: "+meuro);
             System.out.println("Monedas de 50 centimos: "+mcincent);
             System.out.println("Monedas de 1 euro: "+mvencent);
             System.out.println("Monedas de 1 euro: "+mdiezcent);
        // }
         break; 
        }
        }while(menu!=5);
        System.exit(0);
                
        
    }
    
}
