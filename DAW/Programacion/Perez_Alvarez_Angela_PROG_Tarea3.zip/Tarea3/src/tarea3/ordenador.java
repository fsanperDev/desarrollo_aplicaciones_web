/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea3;


/**
 * Clase que elige el tipo de ordenador
 * @author FENRIR
 */
public class ordenador {
    //VARIABLES
 
        private int _tiposobremesa;
        private int _tipoportatil;
        private int _tipobarebone;
        
    
    //CLASES
    public ordenador(){}    
        
    /**
     * 
     * @param Tiposobremesa  Tipo de ordenador sobremesa
     * @param Tipoportatil  Tipo de ordenador portatil
     * @param Tipobarebone  Tipo de ordenador Barebone
     */
    public ordenador(int Tiposobremesa,int Tipoportatil, int Tipobarebone){
        _tiposobremesa = Tiposobremesa;
        _tipoportatil = Tipoportatil;
        _tipobarebone = Tipobarebone;
    }
    
    
    /**
     * Devuelve 800, coste del Sobremesa
     * @return 
     */
    public int Tiposobremesa (){
        return +800;
        
    }
    
    /**
     * Devuelve 600, coste del portatil
     * @return 
     */
    public int Tipoportatil (){
        return +600;
    }
    
    /**
     * Devuelve 400, coste del barebone
     * @return 
     */
    public int Tipobarebone (){
        return +400;
    }
    
    /**
     * Devuelve el nombre Sobremesa
     * @return 
     */
    public String NombSobremesa(){
        return "Sobremesa";
    } 
    
    /**
     * Devuelve el nombre Portatil
     * @return 
     */
    public String NombPortatil(){
        return "Portatil";
    } 
   
    /**
     * Devuelve el nombre Barebone
     * @return 
     */
    public String NombBarebone(){
        return "Barebone";
    } 
    
    
}
