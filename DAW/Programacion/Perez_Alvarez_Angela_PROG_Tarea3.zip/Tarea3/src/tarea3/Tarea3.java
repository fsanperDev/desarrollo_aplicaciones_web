/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea3;

import java.util.Scanner;
/**
 *
 * @author ANGELA PEREZ
 */
public class Tarea3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
    //VARIABLES
     
      boolean salir = false;
      int menu2 = 0;
     //Opciones de Tipo de PC
      int opc1 = 0;
      final String sob = "Sobremesa";
      final String port = "Portatil";
      final String bare = "Barebone";
      String tipopc = "";
      
     //Opciones de configuracion de PC
      int opc2 = 0;
      String confpc = "";
      
     //Servicios
      int opc3 = 0; 
      boolean errorOpc3 = true;
      boolean finservicios = true;
      
     //Opciones de Srevicios
     int opc4 = 0;
     int nserv = 0;
     boolean errornserv = true;
     final int precserv = 0;
     int totalserv = 0;
     
     //Cuenta total
      int total = 0;
      int elegirservA = 0;
      int elegirservB = 0;
      int elegirservC = 0;
      int elegirservD = 0;
      int elegirservE = 0;
      int elegirservF = 0;
      
    
    //Aquí empieza 
     
     do{
      //Llamar al menu de inicio y a la clase ordenador
        menu2 = tarea3.Tarea3.menuPrincipal(0, 0);
        
        ordenador tipoordenador = new ordenador();
        
        
        
       System.out.println("Selecciona el tipo de ordenador:");
       System.out.println("1 Sobremesa 800€");
       System.out.println("2. Portatil 600€");
       System.out.println("3. Barebone 400€");
       opc1 = teclado.nextInt();
        switch(opc1){
            case 1:
                opc1 = tipoordenador.Tiposobremesa();
                
                break;
            case 2:
                opc1 = tipoordenador.Tipoportatil();
                
                break;
            case 3:
                opc1 = tipoordenador.Tipobarebone();
                
                break;
            
        }do{
                if(opc1 != 800){
                    tipopc = tipoordenador.NombSobremesa();
                } if (opc1 != 600){
                     tipopc = tipoordenador.NombPortatil();
                } else {
                    tipopc = tipoordenador.NombBarebone();
                }
        }while(opc1 >= 100);
          
        
        //Elegir la configuracion de ordenador
        configuracion configuracionpc = new configuracion();
        System.out.println("Ahora elige la configuración para su ordenador: ");
        System.out.println("1. Gamer 300€");
        System.out.println("2. Estandar 0€");
        System.out.println("3. Multimedia 200€");
        opc2 = teclado.nextInt();
        switch(opc2){
            case 1:
                opc2 = configuracionpc.PrecioGamer();
                
                break;
            case 2:
                opc2 = configuracionpc.PrecioEstandar();
                
                break;
            case 3:
                opc2 = configuracionpc.PrecioMultimedia();
                
                break;
        }do{
                if(opc2 != 300){
                    confpc = configuracionpc.NombGamer();
                } if (opc1 != 200){
                     confpc = configuracionpc.NombMultimedia();
                } else {
                    confpc = configuracionpc.NombEstandar();
                }
            }while(opc2 >= 0);
        
        //Preguntar si desea servicios
        servicios serv = new servicios();
        do{
           System.out.println("¿Desea algún servicio extra?");
           System.out.println("1. Si");
           System.out.println("2. No");
             do{
                try {
                    opc3 = teclado.nextInt();
                    if((opc3>0) && (opc3<3)){
                        System.out.println("");
                        errorOpc3 = false;
                    }
                }catch(Exception e) {
                         System.out.println("Error al introducir numero");
                         errorOpc3 = true;
                         teclado.nextLine();
                }
             }while(errorOpc3 == true); 
             if(opc3==2){
                 finservicios=false;
              }else{
             //Elegir los servicios
             System.out.println("Estos son nuestros servicios: "
                     +" 1."+ serv.Text_Arranque()+" "+serv.PrecioArranque()+" € "
                     +" 2."+ serv.Text_Solucion()+" "+serv.PrecioSolucion()+" € "
                     +" 3."+ serv.Text_Soporte()+" "+serv.PrecioSoporte()+" € "
                     +" 4."+ serv.Text_InstalarSO()+" "+serv.PrecioSO()+" € "
                     +" 5."+ serv.Text_InstHard()+" "+serv.PrecioHard()+" € "
                     +" 5."+ serv.Text_Gestion()+" "+serv.PrecioGestion()+" € "
                     + " ¿Cuantos servicios deseas? " );
                  nserv = teclado.nextInt();
                do{
                   
                     System.out.println("Servicios: "
                        +" 1."+ serv.Text_Arranque()+" "+serv.PrecioArranque()+" € "
                        +" 2."+ serv.Text_Solucion()+" "+serv.PrecioSolucion()+" € "
                        +" 3."+ serv.Text_Soporte()+" "+serv.PrecioSoporte()+" € "
                        +" 4."+ serv.Text_InstalarSO()+" "+serv.PrecioSO()+" € "
                        +" 5."+ serv.Text_InstHard()+" "+serv.PrecioHard()+" € "
                        +" 5."+ serv.Text_Gestion()+" "+serv.PrecioGestion()+" € " );
                        opc4 = teclado.nextInt();
                        switch(opc4){
                          
                            case 1:
                                opc4 = serv.PrecioArranque();
                                totalserv=precserv+opc4;
                                nserv--;
                                elegirservA++;
                                break;
                            case 2:
                                opc4 = configuracionpc.PrecioEstandar();
                                totalserv=precserv+opc4;
                                nserv--;
                                elegirservB++;
                                break;
                            case 3:
                                opc4 = configuracionpc.PrecioMultimedia();
                                totalserv=precserv+opc4;
                                nserv--;
                                elegirservC++;
                                break;
                            case 4:
                                opc4 = configuracionpc.PrecioEstandar();
                                totalserv=precserv+opc4;
                                nserv--;
                                elegirservD++;
                                break;
                            case 5:
                                opc4 = configuracionpc.PrecioEstandar();
                                totalserv=precserv+opc4;
                                nserv--;
                                elegirservE++;
                                break;
                            case 6:
                                opc4 = configuracionpc.PrecioEstandar();
                                totalserv=precserv+opc4;
                                nserv--;
                                elegirservF++;
                                break;
                        }
                    }while(nserv == 0);
                   } finservicios = false;
                   
               } while(finservicios=false);
        
        
      //Reunir el total en una sola variable y dar la cuenta final 
        total = opc1+opc2+totalserv;
      System.out.println("Ustede ha elegido un ordenador: "+tipopc);
      System.out.println("con la configuracion: "+confpc);
      System.out.println("y el/los servicios: "
                     +elegirservA+" "+ serv.Text_Arranque()+" "+serv.PrecioArranque()+" € "
                     +elegirservB+" "+ serv.Text_Solucion()+" "+serv.PrecioSolucion()+" € "
                     +elegirservC+" "+ serv.Text_Soporte()+" "+serv.PrecioSoporte()+" € "
                     +elegirservD+" "+ serv.Text_InstalarSO()+" "+serv.PrecioSO()+" € "
                     +elegirservE+" "+ serv.Text_InstHard()+" "+serv.PrecioHard()+" € "
                     +elegirservF+" "+ serv.Text_Gestion()+" "+serv.PrecioGestion()+" € ");
      System.out.println("El total sera de: "+total);
     }while(!salir);
    }
   
  //Este es el primer menu
    static int menuPrincipal(int hacerpedido, int apagar){ 
            Scanner teclado = new Scanner(System.in);
        //Menu de Inicio
         int menuprincipal = 0;
         boolean errorOpcPrincipal = false; 

            System.out.println("Bienvenido");
            System.out.println(hacerpedido+"1. Hacer pedido");
            System.out.println(apagar+"2. Salir");

            do{
                try{
                  menuprincipal = teclado.nextInt();
                  if ((menuprincipal > 0) && (menuprincipal < 3)){
                     System.out.println("Nueva compra");
                     errorOpcPrincipal = false;
                  } else {
                        System.out.println("Opción elegida no valida... Intentelo de nuevo");
                        errorOpcPrincipal = false;
                    }
                }catch (Exception e) {
                    System.out.println("Error");
                    errorOpcPrincipal = true;
                    teclado.nextLine();
                }
              }while(errorOpcPrincipal);
            return menuprincipal;
        }    
}
