/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea3;

/**
 *
 * @author ANGELA PEREZ
 */
public class servicios {
    
    final String _arranque = "Arranque Inicial";
    final String _solucionvirus = "Solución de virus";
    final String _soporte = "Soporte Informatico";
    final String _instSO = "Instalar SO";
    final String _instHard = "Instalar Hardware";
    final String _gestionHD = "Gestion de datos HD";
    
    final int _parranque = 20;
    final int _psolucion = 30;
    final int _psoporte = 49;
    final int _pinstso = 36;
    final int _phard = 24;
    final int _pgestion = 60;
    
    
    /**
     * Devuelve el precio de Arranque Inicial
     * @return 
     */
    int PrecioArranque (){
        return _parranque;
    } 
    
    /***
     * Devuelve el precio de Solucion de virus
     * @return 
     */
    int PrecioSolucion (){
        return _psolucion;
    }
    
    /**
     * Devuelve el precio de Soporte Informatico
     * @return 
     */
    int PrecioSoporte (){
        return _psoporte;
    }
    
    /**
     * Devuelve el precio de Instalar SO
     * @return 
     */
    int PrecioSO (){
        return _pinstso;
    }
    
    /**
     * Devuelve el precio de Instalar Hardware
     * @return 
     */
    int PrecioHard (){
        return _phard;
    }
    
    /**
     * Devuelve el precio de Gestion e datos HD
     * @return 
     */
    int PrecioGestion (){
        return _pgestion;
    }
    
    /**
     * Devuelve el texto "Arranque Inicial"
     * @return 
     */
    public String Text_Arranque (){
        return _arranque;
    }
    
    /**
     * Devuelve el texto "Solucion de virus"
     * @return 
     */
    public String Text_Solucion (){
        return _solucionvirus;
    }
    
    /**
     * Devuelve el texto "Soporte informatico"
     * @return 
     */
    public String Text_Soporte (){
        return _soporte;
    }
    
    /**
     * Devuelve el texto "Instalar SO"
     * @return 
     */
    public String Text_InstalarSO (){
        return _instSO;
    }
    /**
     * Devuelve el texto "Instalar Hardware"
     * @return 
     */
    public String Text_InstHard (){
        return _instHard;
    }
    
    /**
     * Devuelve el texto "Gestion de datos HD"
     * @return 
     */
    public String Text_Gestion (){
        return _gestionHD;
    }
    
}
