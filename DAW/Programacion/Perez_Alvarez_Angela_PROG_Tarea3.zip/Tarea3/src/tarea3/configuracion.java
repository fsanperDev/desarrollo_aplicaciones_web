/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea3;

/**
 *
 * @author ANGELA PEREZ
 */
public class configuracion {
    
    int _pgamer = 300;
    int _pestandar = 0;
    int _pmultimedia = 200;
    
    String _gamer = "Gamer";
    String _estandar = "Estandar";
    String _multimedia = "Multimedia";
    
    
    /**
     * Devuelve el precio de la configuracion Gamer
     * @return 
     */
    int PrecioGamer (){
        return _pgamer;
    }
    
    /**
     * Devuelve el precio de la configuracion Estandar
     * @return 
     */
    int PrecioEstandar (){
        return _pestandar;
    }
    
    /**
     * Devuelve el precio de la configuracion Multimedia
     * @return 
     */
    int PrecioMultimedia (){
        return _pmultimedia;
    }
    
    /**
     * Devuelve el nombre de la configuracion Gamer
     * @return 
     */
    public String NombGamer (){
        return _gamer;
    }
    
    /**
     * Devuelve el nombre de la configuracion Estandar
     * @return 
     */
    public String NombEstandar (){
        return _estandar;
    }
     
    /**
     * Devuelve el nombre de la configuracion Multimedia
     * @return 
     */
    public String NombMultimedia (){
        return _multimedia;
    }
    
}
