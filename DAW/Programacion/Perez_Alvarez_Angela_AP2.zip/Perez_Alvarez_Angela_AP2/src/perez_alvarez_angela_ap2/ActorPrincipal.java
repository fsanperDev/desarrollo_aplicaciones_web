/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ap2;

/**
 *
 * @author ANGELA PEREZ
 */
public class ActorPrincipal extends Actor{
// CLASES
    
// ATRIBUTOS

// CONSTRUCTOR
 
// METODOS   

    public ActorPrincipal(String DNI, String Nombre, String Apellidos, int Edad, String NombreArtistico) {
        super(DNI, Nombre, Apellidos, Edad, NombreArtistico);
    }
/**
 * 
 * @return Devuelve el salario de un actor principal.
 */
@Override
    public int sueldoMensual() {
       return _salarioMinimo * 6;
    }
  
}
