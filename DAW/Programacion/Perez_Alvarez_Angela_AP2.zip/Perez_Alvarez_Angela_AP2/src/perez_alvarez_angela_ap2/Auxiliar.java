/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ap2;

import java.util.Scanner;

/**
 *
 * @author FENRIR
 */
public class Auxiliar {
    
    /**
     * Metodo para leer entre un rango numerico.
     * @param menor
     * @param mayor
     * @return 
     */
    public static int leerEntero (int menor, int mayor){
        
        Scanner miTeclado = new Scanner(System.in);
        int numeroEntero = 0;
        String numeroComoCadena ="";
        boolean correcto = true;
        
        do
        {
            try {
                numeroComoCadena = miTeclado.nextLine();
                numeroEntero = Integer.parseInt(numeroComoCadena);
                if ((numeroEntero < menor) || (numeroEntero > mayor)){
                    System.err.println("Número erroneo... ha de estar entre "+
                                        menor+" y "+mayor+
                                        ". Introduzca número de nuevo");
                    correcto = false;
                } else {
                    correcto = true;
                }                

            } catch (Exception e) {
                correcto = false;
                System.err.println("Número introducido no correcto");
            }
        }while (!correcto);
        
        return (numeroEntero);        
    }
    
}
