/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ap2;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_AP2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // CLASES
       Pelicula pelicula  = new Pelicula();
    // ARRAYS
      
    // ATRIBUTOS
        boolean salir = false;
        int opcion;
        final String txtmenu = "CATÁLOGO DE PELICULAS \n 1. Mostrar Película. \n 2. Alta de Película. \n 3. Eliminar Película. \n"
                + " 4. Salir de la aplicacion. \n";
    // -----------------------  CODIGO DEL PROGRAMA  ------------------------------------------------------------------
       
    do{
        System.out.println(txtmenu); 
        opcion = Auxiliar.leerEntero(1, 4);
        switch(opcion){
            case 1:
                pelicula.toString();
                break;
            case 2:
                // Metodo no acabado.
                pelicula.DarDeAlta();
                break;
            case 3:
                pelicula.EliminarPelicula();
                break;
            case 4:
                salir = true;
                break;
        }        
    }while(!salir);
        
        
        
    }
    
}
