/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ap2;

/**
 *
 * @author ANGELA PEREZ
 */
public class Actor  extends Persona{
// CLASES
    
// ATRIBUTOS
   protected String _nombreArtistico;
// CONSTRUCTOR
 
// METODOS    

    public Actor(String DNI, String Nombre, String Apellidos, int Edad, String NombreArtistico) {
        super(DNI, Nombre, Apellidos, Edad);
        _nombreArtistico = NombreArtistico;
    }
   
}
