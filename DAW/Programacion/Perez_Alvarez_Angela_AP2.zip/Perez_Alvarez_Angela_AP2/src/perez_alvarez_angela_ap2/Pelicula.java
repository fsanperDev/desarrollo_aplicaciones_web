/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ap2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class Pelicula {
// CLASES
    Scanner teclado = new Scanner(System.in);
// ATRIBUTOS
   private String _nombre;
   private String _director;
   private int _anno;
   private String _genero;
   private int[] _actores = new int[20];
   private int _nuemroDePeliculas;
   private String[] _peliculas;
   private int _sueltoTotalActores;
  // private int _numeroDeActores;
// CONSTRUCTOR
   /**
    * Constructor para el maximo de peliculas.
    */
   public Pelicula(){
     _peliculas = new String[100];
     _nuemroDePeliculas = 0;
     
   }
   
// METODOS  
   
public void DarDeAlta(){
    /**
     * Preguntas para dar de alta la nueva pelicula.
     */
    System.out.println("Nombre de la Pelicula. \n");
    _nombre = teclado.nextLine();
    System.out.println("Nombre del Director.\n");
    _director = teclado.nextLine();
    System.out.println("Año de estreno.\n");
    _anno = teclado.nextInt();
    System.out.println("Genero: ");
    _genero = teclado.nextLine();
    System.out.println("\n¿Cuantos actores dedea introducir?\n");
    /**
     * Utilizo un bucle para que introduzca tanto actores como ha solicitado.
     */
    int _nuemroActores = teclado.nextInt();
    do{
        // Segun el tipo de actor llamo a una de sus clases.
        System.out.println("¿Que tipo de actor es? \n1.Actor Principal \n2. Actor Secundario \n3. Actor de Reparto");
        int opcion = Auxiliar.leerEntero(1, 3);
        switch(opcion){
            case 1:                 
                break;
            case 2:
                break;
            case 3:
                break;
        }
        
    }while(_nuemroActores == 0);
    
    
}   
/**
 * Metodo para eliminar una pelicula.
 */
public void EliminarPelicula(){
    for (int i = 0; i < _nuemroDePeliculas; i++) {
        System.out.println(i+" - "+_peliculas[i]);
    }
    System.out.println("¿Que pelicula deseas eliminar? \n");
    int numPelicula = teclado.nextInt();
    System.out.println("¿Estas seguro que deseas eliminar la pelicula "+_peliculas[numPelicula]+"?\n 1 = Si   2 = NO ");
    int opcion = Auxiliar.leerEntero(1, 2);
    if(opcion == 1){
        _peliculas[numPelicula] = "";
        _nuemroDePeliculas--;
        for (int i = 0; i < _nuemroDePeliculas; i++) {
            _peliculas[i]= _peliculas[i-1];
        }
    }
    if(opcion == 2){
        System.out.println("Saliendo de la opcion Eliminar pelicula.");
    }
} 
/**
 * Muestra las peliculas.
 * @return 
 */     
@Override
    public String toString(){    
        StringBuilder elementosComoCadena = new StringBuilder();
        for (int i = 0; i < _nuemroDePeliculas; i++) {
            elementosComoCadena.append(" - "+_peliculas[i]+"\n");
    }        
        return elementosComoCadena.reverse().toString();
    }
    
   
  
   public int sueldoDeActores(){       
    return _sueltoTotalActores;
   }
}
