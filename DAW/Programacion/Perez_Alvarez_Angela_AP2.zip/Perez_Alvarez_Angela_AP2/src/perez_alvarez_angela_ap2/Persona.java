/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_ap2;

/**
 *
 * @author ANGELA PEREZ
 */
class Persona implements InterfacePersona{
// CLASES
    
// ATRIBUTOS
   protected String _DNI;
   protected String _Nombre;
   protected String _Apellidos;
   protected int _edad;
   final static int _salarioMinimo = 900;
// CONSTRUCTOR
   public Persona(String DNI, String Nombre, String Apellidos, int Edad){
       _DNI = DNI;
       _Nombre = Nombre;       
       _Apellidos = Apellidos;
       _edad = Edad;
   }
// METODOS
   
    @Override
    public int sueldoMensual() {
       return _salarioMinimo;
    }

    @Override
    public void mostrar() {
        System.out.println( _DNI+ _Nombre +_Apellidos +_edad); 
    }
    

    
}
