/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea5;

/**
 *
 * @author ANGELA PEREZ
 */
public class Sudoku {
  // CLASES
    
  // ARRAY
    //---  Sudoku 1   ----------------------------------------------------------
      // Solucion
        protected int[][] sudoku1Solucion = {
                {6, 9, 2, 3, 8, 4, 1, 5, 7}, 
                {5, 7, 8, 2, 1, 6, 3, 9, 4}, 
                {1, 3, 4, 7, 5, 9, 2, 6, 8},
                {8, 5, 7, 9, 4, 2, 6, 1, 3},
                {9, 1, 6, 8, 3, 5, 7, 4, 2},
                {4, 2, 3, 1, 6, 7, 5, 8, 9},
                {7, 8, 9, 5, 2, 1, 4, 3, 6},
                {2, 6, 1, 4, 9, 3, 8, 7, 5},
                {3, 4, 5, 6, 7, 8, 9, 2, 1},
            };
    // TABLERO SUDOKU 1
        protected int[][] sudoku1Tablero = {
                {0, 9, 0, 0, 0, 4, 0, 5, 0}, 
                {5, 7, 0, 2, 0, 6, 3, 0, 0}, 
                {0, 3, 0, 0, 0, 0, 0, 0, 8},
                {0, 0, 0, 0, 4, 0, 6, 1, 3},
                {9, 0, 0, 0, 3, 0, 7, 0, 0},
                {4, 2, 0, 0, 0, 0, 0, 8, 0},
                {7, 0, 0, 5, 2, 0, 0, 3, 0},
                {2, 6, 0, 0, 0, 0, 8, 7, 0},
                {0, 4, 5, 0, 0, 0, 9, 0, 0},
            };
    //---  Sudoku 2   ----------------------------------------------------------
      // Solucion
       protected int[][] sudoku2Solucion = {
                {6, 8, 5, 2, 3, 7, 1, 4, 9},
                {2, 9, 7, 6, 4, 1, 3, 8, 5},
                {3, 4, 1, 8, 5, 9, 6, 2, 7},
                {5, 2, 4, 9, 1, 3, 8, 7, 6},
                {7, 6, 8, 4, 2, 5, 9, 1, 3},
                {1, 3, 9, 7, 8, 6, 4, 5, 2},
                {8, 5, 2, 3, 6, 4, 7, 9, 1},
                {4, 7, 6, 1, 9, 2, 5, 3, 8},
                {9, 1, 3, 5, 7, 8, 2, 6, 4},
            };
    // TABLERO SUDOKU 2
        protected int[][] sudoku2Tablero = {
                {0, 0, 0, 0, 0, 0, 0, 4, 9},
                {0, 0, 7, 6, 0, 0, 3, 0, 0},
                {3, 0, 1, 0, 0, 0, 0, 0, 7},
                {0, 2, 4, 0, 0, 0, 0, 0, 0},
                {0, 6, 0, 0, 0, 0, 0, 1, 0},
                {0, 0, 0, 7, 0, 0, 0, 5, 2},
                {8, 0, 2, 3, 0, 0, 0, 0, 1},
                {0, 0, 0, 0, 9, 0, 5, 0, 0},
                {0, 0, 3, 0, 0, 8, 0, 6, 0},
            };
    
  // ATRIBUTOS
       
  // CONSTRUCTOR
    Sudoku(){
        
    };
  // METODOS
    
/**
 * Metodo para mostrar el tablero del Sudoku 1.
 */
    public void MostrarSudoku1(){
        for (int fila = 0; fila < sudoku1Solucion.length; fila++) {
                for (int columna = 0; columna < sudoku1Solucion.length; columna++) {
                    System.out.print(sudoku1Solucion[fila][columna]+"   ");                    
                }
                System.out.println("\n");
            }
    }
/**
 * Metodo para mostrar el tablero del Sudoku 2.
 */    
    public void MostrarSudoku2(){
        for (int fila = 0; fila < sudoku2Solucion.length; fila++) {
                for (int columna = 0; columna < sudoku2Solucion.length; columna++) {
                    System.out.print(sudoku2Solucion[fila][columna]+"   ");                    
                }
                System.out.println("\n");
            }
    }
}
