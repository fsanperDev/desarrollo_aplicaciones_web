/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea5;

import javax.swing.JOptionPane;
import java.util.Arrays;

/**
 *
 * @author ANGELA PEREZ ALVAREZ
 */
public class Tablero {
    // CLASES
    Sudoku sudoku = new Sudoku();     
    // ARRAY 
     private int[][] sudokuPartida = new int[9][9];
     private int[][] sudokuTableroComprobacion = new int[9][9];
     private int[][] sudokuTableroSolucion = new int[9][9];
    // ATRIBUTOS
     private int _sector;
     private int _sectorDeLaFila;
     private int _numeroDeLaFila;
     private int _sectorDeLaColumna;
     private int _numeroDeLaColumna;
     private int _numeroAIntroducir;
     private int _noCompleto;
     private boolean _arraysIguales;
     private boolean _comprobacion2;
     
    // CONSTRUCTOR
        Tablero(){
            _sector = 0;
            _sectorDeLaFila = 0;
            _numeroDeLaFila = 0;
            _sectorDeLaColumna = 0;
            _numeroDeLaColumna = 0;
            _numeroAIntroducir = 0;
            _noCompleto = 0;
            _arraysIguales = false;
            _comprobacion2 = false;
        }
    // METODO
    /**
     * Metodo para copiar el Tablero 1 en el array de la partida. 
     */
    public void CrearTablero1(){
        for (int fila = 0; fila < sudokuPartida.length; fila++) {
            for (int columna = 0; columna < sudokuPartida.length; columna++) {
               sudokuPartida[fila][columna] = sudoku.sudoku1Tablero[fila][columna];
               sudokuTableroComprobacion[fila][columna] = sudoku.sudoku1Tablero[fila][columna];
               sudokuTableroSolucion[fila][columna] = sudoku.sudoku1Solucion[fila][columna];
            }                                    
       }  
    }
    /**
     * Metodo para copiar el Tablero 2 en el array de la partida.
     */
    public void CrearTablero2(){
        for (int fila = 0; fila < sudokuPartida.length; fila++) {
            for (int columna = 0; columna < sudokuPartida.length; columna++) {
               sudokuPartida[fila][columna] = sudoku.sudoku2Tablero[fila][columna];
               sudokuTableroComprobacion[fila][columna] = sudoku.sudoku2Tablero[fila][columna];
               sudokuTableroSolucion[fila][columna] = sudoku.sudoku2Solucion[fila][columna];
            }                                    
       }  
    }
    
    /**
     * Metodo para mostrar el tablero con el que se esta jugando.
     */
    public void MostrarTableroDePartida(){
            for (int fila = 0; fila < sudokuPartida.length; fila++) {
                for (int columna = 0; columna < sudokuPartida[0].length; columna++) {
                    if(sudokuPartida[fila][columna] == 0){
                        System.out.print(" _  ");
                    }else{
                        if(sudokuPartida[fila][columna] == sudokuTableroComprobacion[fila][columna]){
                            System.out.print("\033[30m"+sudokuPartida[fila][columna]+"   "); 
                        }else{
                            System.out.print("\033[31m"+sudokuPartida[fila][columna]+"   ");
                        }
                    }
                }
                System.out.println("\n");
            }
    }
    
    /**
     * Metodo para seleccionar la fila del sudoku.
     */
    public void SeleccionarNumeroFila(){
        boolean numeroSalir = false;
        //Creamos un bucle para que en caso de error vuelva a preguntar.
        do{
            _numeroDeLaFila = Integer.parseInt(JOptionPane.showInputDialog(null,"Inserte el nuemro de la fila (1 - 9)"));
            /**
             * En caso de ser correcto procedera, con otras sentencias IF, a calcular el sector al que pertenece la fila
             * y lo guandara en una variable que luego utilizaremos para localizar el sector en el metodo que comprueba
             * si es posible o no colocar el numero es dicha posición, además de cambiar la variable "numeroSalir" para 
             * poder salir del bucle.
             */
            // Si el numero no es correcto, saltara la ventana de error y volvera a preguntar.
            if(_numeroDeLaFila <= 0 || _numeroDeLaFila >= 10){
                JOptionPane.showMessageDialog(null, "¡Numero incorrecto!, Tienes que introducir un numero entre 1 y 9.", "ERROR", JOptionPane.WARNING_MESSAGE);
            }else{
                if(_numeroDeLaFila > 0 && _numeroDeLaFila < 10){
                    if(_numeroDeLaFila >= 1 && _numeroDeLaFila <= 3){_sectorDeLaFila = 0; _numeroDeLaFila--; }
                    if(_numeroDeLaFila >= 4 && _numeroDeLaFila <= 6){_sectorDeLaFila = 3; _numeroDeLaFila--; }
                    if(_numeroDeLaFila >= 7 && _numeroDeLaFila <= 9){_sectorDeLaFila = 6; _numeroDeLaFila--; }
                    numeroSalir = true;
                 // Se resta 1 a '_numeroDeLaFila' debido a que el array empieza en 0. 
                }
            }
        }while(numeroSalir != true);
       
    }
    /**
     * Metodo para seleccionar la columna del sudoku.
     */
    public void SeleccionarNumeroColumna(){
        boolean numeroSalir = false;
        do{
            _numeroDeLaColumna = Integer.parseInt(JOptionPane.showInputDialog(null,"Inserte el nuemro de la Columna (1 - 9)"));
            
            if(_numeroDeLaColumna <= 0 || _numeroDeLaColumna >= 10){
                JOptionPane.showMessageDialog(null, "¡Numero incorrecto!, Tienes que introducir un numero entre 1 y 9.", "ERROR", JOptionPane.WARNING_MESSAGE);
            }else{
                if(_numeroDeLaColumna > 0 && _numeroDeLaColumna < 10){
                    if(_numeroDeLaColumna >= 1 && _numeroDeLaColumna <= 3){_sectorDeLaColumna = 0; _numeroDeLaColumna--; }
                    if(_numeroDeLaColumna >= 4 && _numeroDeLaColumna <= 6){_sectorDeLaColumna = 3; _numeroDeLaColumna--; }
                    if(_numeroDeLaColumna >= 7 && _numeroDeLaColumna <= 9){_sectorDeLaColumna = 6; _numeroDeLaColumna--; }
                    numeroSalir = true;
                }
            }
            
        }while(numeroSalir != true);
    }
    
    /**
     *  Método para introducir un numero en el tablero del sudoku.
     */
    public void IntroducirNumero (){
        // JOptionPanel para seleccionar el numero.
        Object[] possibilities = {1, 2, 3, 4, 5, 6, 7, 8, 9};  
        _numeroAIntroducir = (Integer) JOptionPane.showOptionDialog(null,   
                "Selecciona un numero",  "ShowInputDialog",   
                JOptionPane.PLAIN_MESSAGE, 1,  null, possibilities, 0);
        // Se le suma 1 por el array que empieza en 0.        
        _numeroAIntroducir++;   
        // En caso de no haber cerrado la ventana primero comprobara si ese numero puede introducirse.         
        if(_numeroAIntroducir > 0){
            // Comprobar que no es un numero del tablero.
            if(sudokuTableroComprobacion[_numeroDeLaFila][_numeroDeLaColumna] != 0){
              JOptionPane.showMessageDialog(null, "¡No puedes sustituir un numero base del tablero!", "ERROR", JOptionPane.WARNING_MESSAGE); 
            }else{
                // Preguntar si desea sustituirlo, en caso afirmativo sustituirlo.
                int n = JOptionPane.showConfirmDialog(
                    null,
                    "Introducir numero",
                    "¿Deseas sustituir o cambiar el numero actual?",
                    JOptionPane.YES_NO_OPTION);
                if(true){
                    // Sustituir el numero en el array.
                    sudokuPartida[_numeroDeLaFila][_numeroDeLaColumna] = _numeroAIntroducir;
                }
                else {
                    JOptionPane.showMessageDialog(null, "Cancelacion de la sustitucion del numero.");
                }               
            }
        }

    }
    
    /**
     * Método para comprobar si la partida esta finalizada o no.
     * @param finalizada variable que indica si la partida finaliza, true=Si false=No
     * @return 
     */
    public boolean ComprobarSiFinalizaElTablero(boolean finalizada){
        // Comprobamos que no exista un 0 en el sudoku.
        for (int fila = 0; fila < sudokuPartida.length; fila++) {
            for (int columna = 0; columna < sudokuPartida.length; columna++) {
                if(sudokuPartida[fila][columna] == 0){
                    finalizada = true;
                    _comprobacion2 = false;                    
                }else{
                // Si no existe ningun 0, permitimos la segunda comprobación.
                    _comprobacion2 = true;
                }
            }
        }
        // En esta segunga comprobación comparamos el tablero en el que se ha jugado con el de la solución. 
        if(_comprobacion2 == true){
            for (int fila = 0; fila < sudokuPartida.length; fila++) {
                for (int columna = 0; columna < sudokuPartida.length; columna++) {
                    if(sudokuPartida[fila][columna]==sudokuTableroSolucion[fila][columna]){
                    }else{
                        _noCompleto++;
                    }
                }
            }
        if(_noCompleto == 0){_arraysIguales = true;}
        if(_arraysIguales == true){
           // Si son iguales aparecerá un mensaje y cambiara el valor de la variable a devolver para finalizar la partida.
                finalizada = false;
                JOptionPane.showMessageDialog(null, "¡FELICIDADES! Has completado el sudoku.");
            }else{
           // En caso de no ser iguales no cambiará el valor de la variable por lo que la partida no finalizara. 
                finalizada = true;
            }
        }
        _noCompleto = 0; // Reinicio la variable.
        return finalizada;        
    }
    
    
}
