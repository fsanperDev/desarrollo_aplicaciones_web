/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea5;

import javax.swing.JOptionPane;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_PRO_Tarea5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // CLASES
        Partida partida = new Partida();
        
    // VARIABLES        
        boolean salir = false; 
    // ---------------------------  EMPIEZA AQUI -----------------------------------------------------------------------
    do{
    int seleccion = JOptionPane.showOptionDialog(
        null,
        "Bienvenido", 
        "Selector de opciones",
        JOptionPane.YES_NO_CANCEL_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,    // null para icono por defecto.
        new Object[] { "Jugar", "Salir"},   // null para YES, NO y CANCEL
        "opcion 1");

        if(seleccion <= -1){
            JOptionPane.showMessageDialog(null, "¡Has cerrado lla ventana!", "ERROR", JOptionPane.WARNING_MESSAGE);
        }else{    
            if (seleccion == 0){
               System.out.println("Comienza la partida ");
               partida.MenuPartida();
            }
            if (seleccion == 1){
                System.out.println("\033[31mSaliendo de la aplicacion......");
                salir = true;
            }
        }    
    }while(salir != true);
    }
}
