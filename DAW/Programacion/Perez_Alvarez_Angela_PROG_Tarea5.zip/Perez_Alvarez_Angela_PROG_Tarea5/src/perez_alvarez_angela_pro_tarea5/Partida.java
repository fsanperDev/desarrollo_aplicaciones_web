/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea5;

import javax.swing.JOptionPane;

/**
 *
 * @author ANGELA PEREZ
 */
public class Partida {
  // CLASES
    Sudoku sudoku = new Sudoku();
    Tablero tablero = new Tablero();
  // ARRAY      
        
  // ATRIBUTOS
    private String _txtBienvenida;
    private String _txtTablero1;
    private String _txtTablero2;
    private String _separador;
    private String _txtTerminarPartida;
    int _numeroDeLaFila;
    int _numeroDeLaColumna;
    protected boolean _salir;
  // CONSTRUCTOR
    Partida(){
        _txtBienvenida = "+++ Bienvenido +++ \n Seleccina un tablero para jugar: ";
        _txtTablero1 = "--------  TABLERO 1  ---------------";
        _txtTablero2 = "--------  TABLERO 2  ---------------";
        _separador = "\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";
        _txtTerminarPartida = "\033[31mFinalizando partida.";
        _numeroDeLaFila = 0;
        _numeroDeLaColumna = 0;
        _salir = false;
    }
  // METODOS
    
    /**
     *  Menu panel para seleccionar el tablero.
     */
    public void MenuPartida(){
        System.out.println(_txtBienvenida);
        System.out.println(_txtTablero1);
        sudoku.MostrarSudoku1();
        System.out.println(_txtTablero2);
        sudoku.MostrarSudoku2();
       /**
        *  Menu para elegir un tablero y cargarlo en el array qeu se usara para jugar la partida.
        * 
        */ 
        do{
            int seleccion1 = JOptionPane.showOptionDialog( null, "Seleccione un tablero","Selector de opciones",
            JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,    // null para icono por defecto.
            new Object[] { "Tablero 1", "Tablero 2"},   // null para YES, NO y CANCEL
             "opcion 1");                

                if(seleccion1 == 0){
                    // Llamo al método para crear el tablero 1.
                    tablero.CrearTablero1();                    
                    _salir = true;
                }
                if(seleccion1 == 1){
                    // Llamo al método para crear el tablero 2.
                    tablero.CrearTablero2();
                    _salir = true;
                }                
                if(seleccion1 <= -1){
                    // En caso de cerrar la ventana que salte el error.
                    JOptionPane.showMessageDialog(null, "¡Tienes que elegir un tablero!", "ERROR", JOptionPane.WARNING_MESSAGE);
                }            
        }while(_salir == false);

        /**
         * Bucle donde se jugara la partida, primero mostrando el tablero con el que se esta jugando, luego saltara un 
         * menú que pedirá si deseas introducir un numero en dicho tablero o si deseas terminar la partida, solo podrá
         * salir sí completa el tablero o selecciona la opción de "Terminar partida". En caso de cierre la ventana saltara
         * un mensaje de error.
         */
        do{
        System.out.println(_separador);
        tablero.MostrarTableroDePartida();
        System.out.println(_separador);
        int seleccion2 = JOptionPane.showOptionDialog( null, "Seleccione opcion","Selector de opciones",
        JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,    // null para icono por defecto.
        new Object[] { "Introducir un numero", "Terminar partida"},   // null para YES, NO y CANCEL
         "opcion 1");
            if (seleccion2 <= -1){
                JOptionPane.showMessageDialog(null, "¡Has cerrado la ventana!, Si quieres salir tienes que pulsar Terminar partida.", "ERROR", JOptionPane.WARNING_MESSAGE);
            }else{
                if (seleccion2 == 0){
                    // Seleccion de la fila.
                      tablero.SeleccionarNumeroFila();
                    // Seleccion de la columna.
                      tablero.SeleccionarNumeroColumna();
                    // Numero que desea introducir o cambiar.
                      tablero.IntroducirNumero(); 
                    // Comprobar si se ha finalizado la partida.
                      tablero.ComprobarSiFinalizaElTablero(_salir);
                }else{
                    if (seleccion2 == 1){
                        System.out.println(_txtTerminarPartida);
                        _salir = false;
                    }
                }
            }            
        }while(_salir == true && tablero.ComprobarSiFinalizaElTablero(_salir) == true);
    }   
     
}
