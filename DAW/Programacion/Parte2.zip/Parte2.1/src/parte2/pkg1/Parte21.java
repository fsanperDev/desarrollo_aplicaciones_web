
package parte2.pkg1;

import java.util.Scanner;

public class Parte21 {

    //CONSTANTE
    static final String datos = " Datos personales ";
    
    
    public static void main(String[] args){
    //TECLADO
    Scanner sc = new Scanner(System.in);
    Scanner teclado = new Scanner(System.in);
    
   
    /* Aqui se recogen las variables String */
      String nombre;
      String apell;
      String deportes;
      String aficiones;
      /* Y las siguientes son las demas tipos de variable en las 
      que se requieren numeros o un caracter
      */
          short edad;
          int movil;
          char sexo;
          float altura;
          double peso;
       
    //Obtener datos 
      System.out.println("Escriba su nombre ");
      nombre = sc.nextLine();
      
      System.out.println("Escriba sus apellidos ");
      apell = sc.nextLine();
      
      System.out.println("Escribe tu edad ");
      edad=(short) teclado.nextInt();
      
      System.out.println("Eres hombre (H) o mujer (M) ");
      sexo = teclado.next().charAt(0);
      
      System.out.println("Escribe tu altura en cm ");
      altura=(float) teclado.nextInt();
     
      
      System.out.println("Escribe tu peso en kg ");
      peso=(double) teclado.nextInt();
      
      System.out.println("Escribe tu numero de movil ");
      movil=(int) teclado.nextInt();
      
      System.out.println("¿Practicas algun deporte? ");
      deportes = sc.nextLine();
      
      System.out.println("Escribe alguna aficion que tengas ");
      aficiones  = sc.nextLine(); 

   //Mostrar los datos obtenidos
      System.out.println(datos);
      System.out.println("Nombre: " + nombre);
      System.out.println("Apellidos: " + apell);
      System.out.println("Edad: " + edad);
      System.out.println("Sexo: " + sexo);
      System.out.println("Altura: " + altura);
      System.out.println("Peso: " + peso);
      System.out.println("Numero de movil: " + movil); 
      System.out.println("Deportes: " + deportes);
      System.out.println("Aficiones: " + aficiones);
    } 
    
    
   
}
