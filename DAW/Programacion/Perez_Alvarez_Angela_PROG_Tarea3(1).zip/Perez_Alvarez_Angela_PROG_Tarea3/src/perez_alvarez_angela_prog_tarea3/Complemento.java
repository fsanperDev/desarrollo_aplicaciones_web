/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_tarea3;

/**
 *
 * @author ANGELA PEREZ
 */
public class Complemento {
// ATRIBUTOS
    private int _accesorio;
    private int _lapiz;
    private int _protector;
    private int _funda = 1;
    private int _auriculares;
    private int _antena;
    private int _cable;
    String _accesoriosSeleccionados;
    int _precioAccesorios;
    
// CONSTRUCTOR
    public Complemento (){
     _accesorio = 0;
     _lapiz = 1;
     _protector = 1;
     _funda = 1;
     _auriculares = 1;
     _antena = 1;
     _cable = 1;
     _accesoriosSeleccionados = "";
    _precioAccesorios = 0;
    }
// METODOS
    public void accesorios(int opcionMenu){
        System.out.println("¿Deseas añadir algún accesorio? (Puedes elegir un maximo de 3 accesorios,"
                + "si no deseas ninguno selecciona 0)\n");
        opcionMenu = LeerTeclado.LeerRango(0, 3);
            while(opcionMenu > 0){
                System.out.println("Seleccione los accesorios que deseas: \n"
                        + "Pulse 1 para - Lápiz 3€ \n"
                        + "Pulse 2 para - Protector de pantalla 6€ \n"
                        + "Pulse 3 para - Funda 10€ \n"
                        + "Pulse 4 para - Auriculares 15€ \n"
                        + "Pulse 5 para - Antena FM 2€ \n"
                        + "Pulse 6 para - Cable lector USB 8€ \n");
                _accesorio = LeerTeclado.LeerRango(1, 6);
                switch(_accesorio){
                    case 1:
                        if(_lapiz == 1){
                            _accesoriosSeleccionados = _accesoriosSeleccionados + " Lápiz,";
                            _lapiz--;
                            _precioAccesorios = _precioAccesorios + 3;
                            opcionMenu--;
                        }else{
                            System.err.println("Error, ya has seleccionado este accesorio.");
                        }
                        break;
                    case 2:
                        if(_protector == 1){
                            _accesoriosSeleccionados = _accesoriosSeleccionados + " Protector de pantalla,";
                            _protector--;
                            _precioAccesorios = _precioAccesorios + 6;
                            opcionMenu--;
                        }else{
                            System.err.println("Error, ya has seleccionado este accesorio.");
                        }
                        break;
                    case 3:
                        if(_funda == 1){
                            _accesoriosSeleccionados = _accesoriosSeleccionados + " Funda,";
                            _funda--;
                            _precioAccesorios = _precioAccesorios + 10;
                            opcionMenu--;
                        }else{
                            System.err.println("Error, ya has seleccionado este accesorio.");
                        }
                        break;
                    case 4:
                        if(_auriculares == 1){
                            _accesoriosSeleccionados = _accesoriosSeleccionados + " Auriculares,";
                            _auriculares--;
                            _precioAccesorios = _precioAccesorios + 15;
                            opcionMenu--;
                        }else{
                            System.err.println("Error, ya has seleccionado este accesorio.");
                        }
                        break;
                    case 5:
                        if(_antena == 1){
                            _accesoriosSeleccionados = _accesoriosSeleccionados + " Antena FM,";
                            _antena--;
                            _precioAccesorios = _precioAccesorios + 2;
                            opcionMenu--;
                        }else{
                            System.err.println("Error, ya has seleccionado este accesorio.");
                        }
                        break;
                    case 6:
                        if(_cable == 1){
                            _accesoriosSeleccionados = _accesoriosSeleccionados + " Cable lector USB,";
                            _cable--;
                            _precioAccesorios = _precioAccesorios + 8;
                            opcionMenu--;
                        }else{
                            System.err.println("Error, ya has seleccionado este accesorio.");
                        }
                        break;
                }
            }
    }
    
    /**
     * Metodo que devuelve en un String los accesorios seleccionados.
     * @return 
     */
    public String accesoriosSeleccionados(){
        return _accesoriosSeleccionados;
    }
    /**
     * Metodo que devuelve la suma total de los precios de los accesorios.
     * @return Precio de los accesorios seleccionados.
     */
    public int precioDeAccesorios(){
        return _precioAccesorios;
    }
}
