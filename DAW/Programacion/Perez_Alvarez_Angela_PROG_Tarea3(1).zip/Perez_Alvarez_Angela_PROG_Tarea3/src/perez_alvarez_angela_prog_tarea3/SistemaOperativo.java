/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_tarea3;

/**
 *
 * @author ANGELA PEREZ
 */
public class SistemaOperativo {
  // ATRIBUTOS
    String _sistemaOperativo = " ";       
    
  // METODOS
    /**
     * Metodo para mostrar el texto del menu de Sistemas Operativos.
     */
    public void textoOpcion(){
        System.out.println("Eligue un sistema operativo:\n"
                + "Pulse 1 para Android \n"
                + "Pulse 2 para IOS \n"
                + "Pulse 3 para Windows \n");
    }
    
    /**
     * Metodo para seleccionar un Sistema Operativo.
     * @param opcionMenu Selecciona el SO.
     */
    public void seleccionSO(int opcionMenu){
        opcionMenu = LeerTeclado.LeerRango(1, 3);
        switch(opcionMenu){
            case 1:
                _sistemaOperativo = "Android";
                break;
            case 2:
                _sistemaOperativo = "IOS";
                break;
            case 3:
                _sistemaOperativo = "Windows";
                break;
        }
    }
/**
 * Devuelve, en forma de texto, el Sistema Operativo seleccionado.
 * @return 
 */    
    public String SOseleccionado(){
        return _sistemaOperativo;
    }

}
