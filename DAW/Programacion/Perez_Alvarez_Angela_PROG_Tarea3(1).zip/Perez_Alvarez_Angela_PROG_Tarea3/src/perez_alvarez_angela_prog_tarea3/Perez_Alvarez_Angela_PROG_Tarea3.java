/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_tarea3;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_PROG_Tarea3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
// CLASES
    SistemaOperativo SO = new SistemaOperativo();
    Gama gama = new Gama();
    Complemento complemento = new Complemento();
    
//  VARIABLES
        boolean salir = false;
        int opcionMenu = 0;
        int precioTotal = 0;
        String textoMenuPrincipal = "*****  BIENVENIDO  ******* \n Pulse 1 para hacer un presupuesro \n Pulse 2 parar salir";

/**
 * AQUI EMPIEZA EL PROGRAMA
 */ 
//------------------------------    MENU INICIAL   --------------------------------------------------------------------
      do{
        System.out.println(textoMenuPrincipal);
        opcionMenu = LeerTeclado.LeerRango(1, 2);
        switch(opcionMenu){
            case 1:
//-----------------------------  MENU PARA SELECCIONAR EL SISTEMA OPERATIVO --------------------------------------------
                SO.textoOpcion();
                SO.seleccionSO(opcionMenu);
//----------------------------  MENU PARA SELECCIONAR LA GAMA  ----------------------------------------------------------
                gama.textoOpcion();
                gama.seleccionGama(opcionMenu);
//---------------------------  MENU PARA SELECCIONAR EL NUMERO DE ACCESORIOS --------------------------------------------
                complemento.accesorios(opcionMenu);
//---------------------------  MOSTRAR POR PANTALLA TODO LO SELECCIONADO  -----------------------------------------------
                System.out.println("***  PRESUPUESTO  ***\n"
                    + "- Sistema Operativo elegido: "+SO.SOseleccionado()+"\n "
                    + "- Gama seleccionada: "+gama.devolverGama()+"\n "
                    + "- Accesorios: "+complemento.accesoriosSeleccionados()+"\n");
                        precioTotal = precioTotal + gama.devolverPreciogama()+ complemento.precioDeAccesorios();
                System.out.println("Total: "+precioTotal+"€\n");
                break;
            case 2:
                salir = true;
        }
      }while(!salir);
    }
    
}
