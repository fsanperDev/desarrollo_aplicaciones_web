/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_tarea3;

/**
 *
 * @author ANGELA PEREZ
 */
public class Gama {
// ATRIBUTOS
    String _gama;
    int _precioG;
// CONSTRUCTOR
    public Gama (){
        _gama = "";
        _precioG = 0;
    }
    
// METODOS
    /**
     * Devuelve el texto del menú de Gama.
     */
    public void textoOpcion(){
        System.out.println("-- Eligue la gama de telefono que desea --\n"
                + " 1. Gama Baja (o reacodicionado) - 200€\n"
                + " 2. Gama Media - 350€\n"
                + " 3. Gama Alta - 800€\n");
    }
/**
 * Metodo para seleccionar la gama.
 * @param opcionMenu Variable para seleccionar la gama.
 */  
    public void seleccionGama(int opcionMenu){
        opcionMenu = LeerTeclado.LeerRango(1, 3);
        switch(opcionMenu){
            case 1:
                _gama = "Baja";
                _precioG = 200;
                break;
            case 2:
                _gama = "Media";
                _precioG = 350;
                break;
            case 3:
                _gama = "Alta";
                _precioG = 800;
                break;
        }
    }
/**
 * Devuelve, en forma de texto, la gama seleccionada.
 * @return 
 */    
    public String devolverGama(){
        return _gama;
    }
/**
 * Devuelve el precio de la gama seleccionada.
 * @return 
 */ 
    public int devolverPreciogama(){
        return _precioG;
    }
}
