/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_prog_tarea3;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class LeerTeclado {
    
//--------------------------  METODO  -----------------------------------------------------------------------------------

/**
 * Leer una opción de menu que esté entre un rango numerico.
 * @param menor Variabre para el numero entero mínimo. 
 * @param mayor Variabre para el numero entero máximo.
 * @return 
 */    
    public static int LeerRango (int menor, int mayor){
        Scanner miTeclado = new Scanner(System.in);
        int numeroEntero = 0;
        String numeroComoCadena = "";
        boolean correcto = true;
        
        do{
            try {
                numeroComoCadena = miTeclado.nextLine();
                numeroEntero = Integer.parseInt(numeroComoCadena);
                if ((numeroEntero < menor) || (numeroEntero > mayor)){
                    System.err.println("El numero debe estar entre "+menor+" y "+mayor+". Introduzca un nuevo numero:");
                    correcto = false;
                }else{
                    correcto = true;
                }
            } catch (Exception e) {
                correcto = false;
                System.err.println("Debes introducir un numero. Vuelve a intentarlo.");
            }

        }while(!correcto);
             return (numeroEntero);        
    }
}
