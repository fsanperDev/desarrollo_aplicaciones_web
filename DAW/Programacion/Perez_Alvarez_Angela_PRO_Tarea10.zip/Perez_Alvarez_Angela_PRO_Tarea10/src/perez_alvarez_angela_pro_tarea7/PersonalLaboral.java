/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea7;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class PersonalLaboral extends Persona{
    Scanner teclado = new Scanner(System.in);
// ATRIBUTOS
    protected String _cargo;
    private String _txt_nombre = "Nombre: ";
    private String _txt_apellidos = "Apellidos: ";
    private String _txt_dni = "DNI: ";
    private String _txt_edad = "Edad: ";
    private String _txt_cargo = "Cargo actual: ";
// METODOS
    /**
     * Metodo para  dar de alta a un Profesor Interino.
     * @return 
     */
    @Override
    public String darDeAlta() {
        
        String PLaboral = "";// Variable donde guardaremos luego todos los datos.
        
        // Primero recopilamos los datos.
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_nombre);
        _nombre = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_apellidos);
        _apellidos = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_dni);
        _dni = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_edad);
        _edad = Auxiliar.leerEntero();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_cargo);
        _cargo = teclado.nextLine();
        
        // Ahora se preparan para introducirlos en una sola variable.
        PLaboral += "PERSONALLABORAL"+"\n";
        PLaboral += Auxiliar.AMARILLO+"Nombre: "+_nombre+"\n";
        PLaboral += Auxiliar.AMARILLO+"Apellidos: "+_apellidos+"\n";
        PLaboral += Auxiliar.AMARILLO+"DNI: "+_dni+"\n";
        PLaboral += Auxiliar.AMARILLO+"Edad: "+_edad+"\n";
        PLaboral += Auxiliar.AMARILLO+"Cargo actualmente: "+_cargo+"\n";
        
        return PLaboral;
    }    
    /**
     * Método que muestra los datos del Personal Laboral.
     * @return 
     */
    @Override
    public String mostrar(){
        return (Auxiliar.AMARILLO+super.mostrar()+"\n Cargo: "+_cargo);
    }
}
