/*
 *        --->  IMPORTANTE  <---
 *  El nombre del la base de datos es: tarea10
 *  El usuario es: root
 *  El la contraseña: root
 */
package perez_alvarez_angela_pro_tarea7;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_PROG_Tarea7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // CLASES
    Scanner teclado = new Scanner(System.in);
    Listin listinPersonas = new Listin();
    // ATRIBUTOS
    int opcion;
    boolean salir = false;
    String dato = "";
    final String txt_menu = "*****  LISTÍN DE CENTRO  ****** \n"
            + "1. Crear tablas en la Base de Datos.\n2. Guardar Listín  en la base de datos.\n"
            + "3. Descarga los datos de la base de datos en el Listin.\n"
            + "4. Mostrar todo el lintín.\n5. Alta en el listín.\n"
            + "6. Baja en el listín.\n7. Salir de la aplicación.\n";
    //--------------------   EMPIEZA AQUI   -----------------------------------------------------------------------------
        do {
            Auxiliar.pantalla(Auxiliar.NEGRO, txt_menu);
            opcion = Auxiliar.leerEntero(1, 7);
            switch(opcion){
            //----------------------------  CREAR LAS TABLAS  ----------------------------------------------
                case 1:
                    listinPersonas.crearTablas();
                    break;
            //----------------------------  GUARDAR LISTIN EN LA BASE DE DATOS  ---------------------------------------------
                case 2:
                    listinPersonas.insertarListinBD();
                    break;
            //---------------------------  DESCARGA LISTIN DE LA BASE DE DATOS  --------------------------------------------------
                case 3:
                    listinPersonas.cargarDatosBD();
                    break;
            //-----------------------------  MOSTRAR EL LISTIN  --------------------------------------------------------------------------------
                case 4:
                    listinPersonas.mostrarListin();
                    break;
            //-----------------------------  DAR DE ALTA  ---------------------------------------------------------------------------------
                case 5: 
                    listinPersonas.altaEnListin();
                    break;
            //--------------------------------  DAR DE BAJA  -------------------------------------------------------------------------
                case 6:                     
                    listinPersonas.bajaEnListin();
                    break;
            //---------------------------------------  SALIR  ----------------------------------------------------------------------
                case 7:
                    salir = true;
                    break;
            }
        } while (!salir);  
    
    }
    
}
