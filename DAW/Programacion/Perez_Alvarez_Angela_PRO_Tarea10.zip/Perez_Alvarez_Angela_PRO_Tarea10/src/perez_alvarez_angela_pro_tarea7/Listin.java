/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea7;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ANGELA PEREZ
 */
public class Listin {
    
    Scanner teclado = new Scanner(System.in);
    private Alumno alumno = new Alumno();
    private PFuncionario funcionario = new PFuncionario();
    private PInterino interino = new PInterino();
    private PersonalLaboral plaboral = new PersonalLaboral();
// ARRAY
    private String[] listin = new String[100];
// BASE DE DATOS
    String insertPersonaListin;    
// ATRIBUTOS
    private int _numeroDePersonas = 0;
    private int _opcion;
    private int _opcion2;
    private boolean salir = false;
    private final String _txt_darDeAlta = "¿A quien quieres dar de alta?\n 1. Alumno.\n 2. Profesor Funcionario.\n 3. Profesor Interino.\n"
            + " 4. Personal Laboral.\n ";
    private final String _txt_darDeBaja = "¿Estas seguro que desea darle de baja?\n 1 - SI\n 2 - NO\n";
// CONSTRUCTOR
    
// METODOS
    /**
     * Método para postrar el listin.
     */
    public void mostrarListin(){   
    // Se comprueba que el listin no esté vacio.
        try{
            if(_numeroDePersonas == 0){
        // Si está vacio salta la excepcion.
            throw new ListinVacio();
            }else{
        // Si no está vacio lo muestra.
                for (int i = 0; i < _numeroDePersonas; i++) {
                    if (listin[i] != null) {
                         EntradaSalida.pantalla(Auxiliar.NEGRO,listin[i]+"\n");                         
                    }else{
                        System.out.println(EntradaSalida.ROJO+listin[i]+"\n");
                    }                               
                }
            }
            }catch(ListinVacio ex){
                System.err.println(ex.getMessage());
            }
    }
    
    /**
     * Metodo para dar de alta en el listin.
     */
    public void altaEnListin(){
 // Preguntamos el tipo de persona que se va a insertar en el listin.
    Auxiliar.pantalla(Auxiliar.NEGRO, _txt_darDeAlta);
    _opcion = Auxiliar.leerEntero(1, 4);
    switch(_opcion){
        case 1:
    /* Llamamos al metodo darDeAlta que nos devolvera un String con todos los datos y lo guardamos en una variable.*/ 
        String personaDelListin = alumno.darDeAlta();
    // Buscara una pocision vacia y guardará los datos.
            for (int i = 0; i <= _numeroDePersonas; i++) {
                if (listin[i] == null) {
                    listin[i] = personaDelListin;
                }
            }
                            //Sumamos 1 al numero de personas que hay en el listin. 
                            _numeroDePersonas++;
                            break;
                        case 2:
                            String PfuncionarioDelListin = funcionario.darDeAlta();
                            for (int i = 0; i <= _numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = PfuncionarioDelListin;
                                }
                            }
                            _numeroDePersonas++;
                            break;
                        case 3:
                            String PinterinoDelListin = interino.darDeAlta();
                            for (int i = 0; i <= _numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = PinterinoDelListin;
                                }
                            }
                            _numeroDePersonas++;
                            break;
                        case 4:
                            String PLaboralDelListin = plaboral.darDeAlta();
                            for (int i = 0; i <= _numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = PLaboralDelListin;
                                }
                            }
                            _numeroDePersonas++;
                            break;
                    }
    }

    /**
     * Método para dar de baja a una persona del listin.
     */
    public void bajaEnListin(){
    do {
// Mostrar todo el listin.
        for (int i = 0; i < _numeroDePersonas; i++) {
            System.out.println(Auxiliar.NEGRO+(i)+" - "+listin[i]+"\n");
        }
// Selecciona el numero de la persona que desea dar de baja.
        _opcion = Auxiliar.leerEntero(0, 100);
// Preguntar si realmente desea eliminarlo.
        System.out.println(_txt_darDeBaja+listin[_opcion]);
        _opcion2 = Auxiliar.leerEntero(1, 2);
            if(_opcion2 == 1){                
                for (int i = _opcion; i < _numeroDePersonas; i++) {
                    listin[i] = listin[i+1];
                }
                _numeroDePersonas--;
                salir = true;
            }else{
                salir = true; 
            }                        
            } while (!salir);  
    }
//*********************************************************************************************************
//************************   BASE DE DATOS   ************************************************************** 
//*********************************************************************************************************
   /**
    * Método para establecer conecxión con la base de datos.
    * @return 
    */
    public static Connection getConnection() {
        Connection con = null;

        // Parámetros de acceso
        String servidor = "jdbc:mysql://localhost:3306";
        String baseDatos = "tarea10"; 
        String usuario = "root";
        String password = "root";

        try {            
            Class.forName("com.mysql.jdbc.Driver");
        } catch (java.lang.ClassNotFoundException e) {
            mostrarExcepcion("ClassNotFoundException: " + e.getMessage());
        }
        try {            
            con = DriverManager.getConnection(
                    servidor + "/" + baseDatos, usuario, password);            
        } catch (SQLException ex) {
            mostrarExcepcion("SQLException conexión: " + ex.getMessage());
        }
        return con;
    }
   
    /**
     * Método que inserta la línea SQL en la base de datos.
     * 
     * Sirve para conectar con la base de datos y ejecutar la secuencia SQL que se 
     * encuentra en la variable 'insertPersonaListin'.
     */
    public void introducirEnBD() {
        Statement inserBD;
        Connection con;

        con = getConnection(); //Establecemos conecxion con la base de datos.        

                try {
                    inserBD = con.createStatement();
                    inserBD.executeUpdate(insertPersonaListin);                  
                    
                    inserBD.close();
                    con.close();
                    
                   
                } catch (SQLException ex) {
                    mostrarExcepcion("SQLException: " + ex.getMessage());
                    System.err.println("NO SE HA PODIDO INTRODUCIR EL LISTIN EN LA BASE DE DATOS");
                }        
    }
    
    /**
     * Método para crear las tablas de la base de datos.
     */
    public static void crearTablas() {
        Statement stmt;
        Connection con;

        con = getConnection();
        String creaA;
        String creaPL;
        String creaPF;
        String creaPI;
        creaA = "CREATE TABLE IF NOT EXISTS alumno (Alumno LONGTEXT)";
        creaPL = "CREATE TABLE IF NOT EXISTS personallaboral (PLaboral LONGTEXT)";
        creaPF = "CREATE TABLE IF NOT EXISTS profesorfuncionario (PFuncionario LONGTEXT)";
        creaPI = "CREATE TABLE IF NOT EXISTS profesorinterino (PInterino LONGTEXT)";

        try {
            stmt = con.createStatement();
            stmt.executeUpdate(creaA);
            stmt.executeUpdate(creaPL);
            stmt.executeUpdate(creaPF);
            stmt.executeUpdate(creaPI);
            stmt.close();
            con.close();

            System.out.println("Tablas  de base de datos creadas.");
        } catch (SQLException ex) {
            mostrarExcepcion("SQLException: " + ex.getMessage());
        }
        
    }
    
    /**
     * Método para borrar todas la tablas de la base de datos.
     */
    public static void borrarTablas() {
        Statement stmt;
        Connection con;

        con = getConnection();
        String a = "DROP TABLE IF EXISTS alumno;";
        String pl = "DROP TABLE IF EXISTS personallaboral;";
        String pf = "DROP TABLE IF EXISTS profesorfuncionario;";
        String pi = "DROP TABLE IF EXISTS profesorinterino;";

        try {
            stmt = con.createStatement();
            stmt.executeUpdate(a);
            stmt.executeUpdate(pl);
            stmt.executeUpdate(pf);
            stmt.executeUpdate(pi);
            stmt.close();
            con.close();
            
            System.out.println("Eliminadas todas las tablas.");

        } catch (SQLException ex) {
            mostrarExcepcion("SQLException: " + ex.getMessage());
        }

    }
    
    /**
     * Método para insertar el listin en la base de datos.
     * 
     * Primero empieza recorriendo el array, mientras lo recorre busca las palabras clave para
     * introducir los datos en una tabla o en otra.
     * 
     */
    public void insertarListinBD() {
        borrarTablas();
        crearTablas();
        
        for (int i = 0; i < _numeroDePersonas; i++) {
            if(listin[i] != null){
                
                if(listin[i].contains("ALUMNO")){   
                    insertPersonaListin = "INSERT INTO `tarea10`.`alumno` (`Alumno`) VALUES ('"+listin[i]+"')";
                    introducirEnBD();
                }
                if(listin[i].contains("PROFESORFUNCIONARIO")){                    
                    insertPersonaListin = "INSERT INTO `tarea10`.`profesorfuncionario` (`PFuncionario`) VALUES ('"+listin[i]+"')";
                    introducirEnBD();
                }
                if(listin[i].contains("PROFESORINTERINO")){                    
                    insertPersonaListin = "INSERT INTO `tarea10`.`profesorinterino` (`PInterino`) VALUES ('"+listin[i]+"')";
                    introducirEnBD();
                }
                if(listin[i].contains("PERSONALLABORAL")){                    
                    insertPersonaListin = "INSERT INTO `tarea10`.`personallaboral` (`PLaboral`) VALUES ('"+listin[i]+"')";
                    introducirEnBD();
                }
            }
        }        
        System.out.println("Datos insertados correctamente");        
    }
    
    /**
     * Método que primeto vacia el listin y luego lo carga con los datos de la base de datos.
     */
    public void cargarDatosBD(){
        vaciarListin();
        cargarTablaAlumno();
        cargarTablaPL();
        cargarTablaPF();
        cargarTablaPI();
        
    }
//-------------------------  Métodos para cargar al listin las tablas. -------------------------------------------------------  
    public void cargarTablaAlumno() {
        
        Statement stmt;
        Connection con;

        String result = null;
        try {
            con = getConnection();

            String selectString;
            selectString = "select * from alumno";            

            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(selectString);
            while (rs.next()) {  
                
                String dato = rs.getString("Alumno");
                listin[_numeroDePersonas] += dato;
                _numeroDePersonas++;
            }
            stmt.close();
            con.close();            
            
        } catch (SQLException ex) {
            mostrarExcepcion("SQLException: " + ex.getMessage());
        }
    }
    
    public void cargarTablaPL() {
        
        Statement stmt;
        Connection con;

        String result = null;
        try {
            con = getConnection();

            String selectString;
            selectString = "select * from personallaboral";            

            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(selectString);
            while (rs.next()) {  
                
                String dato = rs.getString("PLaboral");
                listin[_numeroDePersonas] += dato;
                _numeroDePersonas++;
            }
            stmt.close();
            con.close();            
            
        } catch (SQLException ex) {
            mostrarExcepcion("SQLException: " + ex.getMessage());
        }
    }
    
    public void cargarTablaPF() {
        
        Statement stmt;
        Connection con;

        String result = null;
        try {
            con = getConnection();

            String selectString;
            selectString = "select * from profesorfuncionario";            

            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(selectString);
            while (rs.next()) {  
                
                String dato = rs.getString("PFuncionario");
                listin[_numeroDePersonas] += dato;
                _numeroDePersonas++;
            }
            stmt.close();
            con.close();            
            
        } catch (SQLException ex) {
            mostrarExcepcion("SQLException: " + ex.getMessage());
        }
    }
    
    public void cargarTablaPI() {
        
        Statement stmt;
        Connection con;

        String result = null;
        try {
            con = getConnection();

            String selectString;
            selectString = "select * from profesorinterino";            

            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(selectString);
            while (rs.next()) {  
                
                String dato = rs.getString("PInterino");
                listin[_numeroDePersonas] += dato;
                _numeroDePersonas++;
            }
            stmt.close();
            con.close();            
            
        } catch (SQLException ex) {
            mostrarExcepcion("SQLException: " + ex.getMessage());
        }
    }
//----------------------------------------------------------------------------------------------------------------    
   /**
    * Método para vaciar el array listin.
    */
   public void vaciarListin(){
       for (int i = 0; i < 100; i++) {
           listin[i] = null;
       }
   } 
   
   public static void mostrarExcepcion( String ex) {
        JOptionPane.showMessageDialog(null, ex, "ERROR", JOptionPane.ERROR_MESSAGE);
    }
}

