/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea7;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class EntradaSalida {
// Colores
    public static final String NEGRO = "\033[30m";
    public static final String ROJO = "\033[31m";
    public static final String AZUL = "\033[34m";
    public static final String VERDE = "\033[32m";
    public static final String AMARILLO = "\033[33m";
    
// METODOS
    /**
     * Metodo para leer un numero entero.
     * @return 
     */
    public static int leerEntero (){
        
        Scanner miTeclado = new Scanner(System.in);
        int numeroEntero = 0;
        String numeroComoCadena ="";
        boolean correcto = true;
        
        do{
            try {
                numeroComoCadena = miTeclado.nextLine();
                numeroEntero = Integer.parseInt(numeroComoCadena);
                correcto = true;

            } catch (Exception e) {
                correcto = false;
                System.err.println("Número introducido no correcto");
            }
        }while (!correcto);        
        return (numeroEntero);        
    }
    
    /**
     * Método para leer un numero entero entre un rango.
     * @param menor Valor mínimo admitido.
     * @param mayor Valor máximo admitido.
     * @return 
     */
    public static int leerEntero (int menor, int mayor){
        
        Scanner miTeclado = new Scanner(System.in);
        int numeroEntero = 0;
        String numeroComoCadena ="";
        boolean correcto = true;
        
        do{
            try {
                numeroComoCadena = miTeclado.nextLine();
                numeroEntero = Integer.parseInt(numeroComoCadena);
                if ((numeroEntero < menor) || (numeroEntero > mayor)){
                    System.err.println("Número erroneo... ha de estar entre "+
                                        menor+" y "+mayor+
                                        ". Introduzca número de nuevo");
                    correcto = false;
                } else {
                    correcto = true;
                }                

            } catch (Exception e) {
                correcto = false;
                System.err.println("Número introducido no correcto");
            }
        }while (!correcto);        
        return (numeroEntero);        
    }
    
    /**
     * Método para cambiar el color del texto a mostrar.
     * @param color Color que tendra el texto.
     * @param texto 
     */
    public static void pantalla(String color, String texto){
        System.out.println(color + texto);
        System.out.print("\u001B[0m");
    }
    
    /**
     * Método que devuelve en caso de que la respuesta sea "s" verdadero y en caso de que sea "n" falso.
     * @return 
     */
    public static boolean VerdaderoFalso(){
        Scanner miTeclado = new Scanner(System.in);
        boolean VerdaderoFalso = false;
        String LeerLetra = "";
        String opcion1 = "s";
        String opcion2 = "S";
        String opcion3 = "n";
        String opcion4 = "N";
        boolean correcto = true;
        
        do{
            try {
                LeerLetra = miTeclado.nextLine();
                if(LeerLetra == opcion1){
                    correcto = true;
                    VerdaderoFalso = true;
                }
                if(LeerLetra == opcion2){
                    correcto = true;
                    VerdaderoFalso = true;
                }
                if(LeerLetra == opcion3){
                    correcto = true;
                    VerdaderoFalso = false;
                }
                if(LeerLetra == opcion4){
                    correcto = true;
                    VerdaderoFalso = false;
                }
            } catch (Exception e) {
                correcto = false;
                System.err.println("Letra introducida Incorercta. Debes de introducir una S para si o N para no.");
            }
        }while (!correcto);        
        return VerdaderoFalso;
    }
    
    /**
     * Método para la entrada de texto por teclado.
     * @return 
     */
    public static String leerCadena (){
        
        Scanner miTeclado = new Scanner(System.in);        
        String cadena ="";
        boolean correcto = true;
        
        do{
            try {
                cadena = miTeclado.nextLine();
                
                correcto = true;

            } catch (Exception e) {
                correcto = false;
                System.err.println("Palabra introducido no correcto");
            }
        }while (!correcto);        
        return (cadena);        
    } 
}
