/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea7;

/**
 *
 * @author ANGELA PEREZ
 */
class Persona implements InterfacePersona {
// ATRIBUTOS
    protected String _dni;
    protected String _nombre;
    protected String _apellidos;
    protected int _edad;
    
// METODOS
    /**
     * Método para dar de alta.
     * @return 
     */
    @Override
    public String darDeAlta() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    /**
     * Método que devuelve los datos de una perosna.
     * @return 
     */
    @Override
    public String mostrar() {
        return ("Nombre: "+_nombre+"\n Apellidos: "+_apellidos+"\n DNI: "+_dni+"\n Edad: "+_edad);
    }
    
}
