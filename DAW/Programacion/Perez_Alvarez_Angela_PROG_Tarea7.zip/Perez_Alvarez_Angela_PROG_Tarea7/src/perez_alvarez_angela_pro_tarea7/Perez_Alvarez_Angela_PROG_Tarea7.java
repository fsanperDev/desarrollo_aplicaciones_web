/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea7;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
public class Perez_Alvarez_Angela_PROG_Tarea7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // CLASES
    Scanner teclado = new Scanner(System.in);
    Listin listinPersonas = new Listin();
    // ATRIBUTOS
    int opcion;
    boolean salir = false;
    String dato = "";
    final String txt_menu = "*****  LISTÍN DE CENTRO  ****** \n"
            + "1. Cargar el Listín utilizando fichero binario.\n2. Guardar el Listín  utilizando fichero binario.\n"
            + "3. Cargar el Listín utilizando ficheros de texto.\n4. Guardar el Listín utilizando ficheros de texto.\n"
            + "5. Mostrar todo el lintín.\n6. Alta en el listín.\n"
            + "7. Baja en el listín.\n8. Salir de la aplicación.\n";
    //--------------------   EMPIEZA AQUI   -----------------------------------------------------------------------------
        do {
            Auxiliar.pantalla(Auxiliar.NEGRO, txt_menu);
            opcion = Auxiliar.leerEntero(1, 8);
            switch(opcion){
            //----------------------------  CARGAR LISTIN FICHERO BINARIO  ----------------------------------------------
                case 1:
                    listinPersonas.cargarDeBinario();
                    break;
            //----------------------------  GUARDAR LISTIN FICHERO BINARIO  ---------------------------------------------
                case 2:
                    listinPersonas.guardarABinario();
                    break;
            //---------------------------  CARGAR LISTIN FICHERO TEXTO  --------------------------------------------------
                case 3:
                    listinPersonas.cargarDeTexto();
                    break;
            //----------------------------  GUARDAR LISTIN FICHERO TEXTO  -------------------------------------------------
                case 4:
                    listinPersonas.guardarATexto();
                    break;
            //-----------------------------  MOSTRAR EL LISTIN  --------------------------------------------------------------------------------
                case 5:
                    listinPersonas.mostrarListin();
                    break;
            //-----------------------------  DAR DE ALTA  ---------------------------------------------------------------------------------
                case 6: 
                    listinPersonas.altaEnListin();
                    break;
            //--------------------------------  DAR DE BAJA  -------------------------------------------------------------------------
                case 7:                     
                    listinPersonas.bajaEnListin();
                    break;
            //---------------------------------------  SALIR  ----------------------------------------------------------------------
                case 8:
                    salir = true;
                    break;
            }
        } while (!salir);  
    
    }
    
}
