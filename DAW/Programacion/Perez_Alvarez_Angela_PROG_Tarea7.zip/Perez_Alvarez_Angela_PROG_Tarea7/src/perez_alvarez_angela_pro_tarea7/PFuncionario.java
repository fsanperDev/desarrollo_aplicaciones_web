/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea7;

import java.util.Scanner;

/**
 *
 * @author ANGELA PEREZ
 */
final class PFuncionario extends Profesor{
    Scanner teclado = new Scanner(System.in);
// ATRIBUTOS
    protected int _annoOposiciones;
    private String _txt_nombre = "Nombre: ";
    private String _txt_apellidos = "Apellidos: ";
    private String _txt_dni = "DNI:";
    private String _txt_edad = "Edad:";
    private String _txt_opociciones = "Año en que aprobo las oposiciones :";
// METODOS    
    /**
     * Metodo para  dar de alta a un Profesor Funcionario.
     * @return 
     */
    @Override
    public String darDeAlta() {
        
        String Pfuncionario = "";// Variable donde guardaremos luego todos los datos.
        
        // Primero recopilamos los datos.
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_nombre);
        _nombre = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_apellidos);
        _apellidos = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_dni);
        _dni = teclado.nextLine();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_edad);
        _edad = Auxiliar.leerEntero();
        Auxiliar.pantalla(Auxiliar.NEGRO, _txt_opociciones);
        _annoOposiciones = Auxiliar.leerEntero();
        
        // Ahora se preparan para introducirlos en una sola variable.
        Pfuncionario += "PROFESORFUNCIONARIO"+"\n";
        Pfuncionario += Auxiliar.VERDE+"Nombre: "+_nombre+"\n";
        Pfuncionario += Auxiliar.VERDE+"Apellidos: "+_apellidos+"\n";
        Pfuncionario += Auxiliar.VERDE+"DNI: "+_dni+"\n";
        Pfuncionario += Auxiliar.VERDE+"Año oposiciones: "+_annoOposiciones+"\n";
        Pfuncionario += Auxiliar.VERDE+"Edad: "+_edad+"\n";
        
        return Pfuncionario;
    }
    
    /**
     * Metodo que devuelve los datos del profesor funcionario.
     * @return 
     */
    @Override
    public String mostrar(){
        return (Auxiliar.VERDE+super.mostrar()+"\n Año en que aprovo las oposiciones: "+_annoOposiciones);
    }
    /**
     * Metodo que devuelve el salario mensual del profesor funcionario.
     * @return 
     */
    @Override
    public float salarioMensual() {
        float annosTrabajados = Auxiliar.anho_actual - _annoOposiciones;
        return (Profesor._salarioBaseMensual+(10*annosTrabajados));
    }
    
}
