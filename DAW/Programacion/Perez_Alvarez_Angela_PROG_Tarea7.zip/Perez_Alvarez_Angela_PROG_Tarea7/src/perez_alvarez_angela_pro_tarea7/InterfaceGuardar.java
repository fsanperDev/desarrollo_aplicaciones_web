/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea7;

/**
 *
 * @author ANGELA PEREZ
 */
public interface InterfaceGuardar {
    /**
     * Guarda en un fichero binario.
     */
    void guardarABinario();
    
    /**
     * Guarda en un fichero de texto.
     */
    void guardarATexto();
}
