/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perez_alvarez_angela_pro_tarea7;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ANGELA PEREZ
 */
public class Listin implements InterfaceCargar, InterfaceGuardar{
    
    Scanner teclado = new Scanner(System.in);
    private Alumno alumno = new Alumno();
    private PFuncionario funcionario = new PFuncionario();
    private PInterino interino = new PInterino();
    private PersonalLaboral plaboral = new PersonalLaboral();
// ARRAY
    private String[] listin = new String[100];
// ATRIBUTOS
    private int _numeroDePersonas = 0;
    private int _opcion;
    private int _opcion2;
    private boolean salir = false;
    private final String _txt_darDeAlta = "¿A quien quieres dar de alta?\n 1. Alumno.\n 2. Profesor Funcionario.\n 3. Profesor Interino.\n"
            + " 4. Personal Laboral.\n ";
    private final String _txt_darDeBaja = "¿Estas seguro que desea darle de baja?\n 1 - SI\n 2 - NO\n";
// CONSTRUCTOR
    
// METODOS
    /**
     * Método para postrar el listin.
     */
    public void mostrarListin(){   
    // Se comprueba que el listin no esté vacio.
        try{
            if(_numeroDePersonas == 0){
        // Si está vacio salta la excepcion.
            throw new ListinVacio();
            }else{
        // Si no está vacio lo muestra.
                for (int i = 0; i < _numeroDePersonas; i++) {
                    if (listin[i] != null) {
                         EntradaSalida.pantalla(Auxiliar.NEGRO,listin[i]+"\n");                         
                    }else{
                        System.out.println(EntradaSalida.ROJO+listin[i]+"\n");
                    }                               
                }
            }
            }catch(ListinVacio ex){
                System.err.println(ex.getMessage());
            }
    }
    
    /**
     * Metodo para dar de alta en el listin.
     */
    public void altaEnListin(){
 // Preguntamos el tipo de persona que se va a insertar en el listin.
    Auxiliar.pantalla(Auxiliar.NEGRO, _txt_darDeAlta);
    _opcion = Auxiliar.leerEntero(1, 4);
    switch(_opcion){
        case 1:
    /* Llamamos al metodo darDeAlta que nos devolvera un String con todos los datos y lo guardamos en una variable.*/ 
        String personaDelListin = alumno.darDeAlta();
    // Buscara una pocision vacia y guardará los datos.
            for (int i = 0; i <= _numeroDePersonas; i++) {
                if (listin[i] == null) {
                    listin[i] = personaDelListin;
                }
            }
                            //Sumamos 1 al numero de personas que hay en el listin. 
                            _numeroDePersonas++;
                            break;
                        case 2:
                            String PfuncionarioDelListin = funcionario.darDeAlta();
                            for (int i = 0; i <= _numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = PfuncionarioDelListin;
                                }
                            }
                            _numeroDePersonas++;
                            break;
                        case 3:
                            String PinterinoDelListin = interino.darDeAlta();
                            for (int i = 0; i <= _numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = PinterinoDelListin;
                                }
                            }
                            _numeroDePersonas++;
                            break;
                        case 4:
                            String PLaboralDelListin = plaboral.darDeAlta();
                            for (int i = 0; i <= _numeroDePersonas; i++) {
                                if (listin[i] == null) {
                                    listin[i] = PLaboralDelListin;
                                }
                            }
                            _numeroDePersonas++;
                            break;
                    }
    }

    /**
     * Método para dar de baja a una persona del listin.
     */
    public void bajaEnListin(){
    do {
// Mostrar todo el listin.
        for (int i = 0; i < _numeroDePersonas; i++) {
            System.out.println(Auxiliar.NEGRO+(i)+" - "+listin[i]+"\n");
        }
// Selecciona el numero de la persona que desea dar de baja.
        _opcion = Auxiliar.leerEntero(0, 100);
// Preguntar si realmente desea eliminarlo.
        System.out.println(_txt_darDeBaja+listin[_opcion]);
        _opcion2 = Auxiliar.leerEntero(1, 2);
            if(_opcion2 == 1){                
                for (int i = _opcion; i < _numeroDePersonas; i++) {
                    listin[i] = listin[i+1];
                }
                _numeroDePersonas--;
                salir = true;
            }else{
                salir = true; 
            }                        
            } while (!salir);  
    }
    
    /**
     * Método para cargar en el array datos de un fichero binario.
     */
    @Override
    public void cargarDeBinario() {
        String objeto = ""; 
        
        FileInputStream fis = null;
        DataInputStream das = null;
        
        try {
            fis = new FileInputStream("./FicheroBinario.dat");
            das = new DataInputStream(fis);            
            
            while(das.available()!=0){
                objeto = das.readUTF();
                listin[_numeroDePersonas]=objeto;
                 _numeroDePersonas++;              
                
            }
            
            das.close();
            fis.close();
        } catch (FileNotFoundException ex) {
            System.err.println("ERROR, no se ha podido encontrar el fichero.");
        } catch (IOException ex) {
            System.err.println("ERROR, no se puede leer el fichero.");
        }
              
    }
    /**
     * Metodo para cargar un fichero de texto.
     */
    @Override
    public void cargarDeTexto() {
        
        String persona = ""; //Variable donde guardaremos los datos de un objeto.
        String linea;         
        
        // Fichero de Alumno.
        File ficheroA = null; 
        FileReader frA = null;
        BufferedReader brA = null;
        // Fichero de Profesor Funcionario.
        File ficheroPF = null; 
        FileReader frPF = null;
        BufferedReader brPF = null;
        // Fichero de Profesor Interino.
        File ficheroPI = null; 
        FileReader frPI = null;
        BufferedReader brPI = null;
        // Fichero de Personal Laboral.
        File ficheroPL = null; 
        FileReader frPL = null;
        BufferedReader brPL = null;
        
    //************  ALUMNO  ****************************************************   
        try {
            /**
             * Seleccionamos el fichero que deseamos extraer la información.
             */
            ficheroA = new File ("./ficheroTextoAlumno.txt");
            frA = new FileReader (ficheroA);
            brA = new BufferedReader(frA);
            /**
             * Mientras, al leerlo, la línea no sea nula lo recorrera.
             */
            while((linea=brA.readLine())!=null){  
                for (int i = 0; i < 1; i++) {
            /**
             * Guardamos todas las líneas en 'persona' para formar un objeto.
             */
                    persona += linea+"\n";
            /**
             * En cuanto encuentre un espacio(separador) introducira la eln objeto en el array, 
             * sumara uno al numero de personas y reiniciará 'persona'.
             */
                    if("".equals(linea)){
                        listin[_numeroDePersonas]=persona;
                        _numeroDePersonas++;
                        persona = "";
                    }               
                }                
            }
    //********** PROFESOR FUNCIONARIO  *****************************************
        
            ficheroPF = new File ("./ficheroTextoProfesorF.txt");
            frPF = new FileReader (ficheroPF);
            brPF = new BufferedReader(frPF);
            
            while((linea=brA.readLine())!=null){  
                for (int i = 0; i < 1; i++) {
                    System.out.println(linea);
                    persona += linea+"\n";
                    if("".equals(linea)){
                        listin[_numeroDePersonas]=persona;
                        _numeroDePersonas++;
                        persona = "";
                    }               
                }                
            }
    //**********  PROFESOR INTERINO  *******************************************
            ficheroPI = new File ("./ficheroTextoProfesorI.txt");
            frPI = new FileReader (ficheroPI);
            brPI = new BufferedReader(frPI);
            
            while((linea=brA.readLine())!=null){  
                for (int i = 0; i < 1; i++) {
                    System.out.println(linea);
                    persona += linea+"\n";
                    if("".equals(linea)){
                        listin[_numeroDePersonas]=persona;
                        _numeroDePersonas++;
                        persona = "";
                    }               
                }                
            }
    //**********  PERSONAL LABORAL  ********************************************
            ficheroPL = new File ("./ficheroTextoPersonalL.txt");
            frPL = new FileReader (ficheroPL);
            brPL = new BufferedReader(frPL);
            
            while((linea=brA.readLine())!=null){  
                for (int i = 0; i < 1; i++) {
                    System.out.println(linea);
                    persona += linea+"\n";
                    if("".equals(linea)){
                        listin[_numeroDePersonas]=persona;
                        _numeroDePersonas++;
                        persona = "";
                    }               
                }                
            }
    // Cerrar los ficheros.
        brA.close();
        frA.close();
        
        brPF.close();
        frPF.close();
        
        brPI.close();
        frPI.close();
        
        brPL.close();
        frPL.close();
        
        } catch (IOException e2){
            System.err.println("No se ha podido leer el archivo.");
        }
    }
    
    /**
     * Método para guardar un fichero en binario.
     */
    @Override
    public void guardarABinario() {
        FileOutputStream fos = null;
        DataOutputStream dos = null;
        
        try {
            fos = new FileOutputStream("./FicheroBinario.dat"); // Crearmos y nombramos al fichero
            dos = new DataOutputStream(fos);
        
            /**
             * Hacemos un for por cada una de las persona guardadas en el listin y las incluimos en el fichero.
             */
            for (int i = 0; i < _numeroDePersonas; i++) {
                dos.writeUTF(listin[i]);
            }
        // Reiniciamos a 0 el numero de personas
            _numeroDePersonas = 0;
        } catch (FileNotFoundException ex) {
            System.err.println("No se ha podido encontrar el fichero.");
        } catch (IOException ex) {
            System.err.println("ERROR, el fichero no se puede leer.");
        }finally{
                try {
                // Cerramos los ficheros.
                    dos.close();
                    fos.close();
                } catch (Exception e) {
                    System.err.println("ERROR, no se puede cerrar el fichero.");
                }
        }
        
      
    }
    /**
     * Método para guardar el array el un fichero de texto.
     */
    @Override
    public void guardarATexto() {
        
        String salto = "\n"; // Variable para separar.
        
        /**
         * Creamos los ficheros, en este caso uno para cada tipo de persona.
         */
        try {
            FileWriter ficheroAlumno=new FileWriter("./ficheroTextoAlumno.txt");
            FileWriter ficheroProfesorF=new FileWriter("./ficheroTextoProfesorF.txt");
            FileWriter ficheroProfesorI=new FileWriter("./ficheroTextoProfesorI.txt");
            FileWriter ficheroPersonalL=new FileWriter("./ficheroTextoPersonalL.txt");
            
            PrintWriter pwA = new PrintWriter(ficheroAlumno, true);
            PrintWriter pwPF = new PrintWriter(ficheroProfesorF, true);
            PrintWriter pwPI = new PrintWriter(ficheroProfesorI, true);
            PrintWriter pwPL = new PrintWriter(ficheroPersonalL, true);
            
            /**
             * Hacemos un for para volcar los datos del array listin y guardarlos en sus respectivos ficheros,
             * la forma de diferenciarlos es por una serie de caracteres clave que empiezan en cada objeto.
             */
            for (int i = 0; i < _numeroDePersonas; i++) {
            // Si el objeto empieza por 'ALUMNO' lo guardará en su respectivo fichero y así con los demás.
                if(listin[i].contains("ALUMNO")){
                    pwA.print(listin[i]);
                    pwA.print(salto);// Esta línea es para guardar un separador.                    
                }                
                if(listin[i].contains("PROFESORFUNCIONARIO")){
                    pwPF.print(listin[i]);
                    pwPF.print(salto);
                }
                if(listin[i].contains("PROFESORINTERINO")){
                    pwPI.print(listin[i]);
                    pwPI.print(salto);
                }
                if(listin[i].contains("PERSONALLABORAL")){
                    pwPL.print(listin[i]);
                    pwPL.print(salto);
                }
                
            }
            // Lo cerramos todo.
            pwA.close();
            pwPF.close();
            pwPI.close();
            pwPL.close();
            ficheroAlumno.close();
            ficheroProfesorF.close();
            ficheroProfesorI.close();
            ficheroPersonalL.close();
            
        } catch (IOException ex) {
            System.out.println("El fichero no ha podido crearse.");
        }finally{
        // Reiniciamos a 0 tanto en array como el nuemro de personas.          
            String[] listin = new String[100];
            _numeroDePersonas = 0;
        }
    }
}

