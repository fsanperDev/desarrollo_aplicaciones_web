<?php
$Nombre = $_REQUEST["nombre"];
?>
<p>Hola <?php echo $Nombre ?> los juegos que te gustan son Mario World, Sonic, Final Fantasy y Street Figther.</p>

<form name="input" action="formularioAdivina.php" method="post">
    <input type="submit" value="Volver"><br>
</form>
