<?php

$Nombre = $_REQUEST["nombreIntroducido"];

//Si el mes está vacio no se ejecuta.
if (isset($_POST['mes'])) {
include 'funciones.inc.php';

//Mandamos a los ficheros solo la variable con el  nombre.
    if ($edad > 40) {
        header('location:http://localhost/Perez_Alvarez_Angela_DWES_TPres1/masDe40.php?nombre=' . "$Nombre");
    } elseif ($edad <= 40 && $edad >= 30) {
        header('location:http://localhost/Perez_Alvarez_Angela_DWES_TPres1/entre40Y30.php?nombre=' . "$Nombre");
    } elseif ($edad < 30) {
        header('location:http://localhost/Perez_Alvarez_Angela_DWES_TPres1/menosDe30.php?nombre=' . "$Nombre");
    }
}
?>