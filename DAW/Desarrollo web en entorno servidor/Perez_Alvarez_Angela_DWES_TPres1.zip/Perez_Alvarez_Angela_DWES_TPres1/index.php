<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <form name="input" action="formularioAdivina.php" method="post">
            <input type="submit" value="Adivina Juegos">
    </form><br>
    <form name="input" action="estadisticaDeAleatorios.php" method="post">
            <input type="submit" value="Estadística del número aleatorios">
    </form>
    </body>
</html>
