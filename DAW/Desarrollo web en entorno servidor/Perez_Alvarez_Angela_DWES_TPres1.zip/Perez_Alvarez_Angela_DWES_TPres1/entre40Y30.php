<?php
$Nombre = $_REQUEST["nombre"];
?>
<p>Hola <?php echo $Nombre ?> los juegos que te gustan son Word of Warcraft, Grand theft autos, Grand turismo y los sims.</p>

<form name="input" action="formularioAdivina.php" method="post">
    <input type="submit" value="Volver"><br>
</form>
