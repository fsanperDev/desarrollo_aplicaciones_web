<?php
$array_de_numeros = array(); //En este array guardaremos todos los numeros.
/**
 * Mientras que 'nuevoNum' no este vacio genera un numero aleatorio.
 */
if(!empty($_POST['nuevoNum'])){
    $n = rand(0,100); 
    
    echo 'El numero: '.$n;
    //Guardamos el numero en el array.
    array_push( $array_de_numeros , $n );
    foreach($array_de_numeros as $numeros) {
        echo '- '.$numeros.' <br>';
    }
    
}
?>

 <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="submit" name="nuevoNum" value="Generar">
 </form>

