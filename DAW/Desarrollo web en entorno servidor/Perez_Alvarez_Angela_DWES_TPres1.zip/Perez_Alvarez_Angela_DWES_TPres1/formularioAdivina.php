
<form name="input" action="logicaAdivina.php" method="post">
    <h1>Adivina Juegos:</h1>
    Nombre: <input type="text" name="nombreIntroducido" size="50" required><br>
    <input type="number" name="dia" placeholder="dia" required />
    <input type="number" name="mes" placeholder="mes" required />
    <input type="number" name="anno" placeholder="año" required />
    <br>
    <input type="submit" value="Adivina"><br>
</form>
