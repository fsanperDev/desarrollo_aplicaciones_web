<?php
$Nombre = $_REQUEST["nombre"];
?>
<p>Hola <?php echo $Nombre ?> los juegos que te gustan son GTA V, Metal Gear solid, God of War y Horizon Zero Dawn.</p>

<form name="input" action="formularioAdivina.php" method="post">
    <input type="submit" value="Volver"><br>
</form>
