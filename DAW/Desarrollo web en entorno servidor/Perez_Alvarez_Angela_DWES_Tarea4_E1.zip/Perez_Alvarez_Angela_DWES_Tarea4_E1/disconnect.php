<?php
/**
 * Este código sirve para desconectar de la sesion borrando los datos de sesion.
 */
@session_start();
session_unset();

header('Location: index.php');

