<?php
////////////////////////////////////////////////////////////////////////
include_once('Class/Usuario.php');
require_once('Smarty.class.php');
session_start();
$smarty = new Smarty;
$smarty->template_dir = './web/smarty/templates/';
$smarty->compile_dir = './web/smarty/templates_c/';
$smarty->config_dir = './web/smarty/configs/';
$smarty->cache_dir = './web/smarty/cache/';
$smarty->assign('user', $_SESSION['objectUser']);

/*Estas líneas se tiene que agregar el todas las páginas en las que se vuelva a llamar a las plantillas*/
$smarty->assign('user', $_SESSION['objectUser']);
$smarty->assign('Cfondo', $_COOKIE['backgroudColor']);
$smarty->assign('Cletras', $_COOKIE['textColor']);
//////////////////////////////////////////////////////////////////////////

//Si se mando un nombre de usuario, llama al método cargarUsuario.
if (isset($_POST['enviarUser'])) {
    if (!empty($_POST['IDusuario'])){
        $user = $_POST['IDusuario'];
        $mostrarUsuario = cargarUsuario($user);
        //Se manda por una variable smarty.
        $smarty->assign('mostrarUsuario', $mostrarUsuario);
    }
}


$smarty->display('opcionesUsuarios.tpl');

