<?php

class Persona {
    protected $_dni;
    protected $_nombre;
    protected $_apellidos;
    protected $_fechNacimiento;
    
    public function _construct($nombre, $apellidos, $dni, $fechNacimiento) {
        $this->_nombre = $nombre;
        $this->_apellidos = $apellidos;
        $this->_dni = $dni;
        $this->_fechNacimiento = $fechNacimiento;
    }
    
//-------------------  GETTER Y SETTERS   ------------------------------------------------------------------
    public function getdni() {return $this->_dni; }
    public function getNombre() {return $this->_nombre; }
    public function getApellidos() {return $this->_apellidos; }
    public function getFechNacimiento() {return $this->_fechNacimiento; }
    
}

