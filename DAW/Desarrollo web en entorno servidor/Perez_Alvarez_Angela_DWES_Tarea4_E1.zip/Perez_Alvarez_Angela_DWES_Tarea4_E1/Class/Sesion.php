<?php

class Sesion {
    protected $_idSesion; //
    protected $_logeado; // Booleano ¿se encuentra logeado?
    protected $_idUsuario; //ID del usuario
    protected $_tiempoInicioSesion; //Hora de conexion
    
    public function __construct($idSesion, $logeado, $idUsuario, $inicioSesion) {
        $this->_idSesion = $idSesion;
        $this->_idUsuario = $idUsuario;
        $this->_logeado = $logeado;
        $this->_tiempoInicioSesion = $inicioSesion;
    }
    
//-------------------  GETTER Y SETTERS   ------------------------------------------------------------------
    public function getLogeado() {return $this->_logeado;}
    public function getIDusuario() {return $this->_idUsuario;}
    public function getInicioSesion() {return $this->_tiempoInicioSesion;}
    
    public function setLogeado($logeado) {$this->_logeado = $logeado;}
    /**
     * No he puesto el de idSesion por que no lo necesito, aun al menos. Y el único set es para la variable 
     * logeado que si puede cambiar.
     */
    
//------------------   FUNCIONES   ---------------------------------------------------------------------------
    /**
     * Funcion par conectar con la base de datos.
     * @param type $sql
     * @return type
     */
    protected static function ejecutaConsulta($sql) {
        @ $dwes = new mysqli("localhost", "dwes", "dwes", "matriculaciones");
        $error = $dwes->connect_errno;
        $resultado = null;
        
        if (isset($dwes)) $resultado = $dwes->query($sql);
        return $resultado;
    }
    
    /**
     * Funcion para comprobar que existe el usuario y que la contraseña sea correcta, en caso de serlo
     * devuelve true.
     * @param type $nombre -> Variable que contiene el nombre de usuario.
     * @param type $contrasena -> VAriable que contiene la contraseña.
     * @return boolean
     */
    public static function verificaCliente($nombre, $contrasena) {
        $sql = "SELECT usuario FROM usuarios ";
        $sql .= "WHERE usuario='$nombre' ";
        $sql .= "AND pwd='" . md5($contrasena) . "';";
        $resultado = self::ejecutaConsulta ($sql);
        $verificado = false;

        if(isset($resultado)) {
            $fila = $resultado->fetch_assoc();
            if($fila !== false) $verificado=true;
        }
        return $verificado;
    }
    
}

