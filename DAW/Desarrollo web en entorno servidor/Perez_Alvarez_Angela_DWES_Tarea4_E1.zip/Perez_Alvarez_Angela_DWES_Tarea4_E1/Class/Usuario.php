<?php
include 'funciones.inc';
include 'Persona.php';
interface Carga {
    public function cargarUsuario($IDusuario);

}

class Usuario extends Persona implements Carga {

    protected $_idUsuario;
    protected $_fechaDeAlta;
    protected $_departamento;
    protected $_nombreUsuario;
    protected $_emailUsuario;

    public function __construct($idUsuario, $fechaDeAlta, $departamento, $emailUsuario, $nombreUsuario) {
        parent::__construct(0);
        $this->_idUsuario = $idUsuario;
        $this->_fechaDeAlta = $fechaDeAlta;
        $this->_departamento = $departamento;
        $this->_emailUsuario = $emailUsuario;
        $this->_nombreUsuario = $nombreUsuario;
    }

//-------------------  GETTER Y SETTERS   ------------------------------------------------------------------
    public function getIDusuario() {return $this->_idUsuario; }
    public function getfechaDeAlta() {return $this->_fechaDeAlta; }
    public function getNombreUsuario() {return $this->_nombreUsuario; }
    public function getEmail() {return $this->_emailUsuario; }
    public function getDepartamento() {return $this->_departamento; }

//------------------   FUNCIONES    -------------------------------------------------------------------------    
    
    /**
     * Metodo al que se le pasa una ID de usuario y te muestra su informacion.
     * @param type $IDusuario
     */
    public function cargarUsuario($IDusuario) {
        //Preparo la sentencia.
        $sql = "SELECT id, usuario, email, fecha_alta, Departamento, dni, nombre, apellidos, fecha_nacimiento";
        $sql .= " FROM usuario WHERE usuario='" . $IDusuario . "'";
        //Establezco la conexion con la base de datos.
        $conexion = conexionALaBaseDeDAtos();
        //Hace la consulta. Como solo se puede introducir un ID solo hace una consulta.
         if ($datoAMostrar = mysqli_query($conexion, $sql)) {
             $row = $datoAMostrar->fetch_assoc();
             echo "Usuario: ${row['usuario']} / Nombre: ${row['nombre']} / Apellidos: ${row['apellidos']} / DNI: ${row['dni']} / "
             . "Email: ${row['email']} / Departamento: ${row['Departamento']} / Fecha de Nacimiento: ${row['fecha_nacimiento']} / "
             . "Fecha de Alta: ${row['fecha_alta']}";
             
         }
         mysqli_close($conexion);
    }

}
