<?php
include 'Class/Sesion.php';
//////////////////////////////////////////////////////////
require_once('Smarty.class.php');
$smarty = new Smarty;
$smarty->template_dir = './web/smarty/templates/';
$smarty->compile_dir = './web/smarty/templates_c/';
$smarty->config_dir = './web/smarty/configs/';
$smarty->cache_dir = './web/smarty/cache/';
//////////////////////////////////////////////////////////
/*Se inicia la sesion*/
session_start();
//Comprueba si existe la variable de sesion 'objectUser'
if (isset($_SESSION['objectUser'])){
    //Si existe el la variable de sesion objeto.
    $name = $_SESSION['objectUser'];
    //La convertimos en variable local para obtener el nombre y la hora de inicio de sesion.
    $nombreUsuario = $name->getIDusuario();

    //Convertimos la varieble de sesion objeto en variable smarty.
    $smarty->assign('texto_bienvenida', $nombreUsuario);
    $smarty->assign('user', $_SESSION['objectUser']);
    $smarty->assign('nombreUsuario', $nombreUsuario);
    //Ahora las cookies.
    $smarty->assign('Cfondo', $_COOKIE['backgroudColor']);
    $smarty->assign('Cletras', $_COOKIE['textColor']);
    
} else {
    //En caso de que no se haya iniciado sesion se muestra un mensaje estandar.
    $smarty->assign('texto_bienvenida', ' a la aplicación Matricúlate. Has de identificarte para poder entrar.');
}
//Carga la plantilla
$smarty->display('bienvenida.tpl');
