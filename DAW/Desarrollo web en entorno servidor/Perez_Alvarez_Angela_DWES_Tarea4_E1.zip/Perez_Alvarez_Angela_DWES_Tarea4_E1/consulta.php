<?php
session_start();
include 'funciones.inc';

//////////////////////////////////////////
require_once('Smarty.class.php');
$smarty = new Smarty;
$smarty->template_dir = './web/smarty/templates/';
$smarty->compile_dir = './web/smarty/templates_c/';
$smarty->config_dir = './web/smarty/configs/';
$smarty->cache_dir = './web/smarty/cache/';

/*Estas líneas se tiene que agregar el todas las páginas en las que se vuelva a llamar a las plantillas*/
$smarty->assign('user', $_SESSION['objectUser']);
$smarty->assign('Cfondo', $_COOKIE['backgroudColor']);
$smarty->assign('Cletras', $_COOKIE['textColor']);

/////////////////////////////////////////
$smarty->display('consulta.tpl');

if (isset($_POST['submit'])) {
    $TablaSeleccionada = $_POST['tablaSeleccionada'];
    
    $smarty->assign('consultarDatos', mostrarDatos($TablaSeleccionada));
}

    