<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-04 14:13:31
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\nav.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5fa97b701c79_50813553',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fd338d16b7a69819583e82d990a0eac326363ade' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\nav.tpl',
      1 => 1583327604,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:userContainer.tpl' => 1,
  ),
),false)) {
function content_5e5fa97b701c79_50813553 (Smarty_Internal_Template $_smarty_tpl) {
?><nav>
    <h1>Universidad de Sevilla</h1>
    <div id="menuNavegacion">
        <form>
            <input type="button" onclick="window.location.href='index.php'" name="inicio" value="Inicio"> 
            <?php if (isset($_smarty_tpl->tpl_vars['user']->value)) {?> 
                <input type="button" onclick="window.location.href='consulta.php'" name="consulta" value="Consulta">
                <input type="button" onclick="window.location.href='insercion.php'" name="insertar" value="Insercion">
                <input type="button" onclick="window.location.href='modificacion.php'" name="modificar" value="Modificacion">
                <input type="button" onclick="window.location.href='eliminacion.php'" name="eliminar" value="Eliminacion">
                <input type="button" onclick="window.location.href='preferenciasDeUsuarios.php'" name="preferencias" value="Preferencias">
                <?php if ($_smarty_tpl->tpl_vars['user']->value->getIDusuario() == "admin") {?>
                    <input type="button" onclick="window.location.href='altaDeUsuario.php'" name="darDeAlta" value="Alta de usuarios">
                    <input type="button" onclick="window.location.href='opcionesUsuarios.php'" name="darDeAlta" value="Opciones de Usuarios">
                <?php }?>
            <?php }?>
        </form> 
    </div>
    <?php if (isset($_smarty_tpl->tpl_vars['user']->value)) {?> 
        <?php $_smarty_tpl->_subTemplateRender("file:userContainer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <?php }?>
</nav>
<?php }
}
