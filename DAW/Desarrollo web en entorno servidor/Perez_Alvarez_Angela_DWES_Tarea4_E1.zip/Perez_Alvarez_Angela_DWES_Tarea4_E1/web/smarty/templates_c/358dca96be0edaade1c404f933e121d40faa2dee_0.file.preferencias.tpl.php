<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-04 14:14:47
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\preferencias.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5fa9c74f0ab9_45600200',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '358dca96be0edaade1c404f933e121d40faa2dee' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\preferencias.tpl',
      1 => 1583327660,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:nav.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e5fa9c74f0ab9_45600200 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:nav.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div id='setting'>
    <form action='preferenciasDeUsuario.php' method='post'> 
        <fieldset>
            <legend>Color de Fondo: </legend>
            <div class='Bcolores'>
                <input type='submit' name='colorDeFondo' class="Azul" value="Azul"/>
                <input type='submit' name='colorDeFondo' class="Amarillo" value="Amarillo"/>
                <input type='submit' name='colorDeFondo' class="Verde" value="Verde"/>
                <input type='submit' name='colorDeFondo' class="Morado" value="Morado"/>
                <input type='submit' name='colorDeFondo' class="Negro" value="Negro"/>
                <input type='submit' name='colorDeFondo' class="Blanco" value="Blanco"/>
                <input type='submit' name='colorDeFondo' class="Rojo" value="Rojo"/>
                <input type='submit' name='colorDeFondo' class="Marron" value="Marron"/>
                <input type='submit' name='colorDeFondo' class="Rosa" value="Rosa"/>
                <input type='submit' name='colorDeFondo' class="Naranja" value="Naranja"/>
            </div>
        </fieldset>
    </form>

    <form action='preferenciasDeUsuario.php' method='post'> 
        <fieldset>
            <legend>Color del Texto: </legend>
            <div class='TextColores'>
                <input type='submit' name='textColor' class="Azul" value="Azul"/>
                <input type='submit' name='textColor' class="Amarillo" value="Amarillo"/>
                <input type='submit' name='textColor' class="Verde" value="Verde"/>
                <input type='submit' name='textColor' class="Morado" value="Morado"/>
                <input type='submit' name='textColor' class="Negro" value="Negro"/>
                <input type='submit' name='textColor' class="Blanco" value="Blanco"/>
                <input type='submit' name='textColor' class="Rojo" value="Rojo"/>
                <input type='submit' name='textColor' class="Marron" value="Marron"/>
                <input type='submit' name='textColor' class="Rosa" value="Rosa"/>
                <input type='submit' name='textColor' class="Naranja" value="Naranja"/>
            </div>
        </fieldset>
    </form>

    <fieldset>
        <div class='TextVisitas'>
            <p>Numero de veces que has visitado este sitio:<?php if (isset($_smarty_tpl->tpl_vars['NumVisitas']->value)) {
echo $_smarty_tpl->tpl_vars['NumVisitas']->value;
} else { ?>0<?php }?></p>
        </div>
        <form action='preferenciasDeUsuario.php' method='post'> 
            <input type='submit' name='vaciarVisitas' value="Restlablecer contador de visitas a cero."/>
        </form>
    </fieldset>

    <fieldset>
        <div class='BotonRestablecer'>
            <form action='preferenciasDeUsuario.php' method='post'> 
                <input type='submit' name='restablecerTodo' value="Restlablecer todo"/>
            </form>
        </div>
    </fieldset>

</div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
