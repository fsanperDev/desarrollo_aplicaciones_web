<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 14:44:23
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5d0db79a7f17_43036380',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8cc647c78df273f6a6f25a05e89151e6f1855489' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\login.tpl',
      1 => 1583156594,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:nav.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e5d0db79a7f17_43036380 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:nav.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div id='ContenedorBlanco'>
    <form action='login.php' method='post'>
        <div><span class='error'><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</span></div>
        <fieldset>
            <div class='campo'>
                <label for='usuario' >Usuario:</label><br/>
                <input type='text' name='usuario' id='usuario' maxlength="50" /><br/>
            </div>
            <div class='campo'>
                <label for='password' >Contraseña:</label><br/>
                <input type='password' name='password' id='password' maxlength="50" /><br/>
            </div>

            <div class='campo'>
                <input type='submit' name='enviar' value='Enviar' />
            </div>
        </fieldset>
    </form>
</div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
