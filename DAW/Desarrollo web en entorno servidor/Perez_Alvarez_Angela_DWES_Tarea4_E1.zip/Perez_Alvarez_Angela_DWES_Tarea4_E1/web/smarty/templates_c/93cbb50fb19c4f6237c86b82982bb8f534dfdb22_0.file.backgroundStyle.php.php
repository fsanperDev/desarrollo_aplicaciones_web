<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-27 19:19:35
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\backgroundStyle.php' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e58083751a8c3_43212210',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '93cbb50fb19c4f6237c86b82982bb8f534dfdb22' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\backgroundStyle.php',
      1 => 1582827540,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e58083751a8c3_43212210 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?php 
';?>
if (isset($_COOKIE['backgroudColor'])){ 
    <?php echo '?>';?>

class="<?php echo '<?php ';?>
echo $_COOKIE['backgroudColor'] <?php echo '?>';?>
 
        <?php echo '<?php ';?>
echo $_COOKIE['textColor'] <?php echo '?>';?>
"
<?php echo '<?php ';?>
}else { <?php echo '?>';?>
 class="Red" <?php echo '<?php ';?>
} <?php echo '?>';?>


<?php }
}
