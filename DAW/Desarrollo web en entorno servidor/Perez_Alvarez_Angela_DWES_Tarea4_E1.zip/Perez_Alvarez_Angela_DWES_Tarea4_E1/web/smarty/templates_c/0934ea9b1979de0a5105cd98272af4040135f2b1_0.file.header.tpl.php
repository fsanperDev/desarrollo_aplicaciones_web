<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-04 14:03:30
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5fa722bce727_23753115',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0934ea9b1979de0a5105cd98272af4040135f2b1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\header.tpl',
      1 => 1583327005,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e5fa722bce727_23753115 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="estilo.css" />
        <title></title>        
    </head>
    <body class="<?php if (isset($_smarty_tpl->tpl_vars['user']->value)) {
echo $_smarty_tpl->tpl_vars['Cfondo']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['Cletras']->value;?>
 <?php } else { ?> Red TNegro <?php }?>"> 
<?php }
}
