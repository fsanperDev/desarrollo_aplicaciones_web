<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-27 19:39:08
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e580ccce351d9_15418284',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8834502846fb723b9b831482b18613abe37bcfed' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\footer.tpl',
      1 => 1582818894,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e580ccce351d9_15418284 (Smarty_Internal_Template $_smarty_tpl) {
?></body>
</html><?php }
}
