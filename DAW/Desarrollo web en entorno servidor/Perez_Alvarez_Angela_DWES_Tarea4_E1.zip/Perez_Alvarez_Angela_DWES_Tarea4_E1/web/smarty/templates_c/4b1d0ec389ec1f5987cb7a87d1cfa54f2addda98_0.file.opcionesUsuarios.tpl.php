<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-04 02:40:01
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\opcionesUsuarios.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5f06f1c3a419_77635384',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4b1d0ec389ec1f5987cb7a87d1cfa54f2addda98' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\opcionesUsuarios.tpl',
      1 => 1583285857,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:nav.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e5f06f1c3a419_77635384 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:nav.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div id='ContenedorBlanco'>
    <form action='opcionesUsuarios.php' method='post'>
        <div class='campo'>
                <label for='usuario' >Nick (o alias) del usuario:</label><br/>
                <input type='text' name='IDusuario' id='IDusuario' maxlength="50" /><br/>
        </div>
        <div class='campo'>
                <input type='submit' name='enviarUser' value='Enviar' />
        </div>
    </form>
    <!--
    if isset($mostrarUsuario)}
        <p>$mostrarUsuario}</p>
    /if}
    -->
</div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
