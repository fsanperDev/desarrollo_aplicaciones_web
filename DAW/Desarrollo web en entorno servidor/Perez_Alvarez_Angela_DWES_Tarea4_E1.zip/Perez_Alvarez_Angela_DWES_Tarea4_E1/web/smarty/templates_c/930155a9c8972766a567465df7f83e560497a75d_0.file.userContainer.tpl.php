<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-04 01:48:30
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\userContainer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5efadeece0d8_80417406',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '930155a9c8972766a567465df7f83e560497a75d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\userContainer.tpl',
      1 => 1583282904,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e5efadeece0d8_80417406 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <div id="menuUsuario">
        <p>Hola <?php echo $_smarty_tpl->tpl_vars['nombreUsuario']->value;?>
, logeado desde: <!-- Aqui va la variable de inicio de sesion --></p>
        <form action='disconnect.php' method='post'>
            <input type='submit' value="Desconexión">
        </form>
    </div><?php }
}
