<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-03 23:18:11
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\consulta.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5ed7a3cb88c2_82604763',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ff76020793cb57dc10d02bda502eec3cd7f9c60a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\consulta.tpl',
      1 => 1583273875,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:nav.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e5ed7a3cb88c2_82604763 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?> 
<?php $_smarty_tpl->_subTemplateRender("file:nav.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<section>
    <form action="consulta.php" method="post">
        <h3>Seleccione la tabla que deseas consultar</h3>
        <select name="tablaSeleccionada">
            <option value="alumno" selected>Alumno</option>
            <option value="asignatura">Asignatura</option>
            <option value="ciclo">Ciclo</option>
            <option value="matricula">Matricula</option>
            <option value="profesor">Profesor</option>
        </select>        
        <input type="submit" name="submit" value="Mostrar Datos" />
    </form>
</section>

<article>
    <table name="consultas">
        <?php if (isset($_smarty_tpl->tpl_vars['consultarDatos']->value)) {?>
            <?php echo $_smarty_tpl->tpl_vars['consultarDatos']->value;?>

        <?php }?>
    </table>
</article>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
