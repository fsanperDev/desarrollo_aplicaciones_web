<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-04 02:48:27
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\insercion.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5f08eb5157b9_76880735',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '576f88600d60990ccd0c248fab5337372a0bfa07' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\insercion.tpl',
      1 => 1583286494,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:nav.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e5f08eb5157b9_76880735 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:nav.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<section>
    <form action="insercion.php" method="post">
        <h3>¿Que deseas introducir en la base de datos?</h3>    
        <select name="tablaSeleccionada">
            <option value="alumno">Alumno</option>
            <option value="asignatura">Asignatura</option>
            <option value="ciclo">Ciclo</option>
            <option value="matricula">Matricula</option>
            <option value="profesor">Profesor</option>
        </select>
        <input type="submit" name="botonTabla" value="Enviar" />
    </form>
</section>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
