<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-01 14:15:16
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\bienvenida.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5bb564550cc2_33173448',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1b1e37d3c7396e271b28cd4a1ff08fc28cfef46b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\bienvenida.tpl',
      1 => 1583068422,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:nav.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e5bb564550cc2_33173448 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:nav.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div id="ContenedorBlanco">
    <form action='login.php' method='post'>
    <p>Bienvenido <?php echo $_smarty_tpl->tpl_vars['texto_bienvenida']->value;?>
</p>    
        <input type='submit' name='enviar' value='Iniciar sesión' />
    </form>
</div>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
