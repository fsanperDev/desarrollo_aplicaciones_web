<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-27 16:51:15
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_DWES_Tarea4_E1\web\smarty\templates\prueba.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e57e573753260_39282062',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd5a3a3c1440eae9337d647de1941607fd3005394' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_DWES_Tarea4_E1\\web\\smarty\\templates\\prueba.tpl',
      1 => 1582818586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e57e573753260_39282062 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>Hello world</h1><?php }
}
