<?php

include 'funciones.inc';
require_once('Class/Sesion.php');

/////////////////////////////////////////////////////////////////////
require_once('Smarty.class.php');
$smarty = new Smarty;
$smarty->template_dir = './web/smarty/templates/';
$smarty->compile_dir = './web/smarty/templates_c/';
$smarty->config_dir = './web/smarty/configs/';
$smarty->cache_dir = './web/smarty/cache/';

////////////////////////////////////////////////////////////////////

if (isset($_POST['enviar'])) {
    if (empty($_POST['usuario']) || empty($_POST['password'])){
        //El campo de usuario o contraseña esta vacio, salta el mensaje de error.
        $smarty->assign('error', 'Debes introducir un nombre de usuario y una contraseña');
    }else {
        //Los campos han sido verificados, comprueba que existe el usuario y la contraseña sea correcta.
        if (Sesion::verificaCliente($_POST['usuario'], $_POST['password'])) {
            //El usuario existe, se crea la sesion.
        /*****  SESSION *********/
            session_start(); 
            //Genero un numero aleatorio con una funcion que será el id de sesion.
            $idSesion = numeroAleatorio(1, 1000);
            //Variable booleana para saber si el usuario está logeado o no.
            $logeado = true;
            //Nombre de usuario o alias como identificador, .
            $idUsuario = $_POST['usuario'];
            $time = time();
            $inicioSesion = date("d-m-Y (H:i:s)", $time);
            //Se crea el objeto.
            $sesionDeUsuario = new Sesion($idSesion, $logeado, $idUsuario, $inicioSesion);

            //Se crea la variable de sesion del objeto.
            $_SESSION['objectUser'] = $sesionDeUsuario;
            
        /******   COOKIES  *******/
                if (!isset($_COOKIE['backgroudColor'])) {
                    setcookie("backgroudColor", "Red", time() + 3600);
                }
                if (!isset($_COOKIE['textColor'])) {
                    setcookie("textColor", "TNegro", time() + 3600);
                }
                if (!isset($_COOKIE['numeroVisitas'])) {
                    setcookie("numeroVisitas", 0);
                }
        //Volvemos a la pagina principal.
            header("Location: index.php");
        } else {
            //La contraseña o nombre de usuario es incorrecta.
            $smarty->assign('error', 'Usuario o contraseña no válidos!');
        }
    }
} else {
    $smarty->assign('error', '');
}
$smarty->display('login.tpl');

?>


