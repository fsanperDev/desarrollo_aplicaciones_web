<?php
session_start();
include 'funciones.inc';

//////////////////////////////////////////
require_once('Smarty.class.php');
$smarty = new Smarty;
$smarty->template_dir = './web/smarty/templates/';
$smarty->compile_dir = './web/smarty/templates_c/';
$smarty->config_dir = './web/smarty/configs/';
$smarty->cache_dir = './web/smarty/cache/';

$smarty->assign('user', $_SESSION['objectUser']);

/////////////////////////////////////////

if (isset($_POST['confirmarEliminacion']) && ($_POST['confirmarEliminacion'] == 'Yes')) {
    $tabla = $_POST['tabla'];
    $clave = $_POST['clave'];
    switch ($tabla) {
        case 'alumno':
            $SentenciaSql = "DELETE FROM `matricula` WHERE `matricula`.`dniAlumno` = $clave";
            eliminarDatos($SentenciaSql);
            $SentenciaSql = "DELETE FROM `alumno` WHERE `alumno`.`dni` = $clave";
            eliminarDatos($SentenciaSql);
            break;
        case 'asignatura':
            $SentenciaSql = "DELETE FROM `matricula` WHERE `matricula`.`idAsignatura` = $clave";
            eliminarDatos($SentenciaSql);
            $SentenciaSql = "DELETE FROM `asignatura` WHERE `asignatura`.`idAsignatura` = $clave";
            eliminarDatos($SentenciaSql);
            break;
        default:
            break;
    }
}
$smarty->display('consulta.tpl');
?>
<article>
<?php
if (isset($_REQUEST['submit'])) {
    if (isset($_POST['radio'])) {
        $tablaSeleccionada = $_POST['radio'];
        eliminarMostrarOpciones($tablaSeleccionada);
    }
}
?>
</article>


