<?php
include 'funciones.inc';

//Reiniciar juego
if (isset($_POST['submit']) == 1) {

    $numJugador = "N/A";
    $numMaquina = "N/A";

    setcookie("rondas", $contadorRondas = 0, time() + 3600);
    setcookie("ganadas", $marcadorGanadas = 0, time() + 3600);
    setcookie("perdidas", $marcadorPerdidas = 0, time() + 3600);
    setcookie("condicionParaGanar", $condicionParaGanar = "", time() + 3600);
    setcookie("VencedorRonda", $vencedorDeRonda = "", time() + 3600);
}

//Juego
if (isset($_COOKIE['rondas'])) {
    $contadorRondas = $_COOKIE['rondas'];
    $marcadorGanadas = $_COOKIE['ganadas'];
    $marcadorPerdidas = $_COOKIE['perdidas'];
    $condicionParaGanar = $_POST['CondicionParaGanar'];
    $vencedorDeRonda = $_COOKIE['VencedorRonda'];
    
    $numJugador = $_POST['numJugador'];
    $numMaquina = numeroMaquina();
    
    $combunacionGanadora = resolverJuego($numJugador, $numMaquina);
    
    if($combunacionGanadora == $condicionParaGanar){
        $marcadorGanadas++;
    }else{
        $marcadorPerdidas++;
    }
    
    $contadorRondas++;
    setcookie("rondas", $contadorRondas, time() + 3600);
    setcookie("ganadas", $marcadorGanadas, time() + 3600);
    setcookie("perdidas", $marcadorPerdidas, time() + 3600);
}else{
    $numJugador = "N/A";
    $numMaquina = "N/A";
    
    setcookie("rondas", $contadorRondas = 0, time() + 3600);
    setcookie("ganadas", $marcadorGanadas = 0, time() + 3600);
    setcookie("perdidas", $marcadorPerdidas = 0, time() + 3600);
    setcookie("condicionParaGanar", $condicionParaGanar = "", time() + 3600);
    setcookie("VencedorRonda", $vencedorDeRonda = "", time() + 3600);
}

?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Juego Pares o Nones</h1>
        <h3>Selecciona la condicion para ganar:</h3>
        <form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post'>
            <h3>Elige tu opcion para ganar:</h3>
            <input type="checkbox" name="CondicionParaGanar" value="PARES" checked>PARES
            <input type="checkbox" name="CondicionParaGanar" value="NONES">NONES<br>
            <input type="submit" name="numJugador" value="0">
            <input type="submit" name="numJugador" value="1">
            <input type="submit" name="numJugador" value="2">
            <input type="submit" name="numJugador" value="3">
            <input type="submit" name="numJugador" value="4">
            <input type="submit" name="numJugador" value="5">       
           
        </form>
        
        <?php

            ?>
        <div class="marcador">
            <h2>Marcador</h2>
            <p>Condicion para ganar: <?php if(isset($_COOKIE['condicionParaGanar'])){ echo $_COOKIE['condicionParaGanar']; } ?></p>
            <p>Tu numero: <?php echo $numJugador; ?></p>
            <p>Numero de la máquina: <?php echo $numMaquina; ?></p>
            <p>El vencedor de esta ronda es: <?php if(isset($_COOKIE['VencedorRonda'])){ echo $_COOKIE['VencedorRonda'];} ?></p>
            <p>Ganadas: <?php echo $_COOKIE['ganadas']; ?></p>
            <p>Perdidas: <?php echo $_COOKIE['perdidas']; ?></p>
            <p>Ronda de juego: <?php echo $_COOKIE['rondas']; ?></p>
        </div>
        <?php
             
        ?>
        
    <form method="GET" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="submit" value="Reiniciar Juego">
    </form>
    </body>
</html>

