<?php
//Iniciar la sesion para el juego.
session_start();
if(!isset($_SESSION['partidaIniciada'])){
    $_SESSION['partidaIniciada'] = false;
}
if(!isset($_SESSION['ganadas'])){
    $_SESSION['ganadas'] = 0;
}
if(!isset($_SESSION['perdidas'])){
    $_SESSION['perdidas'] = 0;
}
if(!isset($_SESSION['condicionGanadora'])){
    $_SESSION['condicionGanadora'] = "";
}
if(!isset($_SESSION['NumJugador'])){
    $_SESSION['NumJugador'] = 0;
}
if(!isset($_SESSION['NumMaquina'])){
    $_SESSION['NumMaquina'] = 0;
}
if(!isset($_SESSION['VencedorRonda'])){
    $_SESSION['VencedorRonda'] ="";
}

if(isset($_POST['CondicionParaGanar'])){
    $condicionParaGanar = $_POST['CondicionParaGanar'];
    $_SESSION['condicionGanadora'] = $condicionParaGanar;
    header("Location: numeroMano.php");
}

?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Juego Pares o Nones</h1>
        <h3>Selecciona la condicion para ganar:</h3>
        <form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post'>
        <!--<form action='numeroMano.php' method='post'>-->
            <h3>Elige tu opcion para ganar:</h3>
            <input type="submit" name="CondicionParaGanar" value="PARES">
            <input type="submit" name="CondicionParaGanar" value="NONES">
        </form>
        
        <?php
        if($_SESSION['partidaIniciada'] == true){
            ?>
        <div class="marcador">
            <h2>Marcador</h2>
            <p>Condicion para ganar: <?php echo $_SESSION['CondicionParaGanar']; ?></p>
            <p>Tu numero: <?php echo $_SESSION['NumJugador']; ?></p>
            <p>Numero de la máquina: <?php echo $_SESSION['NumMaquina']; ?></p>
            <p>El vencedor de esta ronda es: <?php echo $_SESSION['VencedorRonda']; ?></p>
            <p>Ganadas: <?php echo $_SESSION['ganadas']; ?></p>
            <p>Perdidas: <?php echo $_SESSION['perdidas']; ?></p>
        </div>
        <?php
        }        
        ?>
    </body>
</html>

