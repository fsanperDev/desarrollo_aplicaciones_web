<!DOCTYPE html>
<?php

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Juego Pares o Nones</h1>
        <h3>Selecciona el método de juego:</h3>
        <a href="cookies.php">Juego con cookies</a>
        <a href="sesiones.php">Juego con sessiones</a>        
    </body>
</html>
