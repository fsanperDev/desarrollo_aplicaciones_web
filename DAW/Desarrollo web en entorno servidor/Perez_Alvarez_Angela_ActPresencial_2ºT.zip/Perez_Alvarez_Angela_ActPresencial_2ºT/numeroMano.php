<?php
include 'funciones.inc';

    $_SESSION['partidaIniciada'] = true;
    $condicionParaGanar = $_SESSION['condicionGanadora'] ;

//Inicio del juego.
if (isset($_POST["submit"])) {
    $numeroJugador = $_POST['numeroJugador'];
    $_SESSION['NumJugador'] = $numeroJugador;
    
    $numMaquina = numeroMaquina();    
    $_SESSION['NumMaquina'] = $numMaquina;
    
    //Resolver el juego.
    $condicionGanadora = resolverJuego($numeroJugador, $numMaquina);    
    $_SESSION['condicionGanadora'] = $condicionGanadora;
    
    if($condicionGanadora == $condicionParaGanar){
        //Se suma 1 a la variable de ganadas;
        $_SESSION['ganadas'] = $ganadas;
        $ganadas++;
        $_SESSION['ganadas'] = $ganadas;
        
        $_SESSION['VencedorRonda'] = "Jugador";
        header("Location: sesiones.php");
    }else{
        //Se suma 1 a la variable de perdidas;
        $_SESSION['perdidas'] = $perdidas;
        $perdidas++;
        $_SESSION['perdidas'] = $perdidas;
        $_SESSION['VencedorRonda'] = "Maquina";
        header("Location: sesiones.php");
    }
}
?>

<form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post'>
    <input type="submit" name="numeroJugador" value="0">
    <input type="submit" name="numeroJugador" value="1">
    <input type="submit" name="numeroJugador" value="2">
    <input type="submit" name="numeroJugador" value="3">
    <input type="submit" name="numeroJugador" value="4">
    <input type="submit" name="numeroJugador" value="5">
</form>

