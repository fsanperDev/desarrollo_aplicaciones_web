<?php
include 'components/header.php';
include 'components/nav.php';
if (isset($_SESSION['user'])){
    $texto_bienvenida = $_SESSION['user'];
} else {
    $texto_bienvenida = "a la aplicación Matricúlate. Has de identificarte para poder entrar.";
}
include 'components/footer.php';

?>
<div id="ContenedorBlanco">
    <form action='login.php' method='post'>
    <p>Bienvenido <?php echo $texto_bienvenida ?></p>    
        <?php if(!isset($_SESSION['user'])){ ?><input type='submit' name='enviar' value='Iniciar sesión' /> <?php } ?>
    </form>
</div>
