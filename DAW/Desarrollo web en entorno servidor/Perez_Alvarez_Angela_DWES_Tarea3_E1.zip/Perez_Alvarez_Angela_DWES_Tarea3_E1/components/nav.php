<nav>
    <h1>Universidad de Sevilla</h1>
    <div id="menuNavegacion">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <input type="submit"  name="inicio" value="Inicio">
            <?php
            if (isset($_SESSION['user'])) {
                ?>    
                <input type="submit"  name="consulta" value="Consulta">
                <input type="submit"  name="insertar" value="Insercion">
                <input type="submit"  name="modificar" value="Modificacion">
                <input type="submit"  name="eliminar" value="Eliminacion">
                <input type="submit"  name="preferencias" value="Preferencias">
                <?php
            }
            if (isset($_SESSION['administrador']) and ($_SESSION['administrador'] == 1)){
                ?>
                <input type="submit"  name="darDeAlta" value="Alta de usuarios">
                <?php
            }
            ?>
        </form> 
    </div>
    <?php if (isset($_SESSION['user'])) {?>
    <div id="menuUsuario">
        <p>Hola <?php echo $_SESSION['user']; ?>, logeado desde: <?php echo $_SESSION['horaDeConexion'] ?></p>
        <form action='disconnect.php' method='post'>
            <input type='submit' value="Desconexión">
        </form>
    </div>
    <?php } ?>
</nav>
<?php
//---------  Boton INICIO seleccionado  ---------------------------------------------------
if (isset($_REQUEST['inicio'])) {
    header('Location: index.php');
}
//---------  Boton CONSULTA seleccionado  ---------------------------------------------------
if (isset($_REQUEST['consulta'])) {
    header('Location: consulta.php');
}
//---------  Boton INSERTAR seleccionado  ---------------------------------------------------
if (isset($_REQUEST['insertar'])) {
    header('Location: insercion.php');
}
//---------  Boton INSERTAR seleccionado  ---------------------------------------------------
if (isset($_REQUEST['modificar'])) {
    header('Location: modificacion.php');
}
//---------  Boton ELIMINAR seleccionado  ---------------------------------------------------
if (isset($_REQUEST['eliminar'])) {
    header('Location: eliminacion.php');
}
//---------  Boton PREFERENCIAS seleccionado  ---------------------------------------------------
if (isset($_REQUEST['preferencias'])) {
    header('Location: preferenciasDeUsuarios.php');
}
//---------  Boton ALTA DE USUARIOS seleccionado  ---------------------------------------------------
if (isset($_REQUEST['darDeAlta'])) {
    header('Location: altaDeUsuario.php');
}
?>
