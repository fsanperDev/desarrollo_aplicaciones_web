<?php
include 'funciones.inc';
include 'components/header.php';
include 'components/nav.php';
include 'components/footer.php';

/**
 * En esta página el usuario podrá personalizar el sitio.
 */

// COLOR DE FONDO
if (isset($_REQUEST['colorDeFondo'])) {
    $nuevoColorDeFondo = $_POST['colorDeFondo'];
    cambiarColorDeFondo($nuevoColorDeFondo);
}

//COLOR DEL TEXTO
if (isset($_REQUEST['textColor'])) {
    $nuevoColorDeTexto = $_POST['textColor'];
    cambiarColorDelTexto($nuevoColorDeTexto);
}

//CONTADOR DE VISITAS
if (isset($_SESSION['visitas'])) {
    if ($_SESSION['visitas'] == 1) {
        $contador = $_COOKIE['numeroVisitas'] + $_SESSION['visitas'];
        setcookie("numeroVisitas", $contador);
        $_SESSION['visitas'] = 0;
        header("Refresh:0");
    }
}

//VACIAR CONTADO DE VISITAS
if (isset($_REQUEST['vaciarVisitas'])) {
    setcookie("numeroVisitas", "", time() - 6400);
    header("Refresh:0");
}
//RESTABLECER TODO
if (isset($_REQUEST['restablecerTodo'])) {
    borrarCookies();
}
?>

<div id='setting'>
    <form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post'> 
        <fieldset>
            <legend>Color de Fondo: </legend>
            <div class='Bcolores'>
                <input type='submit' name='colorDeFondo' class="Azul" value="Azul"/>
                <input type='submit' name='colorDeFondo' class="Amarillo" value="Amarillo"/>
                <input type='submit' name='colorDeFondo' class="Verde" value="Verde"/>
                <input type='submit' name='colorDeFondo' class="Morado" value="Morado"/>
                <input type='submit' name='colorDeFondo' class="Negro" value="Negro"/>
                <input type='submit' name='colorDeFondo' class="Blanco" value="Blanco"/>
                <input type='submit' name='colorDeFondo' class="Rojo" value="Rojo"/>
                <input type='submit' name='colorDeFondo' class="Marron" value="Marron"/>
                <input type='submit' name='colorDeFondo' class="Rosa" value="Rosa"/>
                <input type='submit' name='colorDeFondo' class="Naranja" value="Naranja"/>
            </div>
        </fieldset>
    </form>

    <form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post'> 
        <fieldset>
            <legend>Color del Texto: </legend>
            <div class='TextColores'>
                <input type='submit' name='textColor' class="Azul" value="Azul"/>
                <input type='submit' name='textColor' class="Amarillo" value="Amarillo"/>
                <input type='submit' name='textColor' class="Verde" value="Verde"/>
                <input type='submit' name='textColor' class="Morado" value="Morado"/>
                <input type='submit' name='textColor' class="Negro" value="Negro"/>
                <input type='submit' name='textColor' class="Blanco" value="Blanco"/>
                <input type='submit' name='textColor' class="Rojo" value="Rojo"/>
                <input type='submit' name='textColor' class="Marron" value="Marron"/>
                <input type='submit' name='textColor' class="Rosa" value="Rosa"/>
                <input type='submit' name='textColor' class="Naranja" value="Naranja"/>
            </div>
        </fieldset>
    </form>

    <fieldset>
        <div class='TextVisitas'>
            <p>Numero de veces que has visitado este sitio: <?php
                if (isset($_COOKIE['numeroVisitas'])) {
                    echo $_COOKIE['numeroVisitas'];
                } else {
                    echo 0;
                }
                ?></p>
        </div>
        <form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post'> 
            <input type='submit' name='vaciarVisitas' value="Restlablecer contador de visitas a cero."/>
        </form>
    </fieldset>

    <fieldset>
        <div class='BotonRestablecer'>
            <form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post'> 
                <input type='submit' name='restablecerTodo' value="Restlablecer todo"/>
            </form>
        </div>
    </fieldset>

</div>
