<?php
include 'funciones.inc';
include 'components/header.php';
include 'components/nav.php';
include 'components/footer.php';

/**
 * Comprueba que todos los campos se han rellenado, si es así llama a la funcion 'altaDeUsuario'.
 */
if (isset($_REQUEST['usuario'])) {
    if (!empty($_REQUEST['usuario'])) {
        if(!empty($_REQUEST['password'])){
            if(!empty($_REQUEST['email'])){
                $AltaUsuario = $_POST['usuario'];
                $AltaPassword = $_POST['password'];
                $AltaEmail = $_POST['email'];
                
                altaDeUsuario($AltaUsuario, $AltaPassword, $AltaEmail);
            
            } else {
                echo "<script>alert('Error: Debe de escribir un correo electronico.');</script>";
            }
        }else{
            echo "<script>alert('Error: Debe de escribir una contraseña.');</script>";
        }
    } else {
        echo "<script>alert('Error: Debe de escribir un nombre de usuario.');</script>";
    }
}
?>

<div id="ContenedorBlanco">
    <form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post'>
        <h3>Introduce los datos del nuevo usuario</h3>
        <div class='campo'>
            <label for='usuario' >Nombre de usuario: </label>
            <input type='text' name='usuario' id='usuario' maxlength="50" /><br/>
        </div>
        <div class='campo'>
            <label for='password' >Contraseña: </label>
            <input type='password' name='password' id='password' maxlength="50" /><br/>
        </div>
        <div class='campo'>
            <label for='email' >Correo electronico: </label>
            <input type='text' name='email' id='email' maxlength="100" /><br/>
        </div>
        <div class='campo'>
            <input type='submit' name='enviar' value='Enviar' />
        </div>
    </form>
</div>