<?php
include 'components/header.php';
include 'components/footer.php';

/**
 * Esta página solo sirve para conectar un usuario a la base de datos.
 */

if (isset($_REQUEST['usuario'])) {
    $user = $_REQUEST['usuario'];
    $password = $_REQUEST['password'];
    @ $dwes = new mysqli("localhost", "dwes", "dwes", "matriculaciones");
    $error = $dwes->connect_errno;

    if ($error == null) {
        $sql = "SELECT pwd FROM usuarios WHERE usuario='$user'";
        $resultado = $dwes->query($sql);

        if ($resultado->num_rows == 0) {
            echo "<script>alert('Error: Usuario no valido.');</script>";
        } else {
            $fila = $resultado->fetch_assoc();
            if (password_verify($password, $fila['pwd'])) {
                /* El usuario y la contraseña son validos */
                /* VARIABLES DE SESION */
                $time = time();
                $horaDeConexion = date("d-m-Y (H:i:s)", $time);
                $_SESSION['user'] = $user; //Nombre del usuario
                $_SESSION['horaDeConexion'] = $horaDeConexion; //Hora de conexion
                if ($user == "admin") {//Si es administrador
                    $_SESSION['administrador'] = 1;
                } else {
                    $_SESSION['administrador'] = 0;
                }
                $_SESSION['visitas'] = 1;
                /* COOKIES */
                if (!isset($_COOKIE['backgroudColor'])) {
                    setcookie("backgroudColor", "Red", time() + 3600);
                }
                if (!isset($_COOKIE['textColor'])) {
                    setcookie("textColor", "TNegro", time() + 3600);
                }
                if (!isset($_COOKIE['numeroVisitas'])) {
                    setcookie("numeroVisitas", 0);
                }
                //Vuelve al index.php
                header("Location: index.php");
            } else {
                echo "<script>alert('Contraseña incorrecta');</script>";
            }
        }
        $resultado->close();
        $dwes->close();
    }
}
?>
<div id='ContenedorBlanco'>
    <form action='<?php echo $_SERVER['PHP_SELF']; ?>' method='post'>
        <fieldset>
            <div class='campo'>
                <label for='usuario' >Usuario:</label><br/>
                <input type='text' name='usuario' id='usuario' maxlength="50" /><br/>
            </div>
            <div class='campo'>
                <label for='password' >Contraseña:</label><br/>
                <input type='password' name='password' id='password' maxlength="50" /><br/>
            </div>

            <div class='campo'>
                <input type='submit' name='enviar' value='Enviar' />
            </div>
        </fieldset>
    </form>
</div>
</body>
</html>

