<?php 
include 'funciones.inc';
/**
 * No realiza la conexion hasta que no pulsemos el boton.
 */
if(isset($_REQUEST['boton'])){
    $User = $_POST['user'];
    $Password = $_POST['pass'];
    $Server = $_POST['server'];
    $DataBase = $_POST['dataBase'];
    //Recogemos los datos con y se lo pasamos a la funcion que realiza la conexion.
    if(conexion($Server, $User, $Password, $DataBase)){
        //Si se realiza la conexion redirige a la pagina consulta.
        header('Location: consulta.php');
    }
}

?>
<form name="consulta" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    <p>Usuario: <input type="text" name="user" value="root"></p>
    <p>Contraseña: <input type="text" name="pass" value=""></p>
    <p>Nombre de la Base de Datos: <input type="text" name="server" value="productos_comerciales"></p>
    <p>Servidor: <input type="text" name="dataBase" value="localhost"></p>
    <input type="submit" name="boton" value="Consultar productos">
</form>
<?php
