<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <form name="input" action="formulario.php" method="post">
            <input type="submit" value="Consultar datos (Ejercicio 1)">
    </form><br>
    <form name="input" action="comprobarDNI.php" method="post">
            <input type="submit" value="Comprobar DNI (Ejercicio 2)">
    </form>
    </body>
</html>
