<?php
//Si se pulsa el boton vuelve al index.
if(isset($_REQUEST['submit']) == 1){
    header('Location: index.php');
}
?>
<table>
<?php
@ $Conexion = new mysqli('localhost', 'root', '', 'productos_comerciales');
    $error = $Conexion->connect_errno;
    if ($error != null) {
        return "<p>Error $error conectando a la base de datos: $Conexion->connect_error</p>";
        exit();
    } else {    
    if ($result = mysqli_query($Conexion, "SELECT `nombre`, `descripcion`, `precio`,`descuento` FROM `productos`")) {
        $row = $result->fetch_assoc();
        echo '<br><td>Nombre</td></br><br><td>Descipcion</td></br><br><td>Precio</td></br><br><td>Descuento</td></br>';
        while ($row != null) {
            echo "<tr><td>${row['nombre']}</td><td>${row['descripcion']}</td><td>${row['precio']}</td><td>${row['descuento']}</td></tr>";
            $row = $result->fetch_assoc();
        }
    }
    mysqli_close($Conexion);
    }
?>
</table><br>
<form action="." method="post">
      <input type="submit" value="Volver al Inicio">
 </form>

