<!--Formulario para recoger el DNI -->
<form name="input" action="devolverDNI.php" method="post">
    <h2>Introduce tu DNI</h2>
    <p>Numeracion: <input name="numero" type="number" maxlength="8" minlength="8"> 
        Letra:<input name="letra" type="text" maxlength="1"></p>
    <input type="submit" value="Enviar">
</form>
