<?php

/**
 * Recoge los datos del formulario y crea las variables que serviran para
 * pasarlas a la funcion que comprueba el DNI.
 */
include 'funciones.inc';
$letra = $_POST['letra'];
$numeros = $_POST['numero'];

validar_dni($letra, $numeros);

