<?php

include './login.php';
require_once('Vehiculo.php');

class Coche extends Vehiculo {

    protected $_puertas;
    protected $_potencia;
    protected $_precio;
    protected $_foto;

    public function _construct($row) {
        parent::_construct($row);
        $this->_puertas = $row['puertas'];
        $this->_potencia = $row['potencia'];
        $this->_precio = $row['precio'];
        $this->_foto = $row['foto'];
    }

//*********  Getters y setters  ***************************************************
    public function getpuertas() {
        return $this->_puertas;
    }

    public function getpotencia() {
        return $this->_potencia;
    }

    public function getprecio() {
        return $this->_precio;
    }

    public function getfoto() {
        return $this->_foto;
    }

    public function getmarca() {
        return $this->_marca;
    }

    public function getmodelo() {
        return $this->_modelo;
    }

    public function getanho() {
        return $this->_anho;
    }

    public function getcombustible() {
        return $this->_combustible;
    }

//**************************  FUNCIONES  ************************************************

    /**
     * Funcion que crea los objeto coche de la base de datos.
     * @return \Coche
     */
    public function cargando() {
        //Preparo sentencia sql.
        $sql = "SELECT marca, modelo, anho, puertas, combustible, potencia, precio, foto FROM coches;";
        $resultado = conexionBaseDatos($sql);
        $coches = array();

        if ($resultado) {
            $row = $resultado->fetch();
            while ($row != null) {
                $coches[] = new Coche($row);
                $row = $resultado->fetch();
            }
        }
        return $coches;
    }
}
