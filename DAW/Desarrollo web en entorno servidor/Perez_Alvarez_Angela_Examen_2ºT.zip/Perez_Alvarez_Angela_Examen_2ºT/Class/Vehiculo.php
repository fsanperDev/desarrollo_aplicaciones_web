<?php

class Vehiculo {
    protected $_marca;
    protected $_modelo;
    protected $_anho;
    protected $_combustible;
    
    public function _construct($row) {
        $this->_marca = $row['marca'];
        $this->_modelo = $row['modelo'];
        $this->_anho = $row['anho'];
        $this->_combustible = $row['combustible'];
    }
}

