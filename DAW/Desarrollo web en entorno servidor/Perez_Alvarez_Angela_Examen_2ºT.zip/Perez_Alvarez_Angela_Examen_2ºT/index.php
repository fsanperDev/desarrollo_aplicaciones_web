<?php
require_once('Class/Coche.php');
//Rutas smarty
require_once('Smarty.class.php');
$smarty = new Smarty;
$smarty->template_dir = './web/smarty/templates/';
$smarty->compile_dir = './web/smarty/templates_c/';
$smarty->config_dir = './web/smarty/configs/';
$smarty->cache_dir = './web/smarty/cache/';

//Variable smarty para coche.
$mp=Coche::cargando();
$smarty->assign('listaCoches', $mp);

//Llamar a la plantilla.
$smarty->display('index.tpl');