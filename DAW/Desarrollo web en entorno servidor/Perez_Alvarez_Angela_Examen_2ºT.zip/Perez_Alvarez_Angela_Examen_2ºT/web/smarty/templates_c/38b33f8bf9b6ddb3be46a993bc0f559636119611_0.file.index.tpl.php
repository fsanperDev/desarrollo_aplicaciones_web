<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-05 20:41:47
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_Examen_2ºT\web\smarty\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e6155fb646ba8_90894058',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '38b33f8bf9b6ddb3be46a993bc0f559636119611' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_Examen_2ºT\\web\\smarty\\templates\\index.tpl',
      1 => 1583437302,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e6155fb646ba8_90894058 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="estilo.css" />
        <title></title> 
    </head>
    <body>
        <div class="contenedor">
            <div id="encabezado">
                <h1>Listado de Coches</h1>
            </div>
            <div id="productos">
             <ul>
                <ul>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['listaCoches']->value, 'coche');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['coche']->value) {
?>
                        <li>Marca: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getmarca();?>
 | Modelo: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getmodelo();?>
| Año: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getanho();?>
| 
                            Puertas: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getpuertas();?>
| Combustible: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getcombustible();?>
| Potencia: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getpotencia();?>
| 
                            Precio: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getprecio();?>
| Foto: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getfoto();?>
</li>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </ul>
              </ul>
            </div>      
        </div>
    </body>
</html><?php }
}
