<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-05 20:09:49
  from 'C:\xampp\htdocs\Perez_Alvarez_Angela_Examen_2ºT\web\smarty\templates\listacoches.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e614e7d640625_23648610',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6209816e5bcb5cdd3000379143a45ed5b55ab40e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Perez_Alvarez_Angela_Examen_2ºT\\web\\smarty\\templates\\listacoches.tpl',
      1 => 1583435353,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e614e7d640625_23648610 (Smarty_Internal_Template $_smarty_tpl) {
?><ul>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['coches']->value, 'coche');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['coche']->value) {
?>
        <li>Marca: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getmarca;?>
 | Modelo: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getmodelo;?>
| Año: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getanho;?>
| 
            Puertas: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getpuertas;?>
| Combustible: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getcombustible;?>
| Potencia: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getpotencia;?>
| 
            Precio: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getprecio;?>
| Foto: <?php echo $_smarty_tpl->tpl_vars['coche']->value->getfoto;?>
</li>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</ul><?php }
}
