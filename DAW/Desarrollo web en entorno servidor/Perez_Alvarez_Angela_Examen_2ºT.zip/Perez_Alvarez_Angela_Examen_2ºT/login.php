<?php

function conexionBaseDatos($sql) {
    /**
     * Conexion a la base de datos.
     * 
     * Mi root por defecto es 'dwes' y con contraseña, puedes cambiar el valor en las variables mas abajo.
     */

    $opc = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8");
        $dsn = "mysql:host=localhost;dbname=coches";
        $usuario = 'dwes';
        $contrasena = 'dwes';
    
    $Conexion = new PDO($dsn, $usuario, $contrasena, $opc);
    $resultado = null;
    if (isset($Conexion))
        $resultado = $Conexion->query($sql);
    return $resultado;

}
