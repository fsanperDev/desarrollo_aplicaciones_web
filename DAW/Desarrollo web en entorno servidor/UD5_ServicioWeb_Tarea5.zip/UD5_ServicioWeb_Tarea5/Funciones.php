<?php

require_once 'preciario.php';

/**
 * Clase Funciones
 */
class Funciones {
    /**
     * Funcion que devuelve el precio del crédito segun el año y la convocatoria recibidos.
     * 
     * @global array $precioAnhoAsignatura
     * @param string $anho 
     * @param string $convocatoria 
     * @return double
     */
    public function getPrecioDeCreditoAcademico($anho, $convocatoria) {
        global $precioAnhoAsignatura;
        return $precioAnhoAsignatura[$anho][$convocatoria];
    }

    /**
     * Funcion que recibe el año, convocatoria y numero de creditos, devolviendo el precio total de la asignatura.
     * 
     * @param string $anho 
     * @param string $convocatoria 
     * @param integer $numCreditos 
     * @return double
     */
    public function getPrecioDeAsignatura($anho, $convocatoria, $numCreditos) {
        $precioTotaldeAsignatura = ($this->getPrecioDeCreditoAcademico($anho, $convocatoria)) * $numCreditos;
        return $precioTotaldeAsignatura;
    }
}




