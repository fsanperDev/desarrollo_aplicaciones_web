<?php
/**
 * Este array contiene los precios de 1 credito según el año y la convocatoria.
 */
$precioAnhoAsignatura = array(
    "2017" => array("1" => 24.00, "2" => 40.02, "3" => 82.30),
    "2018" => array("1" =>24.50, "2" => 45.25, "3" => 92.86),
    "2019" => array("1" =>25.50, "2" => 48.20, "3" => 86.30)
);
        

