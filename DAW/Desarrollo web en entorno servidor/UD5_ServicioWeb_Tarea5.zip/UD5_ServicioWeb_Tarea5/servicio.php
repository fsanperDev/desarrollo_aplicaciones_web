<?php

require_once './src/WSDLDocument.php';
require_once 'Funciones.php';

/********************* WSDL DOCUMENT **************************************/
//Los servicios web no funcionan con el wsdl, por ello esta comentado, para verlo tienes que descomentar la parte WSDL.
/*
$wsdl = new WSDLDocument( "Funciones", 
                          "http://localhost/UD5_ServicioWeb_Tarea5/servicio.php",
                          "http://localhostg/UD5_ServicioWeb_Tarea5/");
echo $wsdl->saveXml();*/
/**************************************************************************/

/* SOAP SIN WSDL */
$options = array("uri" => "http://localhost/UD5_ServicioWeb_Tarea5/");
$server = new SoapServer(null, $options);
$server->setClass('Funciones');
$server->handle();









