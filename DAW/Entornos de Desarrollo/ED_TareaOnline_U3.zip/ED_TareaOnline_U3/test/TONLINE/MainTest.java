/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TONLINE;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ANGELA PEREZ
 */
public class MainTest {
    
    public MainTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test para el método introducir_resultado de la Clase Partido con valores correctos, valores positivos
     * @throws java.lang.Exception
     */
    @Test
    public void testResultadoP() throws Exception {
        System.out.println("Test para introducir_resultado con valores correctos");
        int g_local = 3;
        int g_visitante = 4;
        Partido p = new Partido ();
        p.introducir_resultado(3, 4);
        assertTrue(p.getFinalizado() == true);
        System.out.println("\033[32mLos valores son correctos");
    }
    /**
     * Test para el método introducir_resultado de la Clase Partido con valores incorrectos, valores negativos
     * @throws Exception 
     */
        @Test
    public void testResultadoN() throws Exception {
        System.out.println("Test para introducir_resultado con valores incorrectos");
        int g_local = -2;
        int g_visitante = 4;
        Partido p = new Partido ();
        try{
             p.introducir_resultado(-2, 4);
             fail("No puede tener numero negativos");
        }catch (Exception e){
         System.out.println(e);
            assertFalse(p.getFinalizado() == true);
        }
        System.out.println("\033[32mLos valores tiene que ser igual o mayor que 0");
    }
    /**
     * Test para llamar al método apostar y que los datos introducidos sean correctos
     * @throws Exception 
     */
     @Test
        public void testApostarCorrecto() throws Exception {
        System.out.println("Test para apostar con valores correctos");
        int dineroT = 1000;
        Apuesta a = new Apuesta();
        a.set_dinero_total(dineroT);
        a.apostar(100, 2, 4);
        assertTrue(((a.get_dinero_total()+ dineroT)>= dineroT ) );
        System.out.println("\033[32mLa prueba se ha realizado con exito");
    }
        /**
         * El dinero a apostar es mayor a la cantidad total
         * @throws Exception 
         */
        @Test
        public void testApostarSobrepasar() throws Exception {
        System.out.println("Test para apostar con valores que sobrepasan al total del dinero");
        int dineroT = 1000;
        Apuesta a = new Apuesta();
        a.set_dinero_total(dineroT);
        try{
        a.apostar(1200, 2, 4);
        fail("La apuesta es mayor al numero de dinero total");
        } catch (Exception e){
         System.out.println(e);
        assertTrue((a.get_dinero_total()>= dineroT ) );
        }
        System.out.println("\033[32mLa prueba se ha realizado con exito");
    }
   /**
    * La apuesta es por menos de 1€
    * @throws Exception 
    */
           @Test
        public void testApostarMenos1() throws Exception {
        System.out.println("Test para apostar con valores menores al mínimo permitido");
        int dineroT = 1000;
        Apuesta a = new Apuesta();
        a.set_dinero_total(dineroT);
        try{
            a.apostar(0, 2, 4);
            fail("Hay que apostar al menos 1€");
        }catch (Exception e){
            System.out.println(e);
            assertTrue((a.get_dinero_total()>= dineroT ) );
        }
        System.out.println("\033[32mLa prueba se ha realizado con exito");
    }
   /**
    * El este test se probara la variante cobrar_apuesta con valores correctos
    * @throws Exception 
    */
  @Test
        public void testCobrarCorrecto() throws Exception {
        System.out.println("Test para cobrar con valores correctos");
        int dineroT = 1000;
        Apuesta a = new Apuesta();
        Partido p = new Partido();
        a.set_dinero_total(dineroT);
        a.apostar(100, 2, 4);
        p.introducir_resultado(2, 4);//Para finalizar el partido
        a.cobrar_apuesta(p);
        assertTrue((a.get_dinero_total()>= dineroT ) );
        System.out.println("\033[32mLa prueba se ha realizado con exito");
    }    
     /**
    * El este test se probara la variante cobrar_apuesta cuando la apuesta no se ha hacertado
    * @throws Exception 
    */
  @Test
        public void testCobrarAcierto() throws Exception {
        System.out.println("Test para comprobar los valores cuando la apuesta no se hacierta ");
        int dineroT = 1000;
        Apuesta a = new Apuesta();
        Partido p = new Partido();
        a.set_dinero_total(dineroT);
        a.apostar(100, 1, 4);
        p.introducir_resultado(2, 4);//Para finalizar el partido
        try{
            a.cobrar_apuesta(p);
            fail("No has hacertado la apuesta");
        }catch (Exception e){
            System.out.println(e);
            if(a.comprobar_resultado(p)==true){
                assertTrue((a.get_dinero_total()>= dineroT ) );
            }else{
                assertTrue((a.comprobar_resultado(p)==false));
                System.out.println("La apuesta no ha sido acertada");
            }
           // assertTrue((a.get_dinero_total()>= dineroT ) );
        }
        System.out.println("\033[32mLa prueba se ha realizado con exito");
    }  
       /**
    * El este test se probara la variante cobrar_apuesta cuando el partido aun no ha terminado
    * @throws Exception 
    */
  @Test
        public void testCobrarTerminadoP() throws Exception {
        System.out.println("Test para comprobar los valores cuando el partido aun no ha terminado");
        int dineroT = 1000;
        Apuesta a = new Apuesta();
        Partido p = new Partido();
        a.set_dinero_total(dineroT);
        a.apostar(100, 2, 4);
        //p.introducir_resultado(2, 4);//Para finalizar el partido
        try{
            a.cobrar_apuesta(p);
            fail("El partido aun no ha terminado");
        }catch (Exception e){
            System.out.println(e);
            assertFalse((p.getFinalizado()==true ) );
        }
        System.out.println("\033[32mLa prueba se ha realizado con exito");
    } 
}
