package Ejercicio1;

/**
 * @author Adrián
 */
public class Funciones {    
    //Devuelve true o false según si él numero pasado es primo o no
    public static boolean esPrimo(int n){
        int contador = 2;
        boolean primo = true;
        if(n == 1){
            primo = false;
        }
        else{
            while ((primo) && (contador != n)){
                if (n % contador == 0){
                    primo = false;
                }
                contador++;
            }
        }
        return primo;
    }//FIN método (esPrimo)    

    //Devuelve el número de vocales que contiene una frase
    public static int contarVocales(String f){
        //Variables
        int numVocales = 0;
        f = f.toLowerCase(); // Pasar a minuscula la frase
        int tama = f.length();
        
        //Cuento vocales:
        for(int i=0; i < tama; i++) {
          if ((f.charAt(i)=='a') || (f.charAt(i)=='e') || (f.charAt(i)=='i') || (f.charAt(i)=='o') || (f.charAt(i)=='u'))
            numVocales = numVocales + 1;
          }        
        return numVocales;
    }//FIN método (contarVocales) 
    
 
    //Devuelve tu nombre y tus apellidos concatenados en una sola cadena
    public String unirNombreApellidos(String nombre, String apellido1, String apellido2, boolean unido) throws Exception{ 
        //Comprobar parámetros NO vacíos.
        if(nombre.equals("") || apellido1.equals("")|| apellido2.equals("")){
            throw new Exception("No puede quedarse ni tu nombre ni tus apellidos vacíos");
        }
        
        //Formato unido: ejemplo resultado --> "PepitoGrilloPérez"
        if(unido){
            //Variables:
            String n, ap1,ap2;
            
            //Pasar a minúsculas y sin espacios
            n = nombre.toLowerCase().trim();
            ap1 = apellido1.toLowerCase().trim();
            ap2 = apellido2.toLowerCase().trim();
            
            //Poner primera letra en mayúsculas
            n = n.substring(0, 1).toUpperCase() + n.substring(1);
            ap1 = ap1.substring(0, 1).toUpperCase() + ap1.substring(1);
            ap2 = ap2.substring(0, 1).toUpperCase() + ap2.substring(1);
            
            //Concatenación
            return n+ap1+ap2;
        }
        //Formato separado: ejemplo resultado --> "Pepito Grillo Pérez"
        else{
            //Concatenación
            return nombre.trim()+" "+apellido1.trim()+" "+apellido2.trim();
        }
        
    }//FIN método (unirNombreApellidos)    
    
}
