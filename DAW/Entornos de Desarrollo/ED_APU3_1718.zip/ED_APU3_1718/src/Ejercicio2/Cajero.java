package Ejercicio2;

/**
 *
 * @author Adrián
 */
public class Cajero {
    //Atibutos
    private int saldoCuenta;
    private boolean averiado = false;
    private int maximoPermitido;
    
    //CONSTRUCTORES
    //Por defecto
    public Cajero() {
    }
    //Por parámetros
    public Cajero(int s, int m) {
        this.saldoCuenta = s;
        this.maximoPermitido = m;
    }    

    //GETTERS AND SETTERS   
     public int getSaldoCuenta() {
        return saldoCuenta;
    }

    public void setSaldoCuenta(int s) {
        this.saldoCuenta = s;
    }

    public boolean getAveriado() {
        return averiado;
    }

    public void setAveriado(boolean averiado) {
        this.averiado = averiado;
    }    
    
    //FUNCIONES PROPIAS
    /*
        Método para retirar una cantidad de dinero del saldo de la cuenta.
        -  El cajero no puede estar averiado
        -  No se puede retirar una cantidad mayor al máximo permitido establecido para esa cuenta
        -  No se puede retirar una cantidad menor a 20€    
    */
    public int retirar(int cantidad) throws Exception{
        //COMPROBACIONES:
        //Comprobamos si el cajero está averiado
        if(averiado){
            throw new Exception("El cajero se encuentra averiado.");
        }
        //Comprobamos si la cantidad de dinero a retirar no excede el límite establecido
        if(cantidad > maximoPermitido){
            throw new Exception("No puedes retirar esa cantidad de dinero. Revisa la configuración de tu cuenta.");
        }
        //Comprobamos si la cantidad es menor a la canitdad mínima a retirar
        if(cantidad < 20){
            throw new Exception("Sólo puedes retirar cantidades iguales o superiores a 20€");
        }
        //Todo correcto, se realiza la operación
        this.saldoCuenta = this.saldoCuenta - cantidad;
        
        //Se devuelve la cantidad solicitada
        return cantidad;
    }
   
}
