package Ejercicio1;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Adrián
 */
public class Main {    
    public static void main(String[] args) {
        //Atributos
        String aux;
        int tama;
        int maxNumero;  
        
        //PEDIR DATOS
            //Pido tamaño del array
            do{
                aux = JOptionPane.showInputDialog("Introduce el tamaño del array (<="+100 );
                tama = Integer.valueOf(aux);//Convierte de String a entero
            }while(tama<=100);            
            //Pido el número máximo posble
            do{
                aux = JOptionPane.showInputDialog("Introduce el mayor número que puede contener el array(<="+ 1000 );
                maxNumero = Integer.valueOf(aux);//Convierte de String a entero   
            }while(maxNumero<=1000);
                                  
        //CREAR ARRAY
            Numeros nums = new Numeros(tama, maxNumero);
       
        //MOSTRAR ARRAY
            System.out.println("MUESTRO LA LISTA DE LOS NÚMEROS CREADOS:");
            for(int num: nums.numeros){
                System.out.println("\t--"+num+"--");
            }
        
        //CALCULOS
            System.out.println("MUESTRO LOS CÁLCULOS:");
            int suma=0, media=0, pares=0;
            //Recorro array
            for(int num: nums.numeros){
                suma += num;//Calculo suma
                if(num%2 == 0) pares++;//Calculo pares
            }
            //Muestro info
            System.out.println("\tLa SUMA del array es: "+suma);            
            media = suma/(nums.numeros.size());
            System.out.println("\tLa MEDIA del array es: "+media);
            System.out.println("\tEl número de números PARES es: "+pares); 
            
    }//Fin main  

    
}
