package Ejercicio1;

import java.util.ArrayList;
import java.util.Random;

/**
 * @author Adrián
 */
public class Numeros {
    //ATRIBUTOS
    public ArrayList<Integer> numeros; 
    public int tama;
    public int maxNumero;
    
    //CONSTRUCTOR POR PARÁMETROS
    public Numeros(int tama, int maxNumero){
        //Incializo campos
        numeros = new ArrayList<> ();
        this.tama = tama;
        this.maxNumero = maxNumero;
                
        //Relleno el array "numeros" con números aleatorios
        Random series = new Random();
        int vez = 1;
        int numero;
        while(vez<=tama){
            numero = series.nextInt(maxNumero) + 1;
            numeros.add(numero);
            vez++;
        }
    }//fin constructor
    
    
    
}//fin clase
