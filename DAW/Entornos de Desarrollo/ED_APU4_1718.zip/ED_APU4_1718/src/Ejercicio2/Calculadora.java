package Ejercicio2;

public class Calculadora {
    //ATRIBUTOS
        private String autor;
        private int x;
	private int y;

	
    //FUNCIONES PROPIAS 
	public int suma(){
		int resul = this.x + this.y;
		return resul;
	}
	
	public int resta(){
		int resul = this.x - this.y;
		return resul;		
	}
	
	public int multiplica(){
		int resul = this.x * this.y;
		return resul;
	}
	
	public int divide(){
		int resul = this.x / this.y;
		return resul;
	}	
}
