package Ejercicio2;



public class Animal{
    //ATRIBUTOS
    private String nombreCientífico;
    private String tipoEstructura;
    private String tipoReproduccion;
    private String tipoAlimentacion;
    private int numExtremidades;
    private int velocidadMaxima;
    private boolean acuatico;
    private boolean terrestre;
    private boolean aereo;
    private boolean enPeligroExtinción;
    
    //FUNCIONES PROPIAS    
    public void nacer(int día, int mes, int año){
    }
    public void morir(int día, int mes, int año){
    }
    public void reproducirse(){        
    }
    public void alimentarse(){        
    }
}
